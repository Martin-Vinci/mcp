--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: universe_dw; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA universe_dw;


ALTER SCHEMA universe_dw OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_category; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.account_category (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    account_code character varying(200),
    account_description character varying(200),
    account_type character varying(200),
    account_creation_date character varying(200),
    account_closure_date character varying(200),
    account_status character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.account_category OWNER TO postgres;

--
-- Name: account_category_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.account_category_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.account_category_ptid_seq OWNER TO postgres;

--
-- Name: account_category_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.account_category_ptid_seq OWNED BY universe_dw.account_category.ptid;


--
-- Name: accounts_unsold; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.accounts_unsold (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    security_issuer_name character varying(200),
    relationship_type character varying(200),
    underwritten_security_type character varying(200),
    contract_date character varying(200),
    issuer_country character varying(200),
    credit_rating_counter_customer character varying(200),
    gradesfor_unrated_customer character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    past_due_days character varying(200),
    impairment character varying(200),
    bot_provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.accounts_unsold OWNER TO postgres;

--
-- Name: accounts_unsold_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.accounts_unsold_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.accounts_unsold_ptid_seq OWNER TO postgres;

--
-- Name: accounts_unsold_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.accounts_unsold_ptid_seq OWNED BY universe_dw.accounts_unsold.ptid;


--
-- Name: accrued_taxes; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.accrued_taxes (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    claimant_name character varying(200),
    payable_category character varying(200),
    transaction_date character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    maturity_date character varying(200),
    sector_lender_sna_classification character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.accrued_taxes OWNER TO postgres;

--
-- Name: accrued_taxes_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.accrued_taxes_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.accrued_taxes_ptid_seq OWNER TO postgres;

--
-- Name: accrued_taxes_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.accrued_taxes_ptid_seq OWNED BY universe_dw.accrued_taxes.ptid;


--
-- Name: agent_information; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.agent_information (
    ptid bigint NOT NULL,
    postal_code character varying(200),
    region character varying(200),
    district character varying(200),
    ward character varying(200),
    street character varying(200),
    house_number character varying(200),
    reporting_date timestamp(0) without time zone NOT NULL,
    agent_name character varying(200),
    agent_id character varying(200),
    till_number character varying(200),
    business_form character varying(200),
    agent_principal character varying(200),
    agent_principalname character varying(200),
    gender_male character varying(200),
    registration_date character varying(200),
    closed_date character varying(200),
    cert_incorporation character varying(200),
    nationality character varying(200),
    agent_status character varying(200),
    agent_type character varying(200),
    account_number character varying(200),
    country character varying(200),
    gps_coordinates character varying(200),
    agent_tax_identification_number character varying(200),
    business_license character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.agent_information OWNER TO postgres;

--
-- Name: agent_information_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.agent_information_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.agent_information_ptid_seq OWNER TO postgres;

--
-- Name: agent_information_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.agent_information_ptid_seq OWNED BY universe_dw.agent_information.ptid;


--
-- Name: agent_transaction; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.agent_transaction (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    agent_id character varying(200),
    agent_status character varying(200),
    transaction_date character varying(200),
    last_transaction_date character varying(200),
    transaction_id character varying(200),
    transaction_type character varying(200),
    service_channel character varying(200),
    till_number character varying(200),
    currency character varying(200),
    tzs_amount character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.agent_transaction OWNER TO postgres;

--
-- Name: agent_transaction_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.agent_transaction_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.agent_transaction_ptid_seq OWNER TO postgres;

--
-- Name: agent_transaction_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.agent_transaction_ptid_seq OWNED BY universe_dw.agent_transaction.ptid;


--
-- Name: asset_owned; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.asset_owned (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    asset_category character varying(200),
    asset_type character varying(200),
    acquisition_date character varying(200),
    currency character varying(200),
    org_cost_value character varying(200),
    usd_cost_value character varying(200),
    tzs_cost_value character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.asset_owned OWNER TO postgres;

--
-- Name: asset_owned_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.asset_owned_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.asset_owned_ptid_seq OWNER TO postgres;

--
-- Name: asset_owned_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.asset_owned_ptid_seq OWNED BY universe_dw.asset_owned.ptid;


--
-- Name: atm_information; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.atm_information (
    ptid bigint NOT NULL,
    postal_code character varying(200),
    region character varying(200),
    district character varying(200),
    ward character varying(200),
    street character varying(200),
    house_number character varying(200),
    reporting_date timestamp(0) without time zone NOT NULL,
    atm_name character varying(200),
    branch_code character varying(200),
    atm_code character varying(200),
    qr_fsr_code character varying(200),
    gps_coordinates character varying(200),
    linked_account character varying(200),
    opening_date character varying(200),
    atm_status character varying(200),
    closure_date character varying(200),
    atm_category character varying(200),
    atm_channel character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.atm_information OWNER TO postgres;

--
-- Name: atm_information_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.atm_information_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.atm_information_ptid_seq OWNER TO postgres;

--
-- Name: atm_information_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.atm_information_ptid_seq OWNED BY universe_dw.atm_information.ptid;


--
-- Name: atm_transaction; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.atm_transaction (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    atm_code character varying(200),
    till_number character varying(200),
    transaction_date character varying(200),
    transaction_id character varying(200),
    transaction_type character varying(200),
    currency character varying(200),
    org_transaction_amount character varying(200),
    tzs_transaction_amount character varying(200),
    atm_channel character varying(200),
    atm_services character varying(200),
    mobile_money_services character varying(200),
    value_added_tax_amount character varying(200),
    excise_duty_amount character varying(200),
    electronic_levy_amount character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.atm_transaction OWNER TO postgres;

--
-- Name: atm_transaction_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.atm_transaction_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.atm_transaction_ptid_seq OWNER TO postgres;

--
-- Name: atm_transaction_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.atm_transaction_ptid_seq OWNED BY universe_dw.atm_transaction.ptid;


--
-- Name: balance_bot; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.balance_bot (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    account_number character varying(200),
    account_name character varying(200),
    account_type character varying(200),
    sub_account_type character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    usd_amount character varying(200),
    tzs_amount character varying(200),
    transaction_date character varying(200),
    maturity_date character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.balance_bot OWNER TO postgres;

--
-- Name: balance_bot_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.balance_bot_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.balance_bot_ptid_seq OWNER TO postgres;

--
-- Name: balance_bot_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.balance_bot_ptid_seq OWNED BY universe_dw.balance_bot.ptid;


--
-- Name: balance_mno; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.balance_mno (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    float_balance_date character varying(200),
    mno_name character varying(200),
    till_number character varying(200),
    currency character varying(200),
    org_float_amount character varying(200),
    usd_float_amount character varying(200),
    tzs_float_amount character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.balance_mno OWNER TO postgres;

--
-- Name: balance_mno_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.balance_mno_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.balance_mno_ptid_seq OWNER TO postgres;

--
-- Name: balance_mno_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.balance_mno_ptid_seq OWNED BY universe_dw.balance_mno.ptid;


--
-- Name: balance_other_banks; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.balance_other_banks (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    account_number character varying(200),
    account_name character varying(200),
    bank_name character varying(200),
    country character varying(200),
    relationship_type character varying(200),
    account_type character varying(200),
    currency character varying(200),
    org_amount_0 character varying(200),
    usd_amount_0 character varying(200),
    tzs_amount_0 character varying(200),
    transaction_date character varying(200),
    past_due_days_0 character varying(200),
    allowance_probable_loss character varying(200),
    assets_classification_category character varying(200),
    contract_date character varying(200),
    maturity_date character varying(200),
    external_rating_correspondent_bank character varying(200),
    grades_unrated_banks character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.balance_other_banks OWNER TO postgres;

--
-- Name: balance_other_banks_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.balance_other_banks_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.balance_other_banks_ptid_seq OWNER TO postgres;

--
-- Name: balance_other_banks_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.balance_other_banks_ptid_seq OWNED BY universe_dw.balance_other_banks.ptid;


--
-- Name: bank_funds_transfer; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.bank_funds_transfer (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    transaction_id character varying(200),
    transaction_code character varying(200),
    transaction_date character varying(200),
    transfer_channel character varying(200),
    subcategorytransferchannel character varying(200),
    sender_account_number character varying(200),
    recipient_name character varying(200),
    recipient_identification character varying(200),
    recipient_bank_code character varying(200),
    recipient_account_number character varying(200),
    recipient_mno_code character varying(200),
    recipient_mobile_number character varying(200),
    country character varying(200),
    transaction_type character varying(200),
    service_channel character varying(200),
    org_amount character varying(200),
    currency character varying(200),
    tzs_amount character varying(200),
    purposes character varying(200),
    sender_instruction character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.bank_funds_transfer OWNER TO postgres;

--
-- Name: bank_funds_transfer_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.bank_funds_transfer_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.bank_funds_transfer_ptid_seq OWNER TO postgres;

--
-- Name: bank_funds_transfer_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.bank_funds_transfer_ptid_seq OWNED BY universe_dw.bank_funds_transfer.ptid;


--
-- Name: bankers_cheques; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.bankers_cheques (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    customer_name character varying(200),
    customer_identification_number character varying(200),
    beneficiary_name character varying(200),
    cheque_number character varying(200),
    transaction_date character varying(200),
    value_date character varying(200),
    maturity_date character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    usd_amount character varying(200),
    tzs_amount character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.bankers_cheques OWNER TO postgres;

--
-- Name: bankers_cheques_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.bankers_cheques_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.bankers_cheques_ptid_seq OWNER TO postgres;

--
-- Name: bankers_cheques_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.bankers_cheques_ptid_seq OWNED BY universe_dw.bankers_cheques.ptid;


--
-- Name: borrowings_information; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.borrowings_information (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    borrowing_type character varying(200),
    lender_name character varying(200),
    lender_country character varying(200),
    lender_relationship character varying(200),
    transaction_unique_ref character varying(200),
    debt_registration_number character varying(200),
    borrowers_account_number character varying(200),
    account_number character varying(200),
    borrowers_bank_name character varying(200),
    sector_lender_sna_classification character varying(200),
    date_loan_contract character varying(200),
    date_loan_receipt character varying(200),
    date_loan_maturity character varying(200),
    annual_interest_rate character varying(200),
    interest_rate_type character varying(200),
    borrowing_purposes character varying(200),
    currency character varying(200),
    org_amount_opening character varying(200),
    tzs_amount_opening character varying(200),
    usd_amount_opening character varying(200),
    org_amount_repayment character varying(200),
    tzs_amount_repayment character varying(200),
    usd_amount_repayment character varying(200),
    org_amount_closing character varying(200),
    tzs_amount_closing character varying(200),
    usd_amount_closing character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.borrowings_information OWNER TO postgres;

--
-- Name: borrowings_information_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.borrowings_information_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.borrowings_information_ptid_seq OWNER TO postgres;

--
-- Name: borrowings_information_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.borrowings_information_ptid_seq OWNED BY universe_dw.borrowings_information.ptid;


--
-- Name: bot_replication_files; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.bot_replication_files (
    file_id bigint NOT NULL,
    file_name character varying(200) NOT NULL,
    run_freq_value smallint NOT NULL,
    run_freq_code character varying(20) NOT NULL,
    primary_column_name character varying,
    primary_column_data_type character varying(10),
    db_object_name character varying(100),
    last_run_date timestamp(0) without time zone,
    file_status character varying(10) NOT NULL,
    datasource_mode character varying(15) NOT NULL,
    last_spooled_value character varying,
    uuid character varying(50) NOT NULL
);


ALTER TABLE universe_dw.bot_replication_files OWNER TO postgres;

--
-- Name: bot_replication_summary; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.bot_replication_summary (
    batch_id bigint NOT NULL,
    repl_start_date timestamp(0) without time zone NOT NULL,
    repl_end_date timestamp(0) without time zone,
    status character varying(20) NOT NULL,
    response_log text,
    response_message character varying(150),
    file_id bigint NOT NULL,
    created_by character varying(15) NOT NULL,
    create_date timestamp(0) without time zone NOT NULL,
    uuid character varying(50) NOT NULL
);


ALTER TABLE universe_dw.bot_replication_summary OWNER TO postgres;

--
-- Name: bot_replication_summary_batch_id_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.bot_replication_summary_batch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.bot_replication_summary_batch_id_seq OWNER TO postgres;

--
-- Name: bot_replication_summary_batch_id_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.bot_replication_summary_batch_id_seq OWNED BY universe_dw.bot_replication_summary.batch_id;


--
-- Name: bot_replication_summary_file_id_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.bot_replication_summary_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.bot_replication_summary_file_id_seq OWNER TO postgres;

--
-- Name: bot_replication_summary_file_id_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.bot_replication_summary_file_id_seq OWNED BY universe_dw.bot_replication_files.file_id;


--
-- Name: bought_forward_exchange; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.bought_forward_exchange (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    counterpart_name character varying(200),
    relationship_type character varying(200),
    currency_a character varying(200),
    currency_b character varying(200),
    org_amount_currency_a character varying(200),
    exchange_rate_currency_ab character varying(200),
    org_amount_currency_b character varying(200),
    exchange_rate_currency_a_2_tzs character varying(200),
    exchange_rate_currency_b_2_tzs character varying(200),
    tzs_amount_currency_a character varying(200),
    tzs_amount_currency_b character varying(200),
    transaction_date character varying(200),
    value_date character varying(200),
    counterpart_cr_rating character varying(200),
    transaction_type character varying(200),
    counterpart_country character varying(200),
    cr_rating_counter_seller character varying(200),
    grades_unrated_seller character varying(200),
    past_due_days character varying(200),
    impairment character varying(200),
    bot_provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.bought_forward_exchange OWNER TO postgres;

--
-- Name: bought_forward_exchange_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.bought_forward_exchange_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.bought_forward_exchange_ptid_seq OWNER TO postgres;

--
-- Name: bought_forward_exchange_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.bought_forward_exchange_ptid_seq OWNED BY universe_dw.bought_forward_exchange.ptid;


--
-- Name: branch_information; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.branch_information (
    ptid bigint NOT NULL,
    postal_code character varying(200),
    region character varying(200),
    district character varying(200),
    ward character varying(200),
    street character varying(200),
    house_number character varying(200),
    reporting_date timestamp(0) without time zone NOT NULL,
    branch_name character varying(200),
    tax_identification_number character varying(200),
    business_license character varying(200),
    branch_code character varying(200),
    qr_fsr_code character varying(200),
    gps_coordinates character varying(200),
    banking_services character varying(200),
    mobile_money_services character varying(200),
    registration_date character varying(200),
    branch_status character varying(200),
    closure_date character varying(200),
    contact_person character varying(200),
    telephone_number character varying(200),
    alt_telephone_number character varying(200),
    branch_category character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.branch_information OWNER TO postgres;

--
-- Name: branch_information_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.branch_information_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.branch_information_ptid_seq OWNER TO postgres;

--
-- Name: branch_information_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.branch_information_ptid_seq OWNED BY universe_dw.branch_information.ptid;


--
-- Name: card_transaction; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.card_transaction (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    card_type character varying(200),
    credit_cardtype character varying(200),
    card_issuer character varying(200),
    card_issuer_category character varying(200),
    transacting_bank_name character varying(200),
    transaction_id character varying(200),
    card_holder character varying(200),
    card_number character varying(200),
    card_status character varying(200),
    transaction_date character varying(200),
    last_transaction_date character varying(200),
    transaction_nature character varying(200),
    atm_code character varying(200),
    pos_number character varying(200),
    currency character varying(200),
    org_transaction_amount character varying(200),
    tzs_transaction_amount character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.card_transaction OWNER TO postgres;

--
-- Name: card_transaction_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.card_transaction_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.card_transaction_ptid_seq OWNER TO postgres;

--
-- Name: card_transaction_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.card_transaction_ptid_seq OWNED BY universe_dw.card_transaction.ptid;


--
-- Name: cash_information; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.cash_information (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    branch_code character varying(200),
    cash_category character varying(200),
    sub_category character varying(200),
    currency character varying(200),
    cash_condition character varying(200),
    cash_denomination character varying(200),
    quantity_of_coins_notes character varying(200),
    org_amount character varying(200),
    usd_amount character varying(200),
    tzs_amount character varying(200),
    transaction_date character varying(200),
    maturity_date character varying(200),
    allowance_probable_loss character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.cash_information OWNER TO postgres;

--
-- Name: cash_information_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.cash_information_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.cash_information_ptid_seq OWNER TO postgres;

--
-- Name: cash_information_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.cash_information_ptid_seq OWNED BY universe_dw.cash_information.ptid;


--
-- Name: cheque_unsold; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.cheque_unsold (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    payee_name character varying(200),
    instrument_date character varying(200),
    instrument_issuer_bank character varying(200),
    drawer_name character varying(200),
    relationship_type character varying(200),
    cr_rating_counter_customer character varying(200),
    grades_unrated_customer character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    sector_sna_classification character varying(200),
    past_due_days character varying(200),
    impairment character varying(200),
    bot_provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.cheque_unsold OWNER TO postgres;

--
-- Name: cheque_unsold_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.cheque_unsold_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.cheque_unsold_ptid_seq OWNER TO postgres;

--
-- Name: cheque_unsold_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.cheque_unsold_ptid_seq OWNED BY universe_dw.cheque_unsold.ptid;


--
-- Name: cheques; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.cheques (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    cheque_number character varying(200),
    issuer_name character varying(200),
    issuer_banker character varying(200),
    payee_name character varying(200),
    payee_account_number character varying(200),
    cheque_date character varying(200),
    transaction_date character varying(200),
    settlement_date character varying(200),
    allowance_probable_loss character varying(200),
    currency character varying(200),
    org_amount_opening character varying(200),
    tzs_amount_opening character varying(200),
    org_amount_payment character varying(200),
    tzs_amount_payment character varying(200),
    org_amount_balance character varying(200),
    tzs_amount_balance character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.cheques OWNER TO postgres;

--
-- Name: cheques_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.cheques_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.cheques_ptid_seq OWNER TO postgres;

--
-- Name: cheques_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.cheques_ptid_seq OWNED BY universe_dw.cheques.ptid;


--
-- Name: claim_treasury; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.claim_treasury (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    transaction_date character varying(200),
    gov_institution_name character varying(200),
    currency character varying(200),
    org_amount_claimed character varying(200),
    tzs_amount_claimed character varying(200),
    usd_amount_claimed character varying(200),
    value_date character varying(200),
    maturity_date character varying(200),
    past_due_days character varying(200),
    provision character varying(200),
    asset_classification_category character varying(200),
    sector_sna_classification character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.claim_treasury OWNER TO postgres;

--
-- Name: claim_treasury_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.claim_treasury_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.claim_treasury_ptid_seq OWNER TO postgres;

--
-- Name: claim_treasury_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.claim_treasury_ptid_seq OWNED BY universe_dw.claim_treasury.ptid;


--
-- Name: commercial_other_bills_purchased; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.commercial_other_bills_purchased (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    security_number character varying(200),
    bill_holder character varying(200),
    cr_rating_borrower character varying(200),
    grades_unrated_banks character varying(200),
    bill_type character varying(200),
    bill_type_subcategory character varying(200),
    transaction_date character varying(200),
    value_date character varying(200),
    maturity_date character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    usd_amount character varying(200),
    bill_bearer character varying(200),
    issuer_credit_rating character varying(200),
    issuer_country character varying(200),
    collateral_pledged character varying(200),
    past_due_days character varying(200),
    provision character varying(200),
    asset_classification_category character varying(200),
    sector_sna_classification character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.commercial_other_bills_purchased OWNER TO postgres;

--
-- Name: commercial_other_bills_purchased_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.commercial_other_bills_purchased_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.commercial_other_bills_purchased_ptid_seq OWNER TO postgres;

--
-- Name: commercial_other_bills_purchased_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.commercial_other_bills_purchased_ptid_seq OWNED BY universe_dw.commercial_other_bills_purchased.ptid;


--
-- Name: company_info; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.company_info (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    customer_identification_number character varying(200),
    smr_code_non_government character varying(200),
    account_number character varying(200),
    currency character varying(200),
    account_operation_status character varying(200),
    establishment_date character varying(200),
    legal_form character varying(200),
    negative_client_status character varying(200),
    number_of_employees_male character varying(200),
    number_of_employees_female character varying(200),
    registration_country character varying(200),
    registration_number character varying(200),
    tax_identification_number character varying(200),
    trade_name character varying(200),
    parent_name character varying(200),
    parent_incorporation_number character varying(200),
    group_id character varying(200),
    sector_classification_sna character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.company_info OWNER TO postgres;

--
-- Name: company_info_business_address; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.company_info_business_address (
    ptid bigint NOT NULL,
    postal_code character varying(200),
    region character varying(200),
    district character varying(200),
    ward character varying(200),
    street character varying(200),
    house_number character varying(200)
);


ALTER TABLE universe_dw.company_info_business_address OWNER TO postgres;

--
-- Name: company_info_business_address_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.company_info_business_address_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.company_info_business_address_ptid_seq OWNER TO postgres;

--
-- Name: company_info_business_address_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.company_info_business_address_ptid_seq OWNED BY universe_dw.company_info_business_address.ptid;


--
-- Name: company_info_contact; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.company_info_contact (
    ptid bigint NOT NULL,
    mobile_number character varying(200),
    alternative_mobile_number character varying(200),
    fixed_line_number character varying(200),
    fax_number character varying(200),
    email_address character varying(200),
    social_media character varying(200)
);


ALTER TABLE universe_dw.company_info_contact OWNER TO postgres;

--
-- Name: company_info_contact_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.company_info_contact_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.company_info_contact_ptid_seq OWNER TO postgres;

--
-- Name: company_info_contact_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.company_info_contact_ptid_seq OWNED BY universe_dw.company_info_contact.ptid;


--
-- Name: company_info_pri_address; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.company_info_pri_address (
    ptid bigint NOT NULL,
    primary_postal_code character varying(200),
    primary_region character varying(200),
    primary_district character varying(200),
    primary_ward character varying(200),
    primary_street character varying(200),
    primary_house_number character varying(200),
    country character varying(200),
    postal_office_box character varying(200),
    zip_code character varying(200)
);


ALTER TABLE universe_dw.company_info_pri_address OWNER TO postgres;

--
-- Name: company_info_pri_address_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.company_info_pri_address_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.company_info_pri_address_ptid_seq OWNER TO postgres;

--
-- Name: company_info_pri_address_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.company_info_pri_address_ptid_seq OWNED BY universe_dw.company_info_pri_address.ptid;


--
-- Name: company_info_related_person; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.company_info_related_person (
    ptid bigint NOT NULL,
    cell_phone character varying(200),
    full_name character varying(200),
    gender character varying(200),
    relation_type character varying(200),
    national_id character varying(200),
    nationality character varying(200),
    appointment_date character varying(200),
    termination_date character varying(200),
    rate_value_of_shares_owned character varying(200),
    amount_value_of_shares_owned character varying(200)
);


ALTER TABLE universe_dw.company_info_related_person OWNER TO postgres;

--
-- Name: company_info_rel_person_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.company_info_rel_person_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.company_info_rel_person_ptid_seq OWNER TO postgres;

--
-- Name: company_info_rel_person_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.company_info_rel_person_ptid_seq OWNED BY universe_dw.company_info_related_person.ptid;


--
-- Name: company_info_relation_entity; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.company_info_relation_entity (
    ptid bigint NOT NULL,
    entity_name character varying(200),
    entity_type character varying(200),
    certificate_incorporation character varying(200),
    group_parent_code character varying(200),
    share_owned_percentage character varying(200),
    share_owned_amount character varying(200),
    postal_code character varying(200),
    region character varying(200),
    district character varying(200),
    ward character varying(200),
    street character varying(200),
    house_number character varying(200)
);


ALTER TABLE universe_dw.company_info_relation_entity OWNER TO postgres;

--
-- Name: company_info_relation_entity_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.company_info_relation_entity_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.company_info_relation_entity_ptid_seq OWNER TO postgres;

--
-- Name: company_info_relation_entity_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.company_info_relation_entity_ptid_seq OWNED BY universe_dw.company_info_relation_entity.ptid;


--
-- Name: company_info_sec_address; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.company_info_sec_address (
    ptid bigint NOT NULL,
    secondary_postal_code character varying(200),
    secondary_region character varying(200),
    secondary_district character varying(200),
    secondary_ward character varying(200),
    secondary_street character varying(200),
    secondary_house_number character varying(200),
    country character varying(200),
    structured_address character varying(200),
    text_address character varying(200)
);


ALTER TABLE universe_dw.company_info_sec_address OWNER TO postgres;

--
-- Name: company_info_sec_address_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.company_info_sec_address_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.company_info_sec_address_ptid_seq OWNER TO postgres;

--
-- Name: company_info_sec_address_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.company_info_sec_address_ptid_seq OWNED BY universe_dw.company_info_sec_address.ptid;


--
-- Name: company_information_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.company_information_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.company_information_ptid_seq OWNER TO postgres;

--
-- Name: company_information_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.company_information_ptid_seq OWNED BY universe_dw.company_info.ptid;


--
-- Name: complaint_fraud_statistics; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.complaint_fraud_statistics (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    complainant_name character varying(200),
    complainant_mobile character varying(200),
    complaint_type character varying(200),
    occurance_date character varying(200),
    complaint_reporting_date character varying(200),
    closure_date character varying(200),
    agent_name character varying(200),
    till_number character varying(200),
    currency character varying(200),
    tzs_amount character varying(200),
    employee_id character varying(200),
    referred_complaints character varying(200),
    complaint_status character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.complaint_fraud_statistics OWNER TO postgres;

--
-- Name: complaint_fraud_statistics_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.complaint_fraud_statistics_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.complaint_fraud_statistics_ptid_seq OWNER TO postgres;

--
-- Name: complaint_fraud_statistics_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.complaint_fraud_statistics_ptid_seq OWNED BY universe_dw.complaint_fraud_statistics.ptid;


--
-- Name: complaints_fraud_statistics; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.complaints_fraud_statistics (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    policy_number character varying(200),
    complaint_nature character varying(200),
    occurance_date character varying(200),
    complaint_reporting_date character varying(200),
    closure_date character varying(200),
    currency character varying(200),
    tzs_s_amount character varying(200),
    complaint_status character varying(200),
    complaints_referred character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.complaints_fraud_statistics OWNER TO postgres;

--
-- Name: complaints_fraud_statistics_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.complaints_fraud_statistics_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.complaints_fraud_statistics_ptid_seq OWNER TO postgres;

--
-- Name: complaints_fraud_statistics_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.complaints_fraud_statistics_ptid_seq OWNED BY universe_dw.complaints_fraud_statistics.ptid;


--
-- Name: core_capital_deductions; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.core_capital_deductions (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    transaction_date character varying(200),
    deductions_type character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.core_capital_deductions OWNER TO postgres;

--
-- Name: core_capital_deductions_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.core_capital_deductions_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.core_capital_deductions_ptid_seq OWNER TO postgres;

--
-- Name: core_capital_deductions_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.core_capital_deductions_ptid_seq OWNED BY universe_dw.core_capital_deductions.ptid;


--
-- Name: currency_swap; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.currency_swap (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    contract_date character varying(200),
    maturity_date character varying(200),
    counterpart_name character varying(200),
    relationship_type character varying(200),
    cr_rating_counter_part character varying(200),
    grades_unrated_counter_part character varying(200),
    currency_a character varying(200),
    currency_b character varying(200),
    org_amount_currency_a character varying(200),
    tzs_amount_currency_a character varying(200),
    spot_exchange_rate_currency_ab character varying(200),
    org_amount_currency_b character varying(200),
    tzs_amount_currency_b character varying(200),
    exchange_rate_currency_a_2_tzs character varying(200),
    exchange_rate_currency_b_2_tzs character varying(200),
    foward_exchange_rate character varying(200),
    foward_exchange_rate_currency_a_2_tzs character varying(200),
    foward_exchange_rate_currency_b_2_tzs character varying(200),
    transaction_date character varying(200),
    tzs_foward_currency_a character varying(200),
    tzs_foward_currency_b character varying(200),
    value_date character varying(200),
    cr_rating_counterpart character varying(200),
    transaction_type character varying(200),
    sector_sna_classification character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.currency_swap OWNER TO postgres;

--
-- Name: currency_swap_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.currency_swap_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.currency_swap_ptid_seq OWNER TO postgres;

--
-- Name: currency_swap_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.currency_swap_ptid_seq OWNED BY universe_dw.currency_swap.ptid;


--
-- Name: customer_liabilities; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.customer_liabilities (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    draft_holder character varying(200),
    transaction_date character varying(200),
    value_date character varying(200),
    maturity_date character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    usd_amount character varying(200),
    collateral_pledged character varying(200),
    past_due_days character varying(200),
    provision character varying(200),
    asset_classification_category character varying(200),
    sector_sna_classification character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.customer_liabilities OWNER TO postgres;

--
-- Name: customer_liabilities_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.customer_liabilities_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.customer_liabilities_ptid_seq OWNER TO postgres;

--
-- Name: customer_liabilities_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.customer_liabilities_ptid_seq OWNED BY universe_dw.customer_liabilities.ptid;


--
-- Name: deposit_information; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.deposit_information (
    ptid bigint NOT NULL,
    account_number character varying(200),
    account_name character varying(200),
    customer_category character varying(200),
    branch_code character varying(200),
    district_name character varying(200),
    region character varying(200),
    account_product_name character varying(200),
    account_type_saving character varying(200),
    deposit_category_public character varying(200),
    deposit_account_status_true character varying(200),
    reporting_date timestamp(0) without time zone NOT NULL,
    client_identification_number character varying(200),
    customer_country character varying(200),
    client_type character varying(200),
    relationship_type character varying(200),
    transaction_unique_ref character varying(200),
    time_stamp character varying(200),
    service_channel_mobile_banking character varying(200),
    currency character varying(200),
    org_amount_opening character varying(200),
    usd_amount_opening character varying(200),
    tzs_amount_opening character varying(200),
    org_amount_deposit character varying(200),
    usd_amount_deposit character varying(200),
    tzs_amount_deposit character varying(200),
    org_amount_withdraw character varying(200),
    usd_amount_withdraw character varying(200),
    tzs_amount_withdraw character varying(200),
    org_amount_closing character varying(200),
    usd_amount_closing character varying(200),
    tzs_amount_closing character varying(200),
    sector_sna_classification character varying(200),
    lien_number character varying(200),
    org_amount_lien character varying(200),
    usd_amount_lien character varying(200),
    tzs_amount_lien character varying(200),
    contract_date character varying(200),
    maturity_date character varying(200),
    annual_interest_rate character varying(200),
    interest_rate_type character varying(200),
    org_interest_amount character varying(200),
    usd_interest_amount character varying(200),
    tzs_interest_amount character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.deposit_information OWNER TO postgres;

--
-- Name: deposit_information_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.deposit_information_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.deposit_information_ptid_seq OWNER TO postgres;

--
-- Name: deposit_information_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.deposit_information_ptid_seq OWNED BY universe_dw.deposit_information.ptid;


--
-- Name: digital_credit; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.digital_credit (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    customer_name character varying(200),
    gender_male character varying(200),
    disability_status character varying(200),
    customer_identification_number character varying(200),
    institution_name character varying(200),
    branch_name character varying(200),
    services_facilitator character varying(200),
    product_name character varying(200),
    tzs_loan_disbursed_amount character varying(200),
    loan_disbursement_date character varying(200),
    tzs_loan_balance character varying(200),
    maturity_date character varying(200),
    loan_id character varying(200),
    last_deposit_date character varying(200),
    last_deposit_amount character varying(200),
    payments_installment character varying(200),
    repayments_frequency character varying(200),
    loan_amotization_type character varying(200),
    cycle_number character varying(200),
    loan_amount_paid character varying(200),
    deliquence_date character varying(200),
    restructuring_date character varying(200),
    interest_rate character varying(200),
    past_due_days character varying(200),
    past_due_amount character varying(200),
    currency character varying(200),
    org_accrued_interest character varying(200),
    tzs_accrued_interest character varying(200),
    usd_accrued_interest character varying(200),
    classification character varying(200),
    provision character varying(200),
    interest_suspended character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.digital_credit OWNER TO postgres;

--
-- Name: digital_credit_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.digital_credit_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.digital_credit_ptid_seq OWNER TO postgres;

--
-- Name: digital_credit_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.digital_credit_ptid_seq OWNED BY universe_dw.digital_credit.ptid;


--
-- Name: digital_saving; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.digital_saving (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    customer_identification_number character varying(200),
    customer_name character varying(200),
    gender_male character varying(200),
    disability_status character varying(200),
    bank_name character varying(200),
    branch_code character varying(200),
    services_facilitator character varying(200),
    product_name character varying(200),
    transaction_type character varying(200),
    transaction_date character varying(200),
    currency character varying(200),
    org_deposit_amount character varying(200),
    usd_deposit_amount character varying(200),
    tzs_deposit_amount character varying(200),
    org_transaction_amount character varying(200),
    usd_transaction_amount character varying(200),
    tzs_transaction_amount character varying(200),
    org_deposit_balance character varying(200),
    usd_deposit_balance character varying(200),
    tzs_deposit_balance character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.digital_saving OWNER TO postgres;

--
-- Name: digital_saving_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.digital_saving_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.digital_saving_ptid_seq OWNER TO postgres;

--
-- Name: digital_saving_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.digital_saving_ptid_seq OWNED BY universe_dw.digital_saving.ptid;


--
-- Name: dividends_payable; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.dividends_payable (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    dividend_type character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.dividends_payable OWNER TO postgres;

--
-- Name: dividends_payable_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.dividends_payable_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.dividends_payable_ptid_seq OWNER TO postgres;

--
-- Name: dividends_payable_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.dividends_payable_ptid_seq OWNED BY universe_dw.dividends_payable.ptid;


--
-- Name: equity_derivatives; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.equity_derivatives (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    contract_date character varying(200),
    maturity_date character varying(200),
    counterpart_name character varying(200),
    cr_rating_counterpart character varying(200),
    grades_unrated_counter_part character varying(200),
    relationship_type character varying(200),
    equity_derivatives_category character varying(200),
    sector_sna_classification character varying(200),
    counterpart_country character varying(200),
    currency character varying(200),
    org_contract_amount character varying(200),
    tzs_contract_amount character varying(200),
    fixed_interest_rate character varying(200),
    tzs_start_stock_price_amount character varying(200),
    org_stock_price_amount character varying(200),
    tzs_stock_price_amount character varying(200),
    trading_intent character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.equity_derivatives OWNER TO postgres;

--
-- Name: equity_derivatives_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.equity_derivatives_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.equity_derivatives_ptid_seq OWNER TO postgres;

--
-- Name: equity_derivatives_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.equity_derivatives_ptid_seq OWNED BY universe_dw.equity_derivatives.ptid;


--
-- Name: equity_investment; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.equity_investment (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    nameof_investee character varying(200),
    country_of_investee character varying(200),
    obligor_external_credit_rating character varying(200),
    grades_unrated_banks character varying(200),
    sector_sna_classification character varying(200),
    relationship character varying(200),
    sna_classification character varying(200),
    number_shares_purchased character varying(200),
    equity_investment_category character varying(200),
    currency character varying(200),
    org_purchase_price character varying(200),
    tzs_purchase_price character varying(200),
    usd_purchase_price character varying(200),
    org_purchased_book_value_shares character varying(200),
    tzs_purchased_book_value_shares character varying(200),
    usd_purchased_book_value_shares character varying(200),
    org_purchased_market_value_shares character varying(200),
    tzs_purchased_market_value_shares character varying(200),
    usd_purchased_market_value_shares character varying(200),
    number_paid_up_equity_shares character varying(200),
    org_value_paid_up_equity_shares character varying(200),
    tzs_value_paid_up_equity_shares character varying(200),
    usd_value_paid_up_equity_shares character varying(200),
    trading_intent character varying(200),
    provision character varying(200),
    asset_classification_category character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.equity_investment OWNER TO postgres;

--
-- Name: equity_investment_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.equity_investment_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.equity_investment_ptid_seq OWNER TO postgres;

--
-- Name: equity_investment_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.equity_investment_ptid_seq OWNED BY universe_dw.equity_investment.ptid;


--
-- Name: export_letters_credit; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.export_letters_credit (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    opening_date character varying(200),
    maturity_date character varying(200),
    holder_name character varying(200),
    relationship_type character varying(200),
    beneficiary_name character varying(200),
    beneficiary_country character varying(200),
    cr_rating_counter_foreign_bank character varying(200),
    gradesfor_unrated_foreign_bank character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    asset_classification_type character varying(200),
    sector_sna_classification character varying(200),
    past_due_days character varying(200),
    provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.export_letters_credit OWNER TO postgres;

--
-- Name: export_letters_credit_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.export_letters_credit_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.export_letters_credit_ptid_seq OWNER TO postgres;

--
-- Name: export_letters_credit_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.export_letters_credit_ptid_seq OWNED BY universe_dw.export_letters_credit.ptid;


--
-- Name: foreign_term_debt; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.foreign_term_debt (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    client_identification_number character varying(200),
    borrower_name character varying(200),
    creditor_name character varying(200),
    org_country character varying(200),
    credit_type_letter_of_credit character varying(200),
    debt_registration_number character varying(200),
    borrower_account_number character varying(200),
    sector_borrower_sna_classification character varying(200),
    loan_contract_date character varying(200),
    loan_receipt_date character varying(200),
    loan_maturity_date character varying(200),
    annual_interest_rate character varying(200),
    currency character varying(200),
    org_loan_receipt_amount character varying(200),
    tzs_loan_receipt_amount character varying(200),
    instalment_remittance_date character varying(200),
    org_principal_instalment_payment_amount character varying(200),
    org_interest_instalment_payment_amount character varying(200),
    tzs_principal_instalment_payment_amount character varying(200),
    tzs_interest_instalment_payment_amount character varying(200),
    org_arrears_principal_amount character varying(200),
    org_arrears_interest_amount character varying(200),
    tzs_arrears_principal_amount character varying(200),
    tzs_arrears_interest_amount character varying(200),
    org_principal_amount_paid character varying(200),
    tzs_principal_amount_paid character varying(200),
    org_interest_amount_paid character varying(200),
    tzs_interest_amount_paid character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.foreign_term_debt OWNER TO postgres;

--
-- Name: foreign_term_debt_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.foreign_term_debt_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.foreign_term_debt_ptid_seq OWNER TO postgres;

--
-- Name: foreign_term_debt_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.foreign_term_debt_ptid_seq OWNED BY universe_dw.foreign_term_debt.ptid;


--
-- Name: ibcm_transaction; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.ibcm_transaction (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    transaction_date character varying(200),
    lender_name character varying(200),
    borrower_name character varying(200),
    transaction_type character varying(200),
    tzs_amount character varying(200),
    tenure character varying(200),
    interest_rate character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.ibcm_transaction OWNER TO postgres;

--
-- Name: ibcm_transaction_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.ibcm_transaction_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.ibcm_transaction_ptid_seq OWNER TO postgres;

--
-- Name: ibcm_transaction_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.ibcm_transaction_ptid_seq OWNED BY universe_dw.ibcm_transaction.ptid;


--
-- Name: ifem_quotes; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.ifem_quotes (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    bank_code character varying(200),
    counterparty_name character varying(200),
    transaction_date character varying(200),
    currency character varying(200),
    tzs_bid_price character varying(200),
    tzs_ask_price character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.ifem_quotes OWNER TO postgres;

--
-- Name: ifem_quotes_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.ifem_quotes_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.ifem_quotes_ptid_seq OWNER TO postgres;

--
-- Name: ifem_quotes_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.ifem_quotes_ptid_seq OWNED BY universe_dw.ifem_quotes.ptid;


--
-- Name: ifem_transaction; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.ifem_transaction (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    transaction_date character varying(200),
    value_date character varying(200),
    market_type character varying(200),
    seller_name character varying(200),
    buyer_name character varying(200),
    sector_sna_classification character varying(200),
    buyer_economic_activity character varying(200),
    buyer_country character varying(200),
    org_currency character varying(200),
    exchange_rate character varying(200),
    org_amount_offered character varying(200),
    org_amount_sold character varying(200),
    tzs_amount_offered character varying(200),
    tzs_amount_sold character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.ifem_transaction OWNER TO postgres;

--
-- Name: ifem_transaction_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.ifem_transaction_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.ifem_transaction_ptid_seq OWNER TO postgres;

--
-- Name: ifem_transaction_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.ifem_transaction_ptid_seq OWNED BY universe_dw.ifem_transaction.ptid;


--
-- Name: income_statement; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.income_statement (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    interest_income character varying(200),
    interest_expense character varying(200),
    bad_debts_written_off_not_provided character varying(200),
    provision_bad_doubtful_debts character varying(200),
    impairments_investments character varying(200),
    non_interest_income character varying(200),
    non_interest_expenses character varying(200),
    income_tax_provision character varying(200),
    extraordinary_credits_charge character varying(200),
    non_core_credits_charges character varying(200),
    amount_interest_income character varying(200),
    amount_interest_expenses character varying(200),
    amount_non_interest_income character varying(200),
    amount_non_interest_expenses character varying(200),
    amountnon_core_credits_charges character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.income_statement OWNER TO postgres;

--
-- Name: income_statement_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.income_statement_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.income_statement_ptid_seq OWNER TO postgres;

--
-- Name: income_statement_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.income_statement_ptid_seq OWNED BY universe_dw.income_statement.ptid;


--
-- Name: individual_pri_address; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.individual_pri_address (
    ptid bigint NOT NULL,
    primary_postal_code character varying(200),
    primary_region character varying(200),
    primary_district character varying(200),
    primary_ward character varying(200),
    primary_street character varying(200),
    primary_house_number character varying(200),
    primary_country character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.individual_pri_address OWNER TO postgres;

--
-- Name: individual_address_info_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.individual_address_info_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.individual_address_info_ptid_seq OWNER TO postgres;

--
-- Name: individual_address_info_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.individual_address_info_ptid_seq OWNED BY universe_dw.individual_pri_address.ptid;


--
-- Name: individual_birth_info; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.individual_birth_info (
    ptid bigint NOT NULL,
    birth_postal_code character varying(200),
    birth_region character varying(200),
    birth_district character varying(200),
    birth_ward character varying(200),
    birth_street character varying(200),
    birth_house_number character varying(200),
    birth_date character varying(200),
    birth_country character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.individual_birth_info OWNER TO postgres;

--
-- Name: individual_birth_info_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.individual_birth_info_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.individual_birth_info_ptid_seq OWNER TO postgres;

--
-- Name: individual_birth_info_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.individual_birth_info_ptid_seq OWNED BY universe_dw.individual_birth_info.ptid;


--
-- Name: individual_contact_info; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.individual_contact_info (
    ptid bigint NOT NULL,
    mobile_number character varying(200),
    alternative_mobile_number character varying(200),
    fixed_line_number character varying(200),
    fax_number character varying(200),
    email_address character varying(200),
    social_media character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.individual_contact_info OWNER TO postgres;

--
-- Name: individual_contact_info_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.individual_contact_info_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.individual_contact_info_ptid_seq OWNER TO postgres;

--
-- Name: individual_contact_info_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.individual_contact_info_ptid_seq OWNED BY universe_dw.individual_contact_info.ptid;


--
-- Name: individual_employer_info; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.individual_employer_info (
    ptid bigint NOT NULL,
    employer_postal_code character varying(200),
    employer_region character varying(200),
    employer_district character varying(200),
    employer_ward character varying(200),
    employer_street character varying(200),
    employer_house_number character varying(200),
    employer_name character varying(200),
    business_nature character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.individual_employer_info OWNER TO postgres;

--
-- Name: individual_employer_info_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.individual_employer_info_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.individual_employer_info_ptid_seq OWNER TO postgres;

--
-- Name: individual_employer_info_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.individual_employer_info_ptid_seq OWNED BY universe_dw.individual_employer_info.ptid;


--
-- Name: individual_enterprenuer_info; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.individual_enterprenuer_info (
    ptid bigint NOT NULL,
    business_name character varying(200),
    establishment_date character varying(200),
    business_registration_number character varying(200),
    business_registration_date character varying(200),
    business_license_number character varying(200),
    tax_identification_number character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.individual_enterprenuer_info OWNER TO postgres;

--
-- Name: individual_enterprenuer_info_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.individual_enterprenuer_info_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.individual_enterprenuer_info_ptid_seq OWNER TO postgres;

--
-- Name: individual_enterprenuer_info_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.individual_enterprenuer_info_ptid_seq OWNED BY universe_dw.individual_enterprenuer_info.ptid;


--
-- Name: individual_ident_info; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.individual_ident_info (
    ptid bigint NOT NULL,
    identification_type character varying(200),
    registration_number character varying(200),
    issuance_date character varying(200),
    issuance_expiration_date character varying(200),
    issuance_location character varying(200),
    issuing_authority character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.individual_ident_info OWNER TO postgres;

--
-- Name: individual_ident_info_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.individual_ident_info_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.individual_ident_info_ptid_seq OWNER TO postgres;

--
-- Name: individual_ident_info_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.individual_ident_info_ptid_seq OWNED BY universe_dw.individual_ident_info.ptid;


--
-- Name: individual_info; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.individual_info (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    customer_identification_number character varying(200),
    account_number character varying(200),
    currency character varying(200),
    account_operation_status character varying(200),
    classification character varying(200),
    smr_code character varying(200),
    negative_client_status character varying(200),
    first_name character varying(200),
    middle_names character varying(200),
    other_names character varying(200),
    full_names character varying(200),
    present_surname character varying(200),
    birth_surname character varying(200),
    gender_male character varying(200),
    marital_status character varying(200),
    number_spouse character varying(200),
    spouses_full_name character varying(200),
    spouse_identification_type character varying(200),
    maiden_name character varying(200),
    nationality character varying(200),
    citizenship character varying(200),
    residency character varying(200),
    profession character varying(200),
    social_status character varying(200),
    employer_status character varying(200),
    employer_name character varying(200),
    monthly_income character varying(200),
    monthly_expenses character varying(200),
    number_of_dependants character varying(200),
    education_level character varying(200),
    average_monthly_expenditure character varying(200),
    status character varying(200),
    sna_sector_classification character varying(200),
    fate_status character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.individual_info OWNER TO postgres;

--
-- Name: individual_information_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.individual_information_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.individual_information_ptid_seq OWNER TO postgres;

--
-- Name: individual_information_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.individual_information_ptid_seq OWNED BY universe_dw.individual_info.ptid;


--
-- Name: individual_sec_address; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.individual_sec_address (
    ptid bigint NOT NULL,
    secondary_postal_code character varying(200),
    secondary_region character varying(200),
    secondary_district character varying(200),
    secondary_ward character varying(200),
    secondary_street character varying(200),
    secondary_house_number character varying(200),
    secondary_country character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.individual_sec_address OWNER TO postgres;

--
-- Name: individual_sec_address_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.individual_sec_address_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.individual_sec_address_ptid_seq OWNER TO postgres;

--
-- Name: individual_sec_address_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.individual_sec_address_ptid_seq OWNED BY universe_dw.individual_sec_address.ptid;


--
-- Name: institution_premises; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.institution_premises (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    asset_category character varying(200),
    usage_of_premises_furnitur_and_equipment character varying(200),
    acquisition_date character varying(200),
    asset_type character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    usd_amount character varying(200),
    tzs_amount character varying(200),
    disposal_date character varying(200),
    disposed_asset_value character varying(200),
    org_depreciation character varying(200),
    usd_depreciation character varying(200),
    tzs_depreciation character varying(200),
    org_accum_depr_impairment character varying(200),
    usd_accum_depr_impairment character varying(200),
    tzs_accum_depr_impairment character varying(200),
    org_net_book_value character varying(200),
    usd_net_book_value character varying(200),
    tzs_net_book_value character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.institution_premises OWNER TO postgres;

--
-- Name: institution_premises_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.institution_premises_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.institution_premises_ptid_seq OWNER TO postgres;

--
-- Name: institution_premises_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.institution_premises_ptid_seq OWNED BY universe_dw.institution_premises.ptid;


--
-- Name: insurance_claim; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.insurance_claim (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    policy_number character varying(200),
    insurer_status character varying(200),
    claim_ref_number character varying(200),
    claim_nature character varying(200),
    currency character varying(200),
    org_claim_amount character varying(200),
    tzs_sum_claim_amount character varying(200),
    org_paid_claim_amount character varying(200),
    tzs_paid_claim_amount character varying(200),
    incident_occurence_date character varying(200),
    incident_reporting_date character varying(200),
    claim_date character varying(200),
    claim_status_open character varying(200),
    repudiation_reason character varying(200),
    claim_closure_date character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.insurance_claim OWNER TO postgres;

--
-- Name: insurance_claim_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.insurance_claim_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.insurance_claim_ptid_seq OWNER TO postgres;

--
-- Name: insurance_claim_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.insurance_claim_ptid_seq OWNED BY universe_dw.insurance_claim.ptid;


--
-- Name: insurance_commission; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.insurance_commission (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    policy_number character varying(200),
    currency character varying(200),
    org_commission_received_amount character varying(200),
    tzs_commission_received_amount character varying(200),
    commission_received_date character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.insurance_commission OWNER TO postgres;

--
-- Name: insurance_commission_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.insurance_commission_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.insurance_commission_ptid_seq OWNER TO postgres;

--
-- Name: insurance_commission_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.insurance_commission_ptid_seq OWNED BY universe_dw.insurance_commission.ptid;


--
-- Name: insurance_underwritting; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.insurance_underwritting (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    customer_identification_number character varying(200),
    policy_number character varying(200),
    client_name character varying(200),
    insurer_name character varying(200),
    insurer_status character varying(200),
    client_country character varying(200),
    insurance_business_type character varying(200),
    class_business character varying(200),
    sub_class_business_01 character varying(200),
    sub_class_business_02 character varying(200),
    insurance_product_name character varying(200),
    gender character varying(200),
    disability character varying(200),
    client_type character varying(200),
    related_party character varying(200),
    relationship_category character varying(200),
    branch_name character varying(200),
    branch_code character varying(200),
    region character varying(200),
    district_name character varying(200),
    responsible_officer character varying(200),
    responsible_supervisor character varying(200),
    currency character varying(200),
    org_sum_insured_amount character varying(200),
    tzs_sum_insured_amount character varying(200),
    frequency_premium character varying(200),
    commision_rate character varying(200),
    policy_start_date character varying(200),
    policy_maturity_date character varying(200),
    sector_sna_classfication character varying(200),
    economic_activity character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.insurance_underwritting OWNER TO postgres;

--
-- Name: insurance_underwritting_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.insurance_underwritting_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.insurance_underwritting_ptid_seq OWNER TO postgres;

--
-- Name: insurance_underwritting_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.insurance_underwritting_ptid_seq OWNED BY universe_dw.insurance_underwritting.ptid;


--
-- Name: inter_branch_float_item; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.inter_branch_float_item (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    branch_name character varying(200),
    branch_code character varying(200),
    currency character varying(200),
    org_amount_float character varying(200),
    tzs_amount_float character varying(200),
    usd_amount_float character varying(200),
    past_due_days character varying(200),
    allowance_probable_loss character varying(200),
    classification character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.inter_branch_float_item OWNER TO postgres;

--
-- Name: inter_branch_float_item_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.inter_branch_float_item_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.inter_branch_float_item_ptid_seq OWNER TO postgres;

--
-- Name: inter_branch_float_item_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.inter_branch_float_item_ptid_seq OWNED BY universe_dw.inter_branch_float_item.ptid;


--
-- Name: interbank_loan_payable; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.interbank_loan_payable (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    lender_name character varying(200),
    account_number character varying(200),
    lender_country character varying(200),
    borrowering_type character varying(200),
    transaction_date character varying(200),
    disbursement_date character varying(200),
    maturity_date character varying(200),
    currency character varying(200),
    org_amount_opening character varying(200),
    tzs_amount_opening character varying(200),
    usd_amount_opening character varying(200),
    org_amount_repayment character varying(200),
    tzs_amount_repayment character varying(200),
    usd_amount_repayment character varying(200),
    org_amount_closing character varying(200),
    tzs_amount_closing character varying(200),
    usd_amount_closing character varying(200),
    tenure_days character varying(200),
    annual_interest_rate character varying(200),
    interest_rate_type character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.interbank_loan_payable OWNER TO postgres;

--
-- Name: interbank_loan_payable_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.interbank_loan_payable_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.interbank_loan_payable_ptid_seq OWNER TO postgres;

--
-- Name: interbank_loan_payable_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.interbank_loan_payable_ptid_seq OWNED BY universe_dw.interbank_loan_payable.ptid;


--
-- Name: interbank_loans_receivable; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.interbank_loans_receivable (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    borrowers_name character varying(200),
    borrowers_country character varying(200),
    relationship_type character varying(200),
    external_rating_correspondent_borrower character varying(200),
    grades_unrated_borrower character varying(200),
    loan_type character varying(200),
    issue_date character varying(200),
    loan_maturity_date character varying(200),
    currency character varying(200),
    org_loan_amount character varying(200),
    tzs_loan_amount character varying(200),
    usd_loan_amount character varying(200),
    interest_rate character varying(200),
    past_due_days character varying(200),
    org_accrued_interest_amount character varying(200),
    tzs_accrued_interest_amount character varying(200),
    allowance_probable_loss character varying(200),
    asset_classification character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.interbank_loans_receivable OWNER TO postgres;

--
-- Name: interbank_loans_receivable_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.interbank_loans_receivable_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.interbank_loans_receivable_ptid_seq OWNER TO postgres;

--
-- Name: interbank_loans_receivable_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.interbank_loans_receivable_ptid_seq OWNED BY universe_dw.interbank_loans_receivable.ptid;


--
-- Name: interest_rate_futures; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.interest_rate_futures (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    contract_date character varying(200),
    expiry_date character varying(200),
    underlying_asset_type character varying(200),
    counterpart_name character varying(200),
    counterpart_country character varying(200),
    relationship_type character varying(200),
    cr_rating_counterpart character varying(200),
    grades_unrated_counter_part character varying(200),
    currency character varying(200),
    org_contract_start_amount character varying(200),
    tzs_contract_start_amount character varying(200),
    org_contract_close_amount character varying(200),
    tzs_contract_close_amount character varying(200),
    org_margin_acc_start_amount character varying(200),
    tzs_margin_acc_start_amount character varying(200),
    org_margin_acc_close_amount character varying(200),
    tzs_margin_acc_close_amount character varying(200),
    fixed_interest_rate character varying(200),
    float_interest_rate character varying(200),
    libor_rate character varying(200),
    tax_rate character varying(200),
    arrangement_fee character varying(200),
    sector_sna_classification character varying(200),
    trading_intent character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.interest_rate_futures OWNER TO postgres;

--
-- Name: interest_rate_futures_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.interest_rate_futures_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.interest_rate_futures_ptid_seq OWNER TO postgres;

--
-- Name: interest_rate_futures_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.interest_rate_futures_ptid_seq OWNED BY universe_dw.interest_rate_futures.ptid;


--
-- Name: interest_rate_swap; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.interest_rate_swap (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    contract_date character varying(200),
    maturity_date character varying(200),
    counterpart_name character varying(200),
    counterpart_country character varying(200),
    relationship_type character varying(200),
    cr_rating_counterpart character varying(200),
    gradesfor_unrated_counter_part character varying(200),
    currency character varying(200),
    org_contract_amount character varying(200),
    tzs_contract_amount character varying(200),
    fixed_interest_rate character varying(200),
    float_interest_rate character varying(200),
    libor_rate character varying(200),
    tax_rate character varying(200),
    arrangement_fee character varying(200),
    sector_sna_classification character varying(200),
    trading_intent character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.interest_rate_swap OWNER TO postgres;

--
-- Name: interest_rate_swap_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.interest_rate_swap_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.interest_rate_swap_ptid_seq OWNER TO postgres;

--
-- Name: interest_rate_swap_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.interest_rate_swap_ptid_seq OWNED BY universe_dw.interest_rate_swap.ptid;


--
-- Name: interest_trust_account; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.interest_trust_account (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    trust_account_number character varying(200),
    trust_account_name character varying(200),
    bank_name character varying(200),
    currency character varying(200),
    interest_trust_account_balance character varying(200),
    interest_approved_for_distribution character varying(200),
    actual_interest_distributed_amount character varying(200),
    transaction_type character varying(200),
    undistributedinterest_amount character varying(200),
    transaction_date character varying(200),
    transaction_id character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.interest_trust_account OWNER TO postgres;

--
-- Name: interest_trust_account_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.interest_trust_account_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.interest_trust_account_ptid_seq OWNER TO postgres;

--
-- Name: interest_trust_account_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.interest_trust_account_ptid_seq OWNED BY universe_dw.interest_trust_account.ptid;


--
-- Name: internet_banking; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.internet_banking (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    customer_name character varying(200),
    gender character varying(200),
    account_status character varying(200),
    transaction_date character varying(200),
    last_transaction_date character varying(200),
    unique_identification_number character varying(200),
    customer_category character varying(200),
    transaction_type character varying(200),
    service_category character varying(200),
    sub_service_category character varying(200),
    transaction_ref character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    value_added_tax_amount character varying(200),
    excise_duty_amount character varying(200),
    electronic_levy_amount character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.internet_banking OWNER TO postgres;

--
-- Name: internet_banking_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.internet_banking_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.internet_banking_ptid_seq OWNER TO postgres;

--
-- Name: internet_banking_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.internet_banking_ptid_seq OWNED BY universe_dw.internet_banking.ptid;


--
-- Name: inv_debt_securities; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.inv_debt_securities (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    security_number character varying(200),
    security_type character varying(200),
    security_issuer_name character varying(200),
    external_issuer_ratting character varying(200),
    grades_unrated_banks character varying(200),
    security_issuer_country character varying(200),
    sna_issuer_sector character varying(200),
    currency character varying(200),
    org_cost_value_amount character varying(200),
    tzs_cost_value_amount character varying(200),
    usd_cost_value_amount character varying(200),
    org_face_value_amount character varying(200),
    tzsg_face_value_amount character varying(200),
    usdg_face_value_amount character varying(200),
    org_fair_value_amount character varying(200),
    tzsg_fair_value_amount character varying(200),
    usdg_fair_value_amount character varying(200),
    interest_rate character varying(200),
    purchase_date character varying(200),
    value_date character varying(200),
    maturity_date character varying(200),
    trading_intent character varying(200),
    security_encumbarance_status character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.inv_debt_securities OWNER TO postgres;

--
-- Name: inv_debt_securities_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.inv_debt_securities_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.inv_debt_securities_ptid_seq OWNER TO postgres;

--
-- Name: inv_debt_securities_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.inv_debt_securities_ptid_seq OWNED BY universe_dw.inv_debt_securities.ptid;


--
-- Name: inward_bills; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.inward_bills (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    opening_date character varying(200),
    maturity_date character varying(200),
    holder_name character varying(200),
    relationship_type character varying(200),
    beneficiary_name character varying(200),
    beneficiary_country character varying(200),
    cr_rating_counter_drawer_bank character varying(200),
    gradesfor_unrated_drawer_bank character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    asset_classification_type character varying(200),
    sna_classification character varying(200),
    past_due_days character varying(200),
    provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.inward_bills OWNER TO postgres;

--
-- Name: inward_bills_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.inward_bills_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.inward_bills_ptid_seq OWNER TO postgres;

--
-- Name: inward_bills_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.inward_bills_ptid_seq OWNED BY universe_dw.inward_bills.ptid;


--
-- Name: late_deposit_payments; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.late_deposit_payments (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    deposit_date character varying(200),
    depositor_name character varying(200),
    relationship_type character varying(200),
    grades_unrated_customer character varying(200),
    currency character varying(200),
    org_deposited_amount character varying(200),
    tzs_deposited_amount character varying(200),
    sector_sna_classification character varying(200),
    past_due_days character varying(200),
    impairment character varying(200),
    bot_provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.late_deposit_payments OWNER TO postgres;

--
-- Name: late_deposit_payments_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.late_deposit_payments_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.late_deposit_payments_ptid_seq OWNER TO postgres;

--
-- Name: late_deposit_payments_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.late_deposit_payments_ptid_seq OWNED BY universe_dw.late_deposit_payments.ptid;


--
-- Name: loan_information; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.loan_information (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    customer_identification_number character varying(200),
    account_number character varying(200),
    client_name character varying(200),
    country_of_borrower character varying(200),
    cr_rating_borrower character varying(200),
    grades_unrated_banks character varying(200),
    category_borrower character varying(200),
    gender_male character varying(200),
    disability character varying(200),
    client_type character varying(200),
    group_name character varying(200),
    group_code character varying(200),
    related_party character varying(200),
    relationship_category character varying(200),
    loan_number character varying(200),
    loan_type character varying(200),
    loan_economic_activity character varying(200),
    loan_phase character varying(200),
    transfer_status character varying(200),
    purpose_mortgage character varying(200),
    purpose_other_loans character varying(200),
    source_fund_mortgage character varying(200),
    amortization_type character varying(200),
    branch_name character varying(200),
    branch_code character varying(200),
    district_name character varying(200),
    region character varying(200),
    loan_officer character varying(200),
    loan_supervisor character varying(200),
    group_village_number character varying(200),
    cycle_number character varying(200),
    loan_installment character varying(200),
    frequency_of_repayment character varying(200),
    currency character varying(200),
    contact_date character varying(200),
    org_sanction_amount character varying(200),
    usd_sanction_amount character varying(200),
    tzs_sanction_amount character varying(200),
    org_disbursed_amount character varying(200),
    usd_disbursed_amount character varying(200),
    tzs_disbursed_amount character varying(200),
    disbursement_date character varying(200),
    maturity_date character varying(200),
    real_end_date character varying(200),
    restructuring_date character varying(200),
    org_outstanding_principal_amount character varying(200),
    usd_outstanding_principal_amount character varying(200),
    tzs_outstanding_principal_amount character varying(200),
    org_installment_amount character varying(200),
    usd_installment_amount character varying(200),
    tzs_installment_amount character varying(200),
    loan_installment_paid character varying(200),
    grace_period_payment_principal character varying(200),
    annual_interest_rate character varying(200),
    first_installment_payment_date character varying(200),
    last_payment_date character varying(200),
    collateral_pledged character varying(200),
    collateral_value character varying(200),
    loan_flag_type_restructured character varying(200),
    past_due_days character varying(200),
    past_due_amount character varying(200),
    org_accrued_interest_amount character varying(200),
    usd_accrued_interest_amount character varying(200),
    tzs_accrued_interest_amount character varying(200),
    org_penalty_charged_amount character varying(200),
    usd_penalty_charged_amount character varying(200),
    tzs_penalty_charged_amount character varying(200),
    org_penalty_paid_amount character varying(200),
    usd_penalty_paid_amount character varying(200),
    tzs_penalty_paid_amount character varying(200),
    org_loan_fees_charged_amount character varying(200),
    usd_loan_fees_charged_amount character varying(200),
    tzs_loan_fees_charged_amount character varying(200),
    org_tot_monthly_payment_amount character varying(200),
    usd_tot_monthly_payment_amount character varying(200),
    tzs_tot_monthly_payment_amount character varying(200),
    sector_sna_classification character varying(200),
    asset_classification_category character varying(200),
    neg_status_contract character varying(200),
    customer_role character varying(200),
    provision character varying(200),
    trading_intent character varying(200),
    suspended_interest character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.loan_information OWNER TO postgres;

--
-- Name: loan_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.loan_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.loan_ptid_seq OWNER TO postgres;

--
-- Name: loan_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.loan_ptid_seq OWNED BY universe_dw.loan_information.ptid;


--
-- Name: microfinance_segment_loans; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.microfinance_segment_loans (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    customer_identification_number character varying(200),
    account_number character varying(200),
    client_name character varying(200),
    client_category character varying(200),
    gender character varying(200),
    age character varying(200),
    disability_status character varying(200),
    loan_number character varying(200),
    loan_industry_classification character varying(200),
    loan_sub_industry character varying(200),
    microfinance_loans_type character varying(200),
    amortization_type character varying(200),
    branch_name character varying(200),
    branch_code character varying(200),
    loan_officer character varying(200),
    loan_supervisor character varying(200),
    group_village_number character varying(200),
    cycle_number character varying(200),
    currency character varying(200),
    org_sanction_amount character varying(200),
    tzs_sanction_amount character varying(200),
    usd_sanction_amount character varying(200),
    tzs_disbursed_amount character varying(200),
    org_disbursed_amount character varying(200),
    usd_disbursed_amount character varying(200),
    disbursement_date character varying(200),
    maturity_date character varying(200),
    restructuring_date character varying(200),
    write_off_date character varying(200),
    amount_written_off character varying(200),
    agreed_loan_installments character varying(200),
    repayment_frequency character varying(200),
    org_outstanding_principal_amount character varying(200),
    tzs_outstanding_principal_amount character varying(200),
    usd_outstanding_principal_amount character varying(200),
    loan_installment_paid character varying(200),
    grace_period_payment_principal character varying(200),
    annual_interest_rate character varying(200),
    first_installment_payment_date character varying(200),
    loan_collateral character varying(200),
    collateral_value character varying(200),
    loan_flag_type character varying(200),
    past_due_days character varying(200),
    past_due_amount character varying(200),
    org_accrued_interest_amount character varying(200),
    tzs_accrued_interest_amount character varying(200),
    usd_accrued_interest_amount character varying(200),
    asset_classification_category character varying(200),
    provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.microfinance_segment_loans OWNER TO postgres;

--
-- Name: microfinance_segment_loans_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.microfinance_segment_loans_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.microfinance_segment_loans_ptid_seq OWNER TO postgres;

--
-- Name: microfinance_segment_loans_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.microfinance_segment_loans_ptid_seq OWNED BY universe_dw.microfinance_segment_loans.ptid;


--
-- Name: mno_funds_transfer; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.mno_funds_transfer (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    transaction_id character varying(200),
    transaction_date character varying(200),
    transaction_code character varying(200),
    transfer_channel character varying(200),
    sub_category_transfer_channel character varying(200),
    sender_account_number character varying(200),
    recipient_name character varying(200),
    recipient_identification character varying(200),
    recipient_bank_name character varying(200),
    recipient_account_number character varying(200),
    country character varying(200),
    recipient_mobile_number character varying(200),
    transaction_type character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    sender_instruction character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.mno_funds_transfer OWNER TO postgres;

--
-- Name: mno_funds_transfer_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.mno_funds_transfer_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.mno_funds_transfer_ptid_seq OWNER TO postgres;

--
-- Name: mno_funds_transfer_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.mno_funds_transfer_ptid_seq OWNED BY universe_dw.mno_funds_transfer.ptid;


--
-- Name: mobile_banking; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.mobile_banking (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    customer_name character varying(200),
    gender character varying(200),
    account_status character varying(200),
    transaction_date character varying(200),
    last_transaction_date character varying(200),
    unique_identification_number character varying(200),
    customer_category character varying(200),
    transaction_type character varying(200),
    service_category character varying(200),
    sub_service_category character varying(200),
    transaction_ref character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    value_added_tax_amount character varying(200),
    excise_duty_amount character varying(200),
    electronic_levy_amount character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.mobile_banking OWNER TO postgres;

--
-- Name: mobile_banking_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.mobile_banking_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.mobile_banking_ptid_seq OWNER TO postgres;

--
-- Name: mobile_banking_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.mobile_banking_ptid_seq OWNED BY universe_dw.mobile_banking.ptid;


--
-- Name: other_asset; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.other_asset (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    asset_type character varying(200),
    asset_type_sub_category character varying(200),
    transaction_date character varying(200),
    maturity_date character varying(200),
    debtor_name character varying(200),
    debtor_country character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    usd_amount character varying(200),
    tzs_amount character varying(200),
    sector_sna_classification character varying(200),
    past_due_days character varying(200),
    asset_classification_category character varying(200),
    provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.other_asset OWNER TO postgres;

--
-- Name: other_asset_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.other_asset_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.other_asset_ptid_seq OWNER TO postgres;

--
-- Name: other_asset_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.other_asset_ptid_seq OWNED BY universe_dw.other_asset.ptid;


--
-- Name: other_capital_account; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.other_capital_account (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    transaction_date character varying(200),
    transaction_type character varying(200),
    reserve_category character varying(200),
    reserve_sub_category character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.other_capital_account OWNER TO postgres;

--
-- Name: other_capital_account_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.other_capital_account_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.other_capital_account_ptid_seq OWNER TO postgres;

--
-- Name: other_capital_account_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.other_capital_account_ptid_seq OWNED BY universe_dw.other_capital_account.ptid;


--
-- Name: other_liability; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.other_liability (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    liability_category character varying(200),
    counterparty_name character varying(200),
    counterparty_country character varying(200),
    transaction_date character varying(200),
    value_date character varying(200),
    maturity_date character varying(200),
    currency character varying(200),
    org_amount_opening character varying(200),
    usd_amount_opening character varying(200),
    tzs_amount_opening character varying(200),
    org_amount_payment character varying(200),
    usd_amount_payment character varying(200),
    tzs_amount_payment character varying(200),
    org_amount_balance character varying(200),
    usd_amount_balance character varying(200),
    tzs_amount_balance character varying(200),
    sector_sna_classification character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.other_liability OWNER TO postgres;

--
-- Name: other_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.other_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.other_ptid_seq OWNER TO postgres;

--
-- Name: other_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.other_ptid_seq OWNED BY universe_dw.other_liability.ptid;


--
-- Name: outstanding_acceptances; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.outstanding_acceptances (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    acceptance_type character varying(200),
    beneficiary_name character varying(200),
    transaction_date character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    usd_amount character varying(200),
    tzs_amount character varying(200),
    sector_lender_sna_classification character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.outstanding_acceptances OWNER TO postgres;

--
-- Name: outstanding_acceptances_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.outstanding_acceptances_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.outstanding_acceptances_ptid_seq OWNER TO postgres;

--
-- Name: outstanding_acceptances_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.outstanding_acceptances_ptid_seq OWNED BY universe_dw.outstanding_acceptances.ptid;


--
-- Name: outstanding_guarantees; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.outstanding_guarantees (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    opening_date character varying(200),
    maturity_date character varying(200),
    beneficiary_name character varying(200),
    relationship_type character varying(200),
    guarantee_types character varying(200),
    collateral_types_gold character varying(200),
    beneficiary_country character varying(200),
    cr_rating_counter_foreign_bank character varying(200),
    gradesfor_unrated_foreign_bank character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    past_due_days character varying(200),
    asset_classification_type character varying(200),
    sector_sna_classification character varying(200),
    provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.outstanding_guarantees OWNER TO postgres;

--
-- Name: outstanding_guarantees_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.outstanding_guarantees_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.outstanding_guarantees_ptid_seq OWNER TO postgres;

--
-- Name: outstanding_guarantees_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.outstanding_guarantees_ptid_seq OWNED BY universe_dw.outstanding_guarantees.ptid;


--
-- Name: outstanding_letters_credit; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.outstanding_letters_credit (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    letters_credit_type character varying(200),
    collateral_type character varying(200),
    opening_date character varying(200),
    maturity_date character varying(200),
    holder_name character varying(200),
    relationship_type character varying(200),
    beneficiary_name character varying(200),
    beneficiary_country character varying(200),
    cr_rating_counter_importer character varying(200),
    gradesfor_unrated_importer character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    org_outstanding_deposits_amount character varying(200),
    tzs_outstanding_deposits_amount character varying(200),
    past_due_days character varying(200),
    asset_classification_type character varying(200),
    sector_sna_classification character varying(200),
    provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.outstanding_letters_credit OWNER TO postgres;

--
-- Name: outstanding_letters_credit_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.outstanding_letters_credit_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.outstanding_letters_credit_ptid_seq OWNER TO postgres;

--
-- Name: outstanding_letters_credit_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.outstanding_letters_credit_ptid_seq OWNED BY universe_dw.outstanding_letters_credit.ptid;


--
-- Name: outward_bills; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.outward_bills (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    opening_date character varying(200),
    maturity_date character varying(200),
    holder_name character varying(200),
    relationship_type character varying(200),
    beneficiary_name character varying(200),
    beneficiary_country character varying(200),
    cr_rating_counter_borrower character varying(200),
    gradesfor_unrated_borrower character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    usd_amount character varying(200),
    tzs_amount character varying(200),
    past_due_days character varying(200),
    asset_classification_type character varying(200),
    sna_classification character varying(200),
    impairment character varying(200),
    bot_provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.outward_bills OWNER TO postgres;

--
-- Name: outward_bills_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.outward_bills_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.outward_bills_ptid_seq OWNER TO postgres;

--
-- Name: outward_bills_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.outward_bills_ptid_seq OWNED BY universe_dw.outward_bills.ptid;


--
-- Name: overdraft; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.overdraft (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    account_number character varying(200),
    customer_identification_number character varying(200),
    client_name character varying(200),
    client_type character varying(200),
    borrower_country character varying(200),
    cr_rating_borrower character varying(200),
    grades_unrated_banks character varying(200),
    group_code character varying(200),
    related_entity_name character varying(200),
    related_party character varying(200),
    relationship_category character varying(200),
    loan_product_type character varying(200),
    overdraft_economic_activity character varying(200),
    loan_phase character varying(200),
    transfer_status character varying(200),
    purpose_other_loans character varying(200),
    contact_date character varying(200),
    branch_name character varying(200),
    branch_code character varying(200),
    loan_officer character varying(200),
    loan_supervisor character varying(200),
    currency character varying(200),
    org_sanctioned_amount character varying(200),
    tzs_sanctioned_amount character varying(200),
    org_utilised_amount character varying(200),
    tzs_utilised_amount character varying(200),
    org_cr_usage_last_30_days_amount character varying(200),
    tzs_cr_usage_last_30_days_amount character varying(200),
    disbursement_date character varying(200),
    expiry_date character varying(200),
    real_end_date character varying(200),
    org_outstanding_amount character varying(200),
    tzs_outstanding_amount character varying(200),
    org_outstanding_principal_amount character varying(200),
    latest_customer_credit_date character varying(200),
    latest_credit_amount character varying(200),
    interest_rate character varying(200),
    collateral_pledged character varying(200),
    collateral_value character varying(200),
    restructured_loans character varying(200),
    past_due_days character varying(200),
    past_due_amount character varying(200),
    org_accrued_interest_amount character varying(200),
    tzs_accrued_interest_amount character varying(200),
    org_penalty_charged_amount character varying(200),
    tzs_penalty_charged_amount character varying(200),
    org_penalty_paid_amount character varying(200),
    tzs_penalty_paid_amount character varying(200),
    org_loan_fees_charged_amount character varying(200),
    tzs_loan_fees_charged_amount character varying(200),
    org_tot_monthly_payment_amount character varying(200),
    tzs_tot_monthly_payment_amount character varying(200),
    interest_paid_total character varying(200),
    asset_classification_category character varying(200),
    sector_sna_classification character varying(200),
    neg_status_contract character varying(200),
    customer_role character varying(200),
    provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.overdraft OWNER TO postgres;

--
-- Name: overdraft_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.overdraft_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.overdraft_ptid_seq OWNER TO postgres;

--
-- Name: overdraft_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.overdraft_ptid_seq OWNED BY universe_dw.overdraft.ptid;


--
-- Name: pos_information; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.pos_information (
    ptid bigint NOT NULL,
    postal_code character varying(200),
    region character varying(200),
    district character varying(200),
    ward character varying(200),
    street character varying(200),
    house_number character varying(200),
    reporting_date timestamp(0) without time zone NOT NULL,
    branch_name character varying(200),
    pos_branch_code character varying(200),
    pos_number character varying(200),
    qr_fsr_code character varying(200),
    pos_holder_category character varying(200),
    pos_holder_name character varying(200),
    pos_holder_nin character varying(200),
    pos_holder_tin character varying(200),
    gps_coordinates character varying(200),
    linked_account character varying(200),
    issue_date character varying(200),
    return_date character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.pos_information OWNER TO postgres;

--
-- Name: pos_information_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.pos_information_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.pos_information_ptid_seq OWNER TO postgres;

--
-- Name: pos_information_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.pos_information_ptid_seq OWNED BY universe_dw.pos_information.ptid;


--
-- Name: pos_transaction; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.pos_transaction (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    pos_number character varying(200),
    transaction_date character varying(200),
    transaction_id character varying(200),
    transaction_type character varying(200),
    currency character varying(200),
    org_currency_transaction_amount character varying(200),
    tzs_transaction_amount character varying(200),
    value_added_tax_amount character varying(200),
    excise_duty_amount character varying(200),
    electronic_levy_amount character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.pos_transaction OWNER TO postgres;

--
-- Name: pos_transaction_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.pos_transaction_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.pos_transaction_ptid_seq OWNER TO postgres;

--
-- Name: pos_transaction_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.pos_transaction_ptid_seq OWNED BY universe_dw.pos_transaction.ptid;


--
-- Name: pre_operating_expenses; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.pre_operating_expenses (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    currency character varying(200),
    org_amount character varying(200),
    usd_amount character varying(200),
    tzs_amount character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.pre_operating_expenses OWNER TO postgres;

--
-- Name: pre_operating_expenses_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.pre_operating_expenses_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.pre_operating_expenses_ptid_seq OWNER TO postgres;

--
-- Name: pre_operating_expenses_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.pre_operating_expenses_ptid_seq OWNED BY universe_dw.pre_operating_expenses.ptid;


--
-- Name: premises_furniture_equipment; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.premises_furniture_equipment (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    asset_category character varying(200),
    usage_premises_furniture_equipment character varying(200),
    acquisition_date character varying(200),
    asset_type character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    usd_amount character varying(200),
    disposal_date character varying(200),
    asset_disposed_value character varying(200),
    org_cur_depr character varying(200),
    tzs_cur_depr character varying(200),
    usd_cur_depr character varying(200),
    org_cur_accum_depr_impairment character varying(200),
    tzs_cur_accum_depr_impairment character varying(200),
    usd_cur_accum_depr_impairment character varying(200),
    org_cur_net_book_value character varying(200),
    tzs_cur_net_book_value character varying(200),
    usd_cur_net_book_value character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.premises_furniture_equipment OWNER TO postgres;

--
-- Name: premises_furniture_equipment_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.premises_furniture_equipment_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.premises_furniture_equipment_ptid_seq OWNER TO postgres;

--
-- Name: premises_furniture_equipment_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.premises_furniture_equipment_ptid_seq OWNED BY universe_dw.premises_furniture_equipment.ptid;


--
-- Name: remittances; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.remittances (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    transaction_id character varying(200),
    transaction_code character varying(200),
    transaction_date character varying(200),
    transaction_type character varying(200),
    transaction_purposes character varying(200),
    remittance_type character varying(200),
    sender_name character varying(200),
    sender_identification character varying(200),
    mobile_number character varying(200),
    transfer_channel character varying(200),
    sub_category_transferchannel character varying(200),
    recipient_name character varying(200),
    recipient_identity_number character varying(200),
    recipient_mobile_number character varying(200),
    region_beneficiary character varying(200),
    terminating_channel character varying(200),
    terminating_channel_name character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    tzs_inward_remittance character varying(200),
    agent_principal character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.remittances OWNER TO postgres;

--
-- Name: remittances_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.remittances_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.remittances_ptid_seq OWNER TO postgres;

--
-- Name: remittances_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.remittances_ptid_seq OWNED BY universe_dw.remittances.ptid;


--
-- Name: remittances_receiver; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.remittances_receiver (
    ptid bigint NOT NULL,
    remitance_ptid bigint NOT NULL,
    region character varying(200),
    district character varying(200),
    ward character varying(200),
    street character varying(200),
    recipient_country character varying(200),
    recipient_house_number character varying(200)
);


ALTER TABLE universe_dw.remittances_receiver OWNER TO postgres;

--
-- Name: remittances_receiver_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.remittances_receiver_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.remittances_receiver_ptid_seq OWNER TO postgres;

--
-- Name: remittances_receiver_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.remittances_receiver_ptid_seq OWNED BY universe_dw.remittances_receiver.ptid;


--
-- Name: remittances_sender; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.remittances_sender (
    ptid bigint NOT NULL,
    remitance_ptid bigint NOT NULL,
    region character varying(200),
    district character varying(200),
    ward character varying(200),
    street character varying(200),
    sender_country character varying(200),
    sender_house_number character varying(200)
);


ALTER TABLE universe_dw.remittances_sender OWNER TO postgres;

--
-- Name: remittances_sender_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.remittances_sender_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.remittances_sender_ptid_seq OWNER TO postgres;

--
-- Name: remittances_sender_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.remittances_sender_ptid_seq OWNED BY universe_dw.remittances_sender.ptid;


--
-- Name: safekeeping_heald_item; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.safekeeping_heald_item (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    deposit_date character varying(200),
    beneficiary_name character varying(200),
    relationship_type character varying(200),
    collateral_type character varying(200),
    beneficiary_country character varying(200),
    credit_rating_counter_customer character varying(200),
    gradesfor_unrated_customer character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    past_due_days character varying(200),
    impairment character varying(200),
    bot_provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.safekeeping_heald_item OWNER TO postgres;

--
-- Name: safekeeping_heald_item_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.safekeeping_heald_item_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.safekeeping_heald_item_ptid_seq OWNER TO postgres;

--
-- Name: safekeeping_heald_item_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.safekeeping_heald_item_ptid_seq OWNED BY universe_dw.safekeeping_heald_item.ptid;


--
-- Name: securities_purchased; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.securities_purchased (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    seller_name character varying(200),
    relationship_type character varying(200),
    transaction_date character varying(200),
    value_date character varying(200),
    maturity_date character varying(200),
    seller_country character varying(200),
    cr_rating_counter_customer character varying(200),
    gradesfor_unrated_customer character varying(200),
    currency character varying(200),
    org_purchased_amount character varying(200),
    usd_purchased_amount character varying(200),
    tzs_purchased_amount character varying(200),
    org_resale_amount character varying(200),
    usd_resale_amount character varying(200),
    tzs_resale_amount character varying(200),
    sna_classification character varying(200),
    past_due_days character varying(200),
    impairment character varying(200),
    bot_provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.securities_purchased OWNER TO postgres;

--
-- Name: securities_purchased_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.securities_purchased_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.securities_purchased_ptid_seq OWNER TO postgres;

--
-- Name: securities_purchased_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.securities_purchased_ptid_seq OWNED BY universe_dw.securities_purchased.ptid;


--
-- Name: securities_sold; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.securities_sold (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    relationship_type character varying(200),
    value_date character varying(200),
    maturity_date character varying(200),
    buyer_name character varying(200),
    buyer_country character varying(200),
    cr_rating_counter_customer character varying(200),
    gradesfor_unrated_customer character varying(200),
    currency character varying(200),
    org_sold_amount character varying(200),
    usd_sold_amount character varying(200),
    tzs_sold_amount character varying(200),
    org_repurchase_amount character varying(200),
    usd_repurchase_amount character varying(200),
    tzs_repurchase_amount character varying(200),
    sna_classification character varying(200),
    past_due_days character varying(200),
    impairment character varying(200),
    bot_provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.securities_sold OWNER TO postgres;

--
-- Name: securities_sold_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.securities_sold_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.securities_sold_ptid_seq OWNER TO postgres;

--
-- Name: securities_sold_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.securities_sold_ptid_seq OWNED BY universe_dw.securities_sold.ptid;


--
-- Name: share_capital; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.share_capital (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    capital_category character varying(200),
    capital_sub_category character varying(200),
    transaction_date character varying(200),
    shareholder_names character varying(200),
    client_type character varying(200),
    shareholder_country character varying(200),
    number_of_shares character varying(200),
    share_price_book_value character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    sector_snaclassification character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.share_capital OWNER TO postgres;

--
-- Name: share_capital_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.share_capital_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.share_capital_ptid_seq OWNER TO postgres;

--
-- Name: share_capital_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.share_capital_ptid_seq OWNED BY universe_dw.share_capital.ptid;


--
-- Name: sold_forward_exchange; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.sold_forward_exchange (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    counterpart_name character varying(200),
    relationship_type character varying(200),
    currency_a character varying(200),
    currency_b character varying(200),
    org_amount_currency_a character varying(200),
    exchange_rate_currency_ab character varying(200),
    org_amount_currency_b character varying(200),
    exchange_rate_currency_a_2_tzs character varying(200),
    exchange_rate_currency_b_2_tzs character varying(200),
    tzs_amount_currency_a character varying(200),
    tzs_amount_currency_b character varying(200),
    transaction_date character varying(200),
    value_date character varying(200),
    transaction_type character varying(200),
    counterpart_country character varying(200),
    cr_rating_counter_customer character varying(200),
    grades_unrated_customer character varying(200),
    past_due_days character varying(200),
    impairment character varying(200),
    bot_provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.sold_forward_exchange OWNER TO postgres;

--
-- Name: sold_forward_exchange_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.sold_forward_exchange_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.sold_forward_exchange_ptid_seq OWNER TO postgres;

--
-- Name: sold_forward_exchange_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.sold_forward_exchange_ptid_seq OWNED BY universe_dw.sold_forward_exchange.ptid;


--
-- Name: subordinated_debt; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.subordinated_debt (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    lender_name character varying(200),
    country character varying(200),
    sector_sna_classification character varying(200),
    lender_relationship character varying(200),
    borrowing_purposes character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    annual_interest_rate character varying(200),
    interest_rate_type character varying(200),
    loan_contract_date character varying(200),
    loan_value_date character varying(200),
    maturity_date character varying(200),
    principal_payment_date character varying(200),
    org_amount_repayment character varying(200),
    tzs_amount_repayment character varying(200),
    org_amount_closing character varying(200),
    tzs_amount_closing character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.subordinated_debt OWNER TO postgres;

--
-- Name: subordinated_debt_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.subordinated_debt_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.subordinated_debt_ptid_seq OWNER TO postgres;

--
-- Name: subordinated_debt_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.subordinated_debt_ptid_seq OWNED BY universe_dw.subordinated_debt.ptid;


--
-- Name: tbond_transactions; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.tbond_transactions (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    trade_date character varying(200),
    seller_name character varying(200),
    buyer_name character varying(200),
    tbond_auction_number character varying(200),
    isin character varying(200),
    issue_date character varying(200),
    maturity_date character varying(200),
    tzs_amount character varying(200),
    price character varying(200),
    yield character varying(200),
    coupon_rate character varying(200),
    tenure character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.tbond_transactions OWNER TO postgres;

--
-- Name: tbond_transactionaa_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.tbond_transactionaa_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.tbond_transactionaa_ptid_seq OWNER TO postgres;

--
-- Name: tbond_transactionaa_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.tbond_transactionaa_ptid_seq OWNED BY universe_dw.tbond_transactions.ptid;


--
-- Name: transfers_payable; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.transfers_payable (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    customer_identification_number character varying(200),
    beneficiary_name character varying(200),
    beneficiary_country character varying(200),
    purpose_transfer character varying(200),
    beneficiary_acc_number character varying(200),
    ben_receiving_institution character varying(200),
    ben_sector_sna_classification character varying(200),
    transaction_date character varying(200),
    value_date character varying(200),
    maturity_date character varying(200),
    sender_name character varying(200),
    sender_acc_number character varying(200),
    sender_country character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    org_amount_repayment character varying(200),
    tzs_amount_repayment character varying(200),
    org_amount_closing character varying(200),
    tzs_amount_closing character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.transfers_payable OWNER TO postgres;

--
-- Name: transfers_payable_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.transfers_payable_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.transfers_payable_ptid_seq OWNER TO postgres;

--
-- Name: transfers_payable_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.transfers_payable_ptid_seq OWNED BY universe_dw.transfers_payable.ptid;


--
-- Name: trust_fiduciary_account; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.trust_fiduciary_account (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    deposit_date character varying(200),
    beneficiary_name character varying(200),
    relationship_type character varying(200),
    collateral_type character varying(200),
    beneficiary_country character varying(200),
    credit_rating_counter_customer character varying(200),
    gradesfor_unrated_customer character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    tzs_amount character varying(200),
    past_due_days character varying(200),
    impairment character varying(200),
    bot_provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.trust_fiduciary_account OWNER TO postgres;

--
-- Name: trust_fiduciary_account_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.trust_fiduciary_account_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.trust_fiduciary_account_ptid_seq OWNER TO postgres;

--
-- Name: trust_fiduciary_account_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.trust_fiduciary_account_ptid_seq OWNED BY universe_dw.trust_fiduciary_account.ptid;


--
-- Name: underwriting_accounts; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.underwriting_accounts (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    underwriting_type character varying(200),
    collateral_type character varying(200),
    customer_name character varying(200),
    transaction_date character varying(200),
    total_value_share character varying(200),
    total_value_share_underwritten character varying(200),
    date_underwritten character varying(200),
    past_due_days character varying(200),
    provision character varying(200),
    asset_classification_category character varying(200),
    sector_sna_classification character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.underwriting_accounts OWNER TO postgres;

--
-- Name: underwriting_accounts_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.underwriting_accounts_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.underwriting_accounts_ptid_seq OWNER TO postgres;

--
-- Name: underwriting_accounts_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.underwriting_accounts_ptid_seq OWNED BY universe_dw.underwriting_accounts.ptid;


--
-- Name: undrawn_balance; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.undrawn_balance (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    client_file_number character varying(200),
    borrower_name character varying(200),
    relationship_type character varying(200),
    contract_date character varying(200),
    category_undrawn_balance character varying(200),
    cr_rating_counter_customer character varying(200),
    grades_unrated_customer character varying(200),
    currency character varying(200),
    org_sanctioned_amount character varying(200),
    tzs_sactioned_amount character varying(200),
    org_disbursed_amount character varying(200),
    tzs_disbursed_amount character varying(200),
    org_unutilised_amount character varying(200),
    tzs_unutilised_amount character varying(200),
    collateral_type character varying(200),
    past_due_days character varying(200),
    impairment character varying(200),
    bot_provision character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.undrawn_balance OWNER TO postgres;

--
-- Name: undrawn_balance_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.undrawn_balance_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.undrawn_balance_ptid_seq OWNER TO postgres;

--
-- Name: undrawn_balance_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.undrawn_balance_ptid_seq OWNED BY universe_dw.undrawn_balance.ptid;


--
-- Name: unearned_income; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.unearned_income (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    unearned_income_type character varying(200),
    beneficiary_name character varying(200),
    transaction_date character varying(200),
    currency character varying(200),
    org_amount character varying(200),
    usd_amount character varying(200),
    tzs_amount character varying(200),
    sector_lender_sna_classification character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.unearned_income OWNER TO postgres;

--
-- Name: unearned_income_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.unearned_income_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.unearned_income_ptid_seq OWNER TO postgres;

--
-- Name: unearned_income_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.unearned_income_ptid_seq OWNED BY universe_dw.unearned_income.ptid;


--
-- Name: user_pwd; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.user_pwd (
    user_id smallint NOT NULL,
    encrypted_pwd character varying(100) NOT NULL,
    status character varying(1) NOT NULL,
    ptid numeric(10,0) NOT NULL,
    password_cycle integer NOT NULL,
    created_by character varying(30) NOT NULL,
    create_date timestamp without time zone NOT NULL
);


ALTER TABLE universe_dw.user_pwd OWNER TO postgres;

--
-- Name: user_ref; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.user_ref (
    user_id bigint NOT NULL,
    login_id character varying(20),
    first_name character varying(255),
    middle_name character varying(255),
    last_name character varying(255),
    gender character varying(8),
    email_address character varying(70),
    branch_id bigint,
    security_role_id integer,
    start_dt date,
    end_dt date,
    failed_login_attempt integer,
    status character varying(20),
    uuid character varying(36),
    password_changed_flag character varying(1),
    password_expiry_date date,
    last_logon_date timestamp(0) without time zone,
    created_by character varying(10) NOT NULL,
    create_dt timestamp without time zone NOT NULL,
    modified_by character varying(10),
    modify_dt timestamp without time zone
);


ALTER TABLE universe_dw.user_ref OWNER TO postgres;

--
-- Name: user_ref_user_id_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.user_ref_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.user_ref_user_id_seq OWNER TO postgres;

--
-- Name: user_ref_user_id_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.user_ref_user_id_seq OWNED BY universe_dw.user_ref.user_id;


--
-- Name: written_offloans; Type: TABLE; Schema: universe_dw; Owner: postgres
--

CREATE TABLE universe_dw.written_offloans (
    ptid bigint NOT NULL,
    reporting_date timestamp(0) without time zone NOT NULL,
    customer_identification_number character varying(200),
    account_number character varying(200),
    borrower_name character varying(200),
    borrower_country character varying(200),
    client_type character varying(200),
    loan_number character varying(200),
    loan_type character varying(200),
    currency character varying(200),
    org_disbursed_amount character varying(200),
    tzs_disbursed_amount character varying(200),
    disbursement_date character varying(200),
    grace_period_payment_principal character varying(200),
    maturity_date character varying(200),
    gross_paid_amount character varying(200),
    written_off_date character varying(200),
    org_outstanding_principal_amount character varying(200),
    tzs_outstanding_principal_amount character varying(200),
    annual_interest_rate character varying(200),
    latest_installment_pay_date character varying(200),
    collateral_pledged character varying(200),
    collateral_value character varying(200),
    past_due_days character varying(200),
    loan_officer character varying(200),
    loan_supervisor character varying(200),
    batch_id bigint NOT NULL
);


ALTER TABLE universe_dw.written_offloans OWNER TO postgres;

--
-- Name: written_offloans_ptid_seq; Type: SEQUENCE; Schema: universe_dw; Owner: postgres
--

CREATE SEQUENCE universe_dw.written_offloans_ptid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE universe_dw.written_offloans_ptid_seq OWNER TO postgres;

--
-- Name: written_offloans_ptid_seq; Type: SEQUENCE OWNED BY; Schema: universe_dw; Owner: postgres
--

ALTER SEQUENCE universe_dw.written_offloans_ptid_seq OWNED BY universe_dw.written_offloans.ptid;


--
-- Name: account_category ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.account_category ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.account_category_ptid_seq'::regclass);


--
-- Name: accounts_unsold ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.accounts_unsold ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.accounts_unsold_ptid_seq'::regclass);


--
-- Name: accrued_taxes ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.accrued_taxes ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.accrued_taxes_ptid_seq'::regclass);


--
-- Name: agent_information ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.agent_information ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.agent_information_ptid_seq'::regclass);


--
-- Name: agent_transaction ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.agent_transaction ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.agent_transaction_ptid_seq'::regclass);


--
-- Name: asset_owned ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.asset_owned ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.asset_owned_ptid_seq'::regclass);


--
-- Name: atm_information ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.atm_information ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.atm_information_ptid_seq'::regclass);


--
-- Name: atm_transaction ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.atm_transaction ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.atm_transaction_ptid_seq'::regclass);


--
-- Name: balance_bot ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.balance_bot ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.balance_bot_ptid_seq'::regclass);


--
-- Name: balance_mno ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.balance_mno ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.balance_mno_ptid_seq'::regclass);


--
-- Name: balance_other_banks ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.balance_other_banks ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.balance_other_banks_ptid_seq'::regclass);


--
-- Name: bank_funds_transfer ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bank_funds_transfer ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.bank_funds_transfer_ptid_seq'::regclass);


--
-- Name: bankers_cheques ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bankers_cheques ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.bankers_cheques_ptid_seq'::regclass);


--
-- Name: borrowings_information ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.borrowings_information ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.borrowings_information_ptid_seq'::regclass);


--
-- Name: bot_replication_files file_id; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bot_replication_files ALTER COLUMN file_id SET DEFAULT nextval('universe_dw.bot_replication_summary_file_id_seq'::regclass);


--
-- Name: bot_replication_summary batch_id; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bot_replication_summary ALTER COLUMN batch_id SET DEFAULT nextval('universe_dw.bot_replication_summary_batch_id_seq'::regclass);


--
-- Name: bought_forward_exchange ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bought_forward_exchange ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.bought_forward_exchange_ptid_seq'::regclass);


--
-- Name: branch_information ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.branch_information ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.branch_information_ptid_seq'::regclass);


--
-- Name: card_transaction ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.card_transaction ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.card_transaction_ptid_seq'::regclass);


--
-- Name: cash_information ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.cash_information ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.cash_information_ptid_seq'::regclass);


--
-- Name: cheque_unsold ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.cheque_unsold ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.cheque_unsold_ptid_seq'::regclass);


--
-- Name: cheques ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.cheques ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.cheques_ptid_seq'::regclass);


--
-- Name: claim_treasury ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.claim_treasury ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.claim_treasury_ptid_seq'::regclass);


--
-- Name: commercial_other_bills_purchased ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.commercial_other_bills_purchased ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.commercial_other_bills_purchased_ptid_seq'::regclass);


--
-- Name: company_info ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.company_info ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.company_information_ptid_seq'::regclass);


--
-- Name: company_info_business_address ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.company_info_business_address ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.company_info_business_address_ptid_seq'::regclass);


--
-- Name: company_info_contact ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.company_info_contact ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.company_info_contact_ptid_seq'::regclass);


--
-- Name: company_info_pri_address ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.company_info_pri_address ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.company_info_pri_address_ptid_seq'::regclass);


--
-- Name: company_info_related_person ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.company_info_related_person ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.company_info_rel_person_ptid_seq'::regclass);


--
-- Name: company_info_relation_entity ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.company_info_relation_entity ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.company_info_relation_entity_ptid_seq'::regclass);


--
-- Name: company_info_sec_address ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.company_info_sec_address ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.company_info_sec_address_ptid_seq'::regclass);


--
-- Name: complaint_fraud_statistics ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.complaint_fraud_statistics ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.complaint_fraud_statistics_ptid_seq'::regclass);


--
-- Name: complaints_fraud_statistics ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.complaints_fraud_statistics ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.complaints_fraud_statistics_ptid_seq'::regclass);


--
-- Name: core_capital_deductions ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.core_capital_deductions ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.core_capital_deductions_ptid_seq'::regclass);


--
-- Name: currency_swap ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.currency_swap ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.currency_swap_ptid_seq'::regclass);


--
-- Name: customer_liabilities ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.customer_liabilities ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.customer_liabilities_ptid_seq'::regclass);


--
-- Name: deposit_information ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.deposit_information ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.deposit_information_ptid_seq'::regclass);


--
-- Name: digital_credit ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.digital_credit ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.digital_credit_ptid_seq'::regclass);


--
-- Name: digital_saving ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.digital_saving ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.digital_saving_ptid_seq'::regclass);


--
-- Name: dividends_payable ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.dividends_payable ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.dividends_payable_ptid_seq'::regclass);


--
-- Name: equity_derivatives ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.equity_derivatives ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.equity_derivatives_ptid_seq'::regclass);


--
-- Name: equity_investment ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.equity_investment ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.equity_investment_ptid_seq'::regclass);


--
-- Name: export_letters_credit ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.export_letters_credit ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.export_letters_credit_ptid_seq'::regclass);


--
-- Name: foreign_term_debt ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.foreign_term_debt ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.foreign_term_debt_ptid_seq'::regclass);


--
-- Name: ibcm_transaction ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.ibcm_transaction ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.ibcm_transaction_ptid_seq'::regclass);


--
-- Name: ifem_quotes ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.ifem_quotes ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.ifem_quotes_ptid_seq'::regclass);


--
-- Name: ifem_transaction ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.ifem_transaction ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.ifem_transaction_ptid_seq'::regclass);


--
-- Name: income_statement ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.income_statement ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.income_statement_ptid_seq'::regclass);


--
-- Name: individual_birth_info ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_birth_info ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.individual_birth_info_ptid_seq'::regclass);


--
-- Name: individual_contact_info ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_contact_info ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.individual_contact_info_ptid_seq'::regclass);


--
-- Name: individual_employer_info ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_employer_info ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.individual_employer_info_ptid_seq'::regclass);


--
-- Name: individual_enterprenuer_info ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_enterprenuer_info ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.individual_enterprenuer_info_ptid_seq'::regclass);


--
-- Name: individual_ident_info ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_ident_info ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.individual_ident_info_ptid_seq'::regclass);


--
-- Name: individual_info ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_info ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.individual_information_ptid_seq'::regclass);


--
-- Name: individual_pri_address ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_pri_address ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.individual_address_info_ptid_seq'::regclass);


--
-- Name: individual_sec_address ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_sec_address ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.individual_sec_address_ptid_seq'::regclass);


--
-- Name: institution_premises ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.institution_premises ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.institution_premises_ptid_seq'::regclass);


--
-- Name: insurance_claim ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.insurance_claim ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.insurance_claim_ptid_seq'::regclass);


--
-- Name: insurance_commission ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.insurance_commission ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.insurance_commission_ptid_seq'::regclass);


--
-- Name: insurance_underwritting ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.insurance_underwritting ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.insurance_underwritting_ptid_seq'::regclass);


--
-- Name: inter_branch_float_item ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.inter_branch_float_item ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.inter_branch_float_item_ptid_seq'::regclass);


--
-- Name: interbank_loan_payable ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interbank_loan_payable ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.interbank_loan_payable_ptid_seq'::regclass);


--
-- Name: interbank_loans_receivable ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interbank_loans_receivable ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.interbank_loans_receivable_ptid_seq'::regclass);


--
-- Name: interest_rate_futures ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interest_rate_futures ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.interest_rate_futures_ptid_seq'::regclass);


--
-- Name: interest_rate_swap ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interest_rate_swap ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.interest_rate_swap_ptid_seq'::regclass);


--
-- Name: interest_trust_account ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interest_trust_account ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.interest_trust_account_ptid_seq'::regclass);


--
-- Name: internet_banking ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.internet_banking ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.internet_banking_ptid_seq'::regclass);


--
-- Name: inv_debt_securities ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.inv_debt_securities ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.inv_debt_securities_ptid_seq'::regclass);


--
-- Name: inward_bills ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.inward_bills ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.inward_bills_ptid_seq'::regclass);


--
-- Name: late_deposit_payments ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.late_deposit_payments ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.late_deposit_payments_ptid_seq'::regclass);


--
-- Name: loan_information ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.loan_information ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.loan_ptid_seq'::regclass);


--
-- Name: microfinance_segment_loans ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.microfinance_segment_loans ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.microfinance_segment_loans_ptid_seq'::regclass);


--
-- Name: mno_funds_transfer ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.mno_funds_transfer ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.mno_funds_transfer_ptid_seq'::regclass);


--
-- Name: mobile_banking ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.mobile_banking ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.mobile_banking_ptid_seq'::regclass);


--
-- Name: other_asset ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.other_asset ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.other_asset_ptid_seq'::regclass);


--
-- Name: other_capital_account ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.other_capital_account ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.other_capital_account_ptid_seq'::regclass);


--
-- Name: other_liability ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.other_liability ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.other_ptid_seq'::regclass);


--
-- Name: outstanding_acceptances ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.outstanding_acceptances ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.outstanding_acceptances_ptid_seq'::regclass);


--
-- Name: outstanding_guarantees ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.outstanding_guarantees ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.outstanding_guarantees_ptid_seq'::regclass);


--
-- Name: outstanding_letters_credit ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.outstanding_letters_credit ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.outstanding_letters_credit_ptid_seq'::regclass);


--
-- Name: outward_bills ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.outward_bills ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.outward_bills_ptid_seq'::regclass);


--
-- Name: overdraft ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.overdraft ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.overdraft_ptid_seq'::regclass);


--
-- Name: pos_information ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.pos_information ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.pos_information_ptid_seq'::regclass);


--
-- Name: pos_transaction ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.pos_transaction ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.pos_transaction_ptid_seq'::regclass);


--
-- Name: pre_operating_expenses ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.pre_operating_expenses ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.pre_operating_expenses_ptid_seq'::regclass);


--
-- Name: premises_furniture_equipment ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.premises_furniture_equipment ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.premises_furniture_equipment_ptid_seq'::regclass);


--
-- Name: remittances ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.remittances ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.remittances_ptid_seq'::regclass);


--
-- Name: remittances_receiver ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.remittances_receiver ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.remittances_receiver_ptid_seq'::regclass);


--
-- Name: remittances_sender ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.remittances_sender ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.remittances_sender_ptid_seq'::regclass);


--
-- Name: safekeeping_heald_item ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.safekeeping_heald_item ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.safekeeping_heald_item_ptid_seq'::regclass);


--
-- Name: securities_purchased ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.securities_purchased ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.securities_purchased_ptid_seq'::regclass);


--
-- Name: securities_sold ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.securities_sold ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.securities_sold_ptid_seq'::regclass);


--
-- Name: share_capital ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.share_capital ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.share_capital_ptid_seq'::regclass);


--
-- Name: sold_forward_exchange ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.sold_forward_exchange ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.sold_forward_exchange_ptid_seq'::regclass);


--
-- Name: subordinated_debt ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.subordinated_debt ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.subordinated_debt_ptid_seq'::regclass);


--
-- Name: tbond_transactions ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.tbond_transactions ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.tbond_transactionaa_ptid_seq'::regclass);


--
-- Name: transfers_payable ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.transfers_payable ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.transfers_payable_ptid_seq'::regclass);


--
-- Name: trust_fiduciary_account ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.trust_fiduciary_account ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.trust_fiduciary_account_ptid_seq'::regclass);


--
-- Name: underwriting_accounts ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.underwriting_accounts ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.underwriting_accounts_ptid_seq'::regclass);


--
-- Name: undrawn_balance ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.undrawn_balance ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.undrawn_balance_ptid_seq'::regclass);


--
-- Name: unearned_income ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.unearned_income ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.unearned_income_ptid_seq'::regclass);


--
-- Name: user_ref user_id; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.user_ref ALTER COLUMN user_id SET DEFAULT nextval('universe_dw.user_ref_user_id_seq'::regclass);


--
-- Name: written_offloans ptid; Type: DEFAULT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.written_offloans ALTER COLUMN ptid SET DEFAULT nextval('universe_dw.written_offloans_ptid_seq'::regclass);


--
-- Data for Name: account_category; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.account_category (ptid, reporting_date, account_code, account_description, account_type, account_creation_date, account_closure_date, account_status, batch_id) FROM stdin;
\.
COPY universe_dw.account_category (ptid, reporting_date, account_code, account_description, account_type, account_creation_date, account_closure_date, account_status, batch_id) FROM '$$PATH$$/6586.dat';

--
-- Data for Name: accounts_unsold; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.accounts_unsold (ptid, reporting_date, security_issuer_name, relationship_type, underwritten_security_type, contract_date, issuer_country, credit_rating_counter_customer, gradesfor_unrated_customer, currency, org_amount, tzs_amount, past_due_days, impairment, bot_provision, batch_id) FROM stdin;
\.
COPY universe_dw.accounts_unsold (ptid, reporting_date, security_issuer_name, relationship_type, underwritten_security_type, contract_date, issuer_country, credit_rating_counter_customer, gradesfor_unrated_customer, currency, org_amount, tzs_amount, past_due_days, impairment, bot_provision, batch_id) FROM '$$PATH$$/6542.dat';

--
-- Data for Name: accrued_taxes; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.accrued_taxes (ptid, reporting_date, claimant_name, payable_category, transaction_date, currency, org_amount, tzs_amount, maturity_date, sector_lender_sna_classification, batch_id) FROM stdin;
\.
COPY universe_dw.accrued_taxes (ptid, reporting_date, claimant_name, payable_category, transaction_date, currency, org_amount, tzs_amount, maturity_date, sector_lender_sna_classification, batch_id) FROM '$$PATH$$/6468.dat';

--
-- Data for Name: agent_information; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.agent_information (ptid, postal_code, region, district, ward, street, house_number, reporting_date, agent_name, agent_id, till_number, business_form, agent_principal, agent_principalname, gender_male, registration_date, closed_date, cert_incorporation, nationality, agent_status, agent_type, account_number, country, gps_coordinates, agent_tax_identification_number, business_license, batch_id) FROM stdin;
\.
COPY universe_dw.agent_information (ptid, postal_code, region, district, ward, street, house_number, reporting_date, agent_name, agent_id, till_number, business_form, agent_principal, agent_principalname, gender_male, registration_date, closed_date, cert_incorporation, nationality, agent_status, agent_type, account_number, country, gps_coordinates, agent_tax_identification_number, business_license, batch_id) FROM '$$PATH$$/6594.dat';

--
-- Data for Name: agent_transaction; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.agent_transaction (ptid, reporting_date, agent_id, agent_status, transaction_date, last_transaction_date, transaction_id, transaction_type, service_channel, till_number, currency, tzs_amount, batch_id) FROM stdin;
\.
COPY universe_dw.agent_transaction (ptid, reporting_date, agent_id, agent_status, transaction_date, last_transaction_date, transaction_id, transaction_type, service_channel, till_number, currency, tzs_amount, batch_id) FROM '$$PATH$$/6596.dat';

--
-- Data for Name: asset_owned; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.asset_owned (ptid, reporting_date, asset_category, asset_type, acquisition_date, currency, org_cost_value, usd_cost_value, tzs_cost_value, batch_id) FROM stdin;
\.
COPY universe_dw.asset_owned (ptid, reporting_date, asset_category, asset_type, acquisition_date, currency, org_cost_value, usd_cost_value, tzs_cost_value, batch_id) FROM '$$PATH$$/6484.dat';

--
-- Data for Name: atm_information; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.atm_information (ptid, postal_code, region, district, ward, street, house_number, reporting_date, atm_name, branch_code, atm_code, qr_fsr_code, gps_coordinates, linked_account, opening_date, atm_status, closure_date, atm_category, atm_channel, batch_id) FROM stdin;
\.
COPY universe_dw.atm_information (ptid, postal_code, region, district, ward, street, house_number, reporting_date, atm_name, branch_code, atm_code, qr_fsr_code, gps_coordinates, linked_account, opening_date, atm_status, closure_date, atm_category, atm_channel, batch_id) FROM '$$PATH$$/6604.dat';

--
-- Data for Name: atm_transaction; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.atm_transaction (ptid, reporting_date, atm_code, till_number, transaction_date, transaction_id, transaction_type, currency, org_transaction_amount, tzs_transaction_amount, atm_channel, atm_services, mobile_money_services, value_added_tax_amount, excise_duty_amount, electronic_levy_amount, batch_id) FROM stdin;
\.
COPY universe_dw.atm_transaction (ptid, reporting_date, atm_code, till_number, transaction_date, transaction_id, transaction_type, currency, org_transaction_amount, tzs_transaction_amount, atm_channel, atm_services, mobile_money_services, value_added_tax_amount, excise_duty_amount, electronic_levy_amount, batch_id) FROM '$$PATH$$/6606.dat';

--
-- Data for Name: balance_bot; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.balance_bot (ptid, reporting_date, account_number, account_name, account_type, sub_account_type, currency, org_amount, usd_amount, tzs_amount, transaction_date, maturity_date, batch_id) FROM stdin;
\.
COPY universe_dw.balance_bot (ptid, reporting_date, account_number, account_name, account_type, sub_account_type, currency, org_amount, usd_amount, tzs_amount, transaction_date, maturity_date, batch_id) FROM '$$PATH$$/6494.dat';

--
-- Data for Name: balance_mno; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.balance_mno (ptid, reporting_date, float_balance_date, mno_name, till_number, currency, org_float_amount, usd_float_amount, tzs_float_amount, batch_id) FROM stdin;
\.
COPY universe_dw.balance_mno (ptid, reporting_date, float_balance_date, mno_name, till_number, currency, org_float_amount, usd_float_amount, tzs_float_amount, batch_id) FROM '$$PATH$$/6498.dat';

--
-- Data for Name: balance_other_banks; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.balance_other_banks (ptid, reporting_date, account_number, account_name, bank_name, country, relationship_type, account_type, currency, org_amount_0, usd_amount_0, tzs_amount_0, transaction_date, past_due_days_0, allowance_probable_loss, assets_classification_category, contract_date, maturity_date, external_rating_correspondent_bank, grades_unrated_banks, batch_id) FROM stdin;
\.
COPY universe_dw.balance_other_banks (ptid, reporting_date, account_number, account_name, bank_name, country, relationship_type, account_type, currency, org_amount_0, usd_amount_0, tzs_amount_0, transaction_date, past_due_days_0, allowance_probable_loss, assets_classification_category, contract_date, maturity_date, external_rating_correspondent_bank, grades_unrated_banks, batch_id) FROM '$$PATH$$/6496.dat';

--
-- Data for Name: bank_funds_transfer; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.bank_funds_transfer (ptid, reporting_date, transaction_id, transaction_code, transaction_date, transfer_channel, subcategorytransferchannel, sender_account_number, recipient_name, recipient_identification, recipient_bank_code, recipient_account_number, recipient_mno_code, recipient_mobile_number, country, transaction_type, service_channel, org_amount, currency, tzs_amount, purposes, sender_instruction, batch_id) FROM stdin;
\.
COPY universe_dw.bank_funds_transfer (ptid, reporting_date, transaction_id, transaction_code, transaction_date, transfer_channel, subcategorytransferchannel, sender_account_number, recipient_name, recipient_identification, recipient_bank_code, recipient_account_number, recipient_mno_code, recipient_mobile_number, country, transaction_type, service_channel, org_amount, currency, tzs_amount, purposes, sender_instruction, batch_id) FROM '$$PATH$$/6588.dat';

--
-- Data for Name: bankers_cheques; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.bankers_cheques (ptid, reporting_date, customer_name, customer_identification_number, beneficiary_name, cheque_number, transaction_date, value_date, maturity_date, currency, org_amount, usd_amount, tzs_amount, batch_id) FROM stdin;
\.
COPY universe_dw.bankers_cheques (ptid, reporting_date, customer_name, customer_identification_number, beneficiary_name, cheque_number, transaction_date, value_date, maturity_date, currency, org_amount, usd_amount, tzs_amount, batch_id) FROM '$$PATH$$/6464.dat';

--
-- Data for Name: borrowings_information; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.borrowings_information (ptid, reporting_date, borrowing_type, lender_name, lender_country, lender_relationship, transaction_unique_ref, debt_registration_number, borrowers_account_number, account_number, borrowers_bank_name, sector_lender_sna_classification, date_loan_contract, date_loan_receipt, date_loan_maturity, annual_interest_rate, interest_rate_type, borrowing_purposes, currency, org_amount_opening, tzs_amount_opening, usd_amount_opening, org_amount_repayment, tzs_amount_repayment, usd_amount_repayment, org_amount_closing, tzs_amount_closing, usd_amount_closing, batch_id) FROM stdin;
\.
COPY universe_dw.borrowings_information (ptid, reporting_date, borrowing_type, lender_name, lender_country, lender_relationship, transaction_unique_ref, debt_registration_number, borrowers_account_number, account_number, borrowers_bank_name, sector_lender_sna_classification, date_loan_contract, date_loan_receipt, date_loan_maturity, annual_interest_rate, interest_rate_type, borrowing_purposes, currency, org_amount_opening, tzs_amount_opening, usd_amount_opening, org_amount_repayment, tzs_amount_repayment, usd_amount_repayment, org_amount_closing, tzs_amount_closing, usd_amount_closing, batch_id) FROM '$$PATH$$/6478.dat';

--
-- Data for Name: bot_replication_files; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.bot_replication_files (file_id, file_name, run_freq_value, run_freq_code, primary_column_name, primary_column_data_type, db_object_name, last_run_date, file_status, datasource_mode, last_spooled_value, uuid) FROM stdin;
\.
COPY universe_dw.bot_replication_files (file_id, file_name, run_freq_value, run_freq_code, primary_column_name, primary_column_data_type, db_object_name, last_run_date, file_status, datasource_mode, last_spooled_value, uuid) FROM '$$PATH$$/6652.dat';

--
-- Data for Name: bot_replication_summary; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.bot_replication_summary (batch_id, repl_start_date, repl_end_date, status, response_log, response_message, file_id, created_by, create_date, uuid) FROM stdin;
\.
COPY universe_dw.bot_replication_summary (batch_id, repl_start_date, repl_end_date, status, response_log, response_message, file_id, created_by, create_date, uuid) FROM '$$PATH$$/6654.dat';

--
-- Data for Name: bought_forward_exchange; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.bought_forward_exchange (ptid, reporting_date, counterpart_name, relationship_type, currency_a, currency_b, org_amount_currency_a, exchange_rate_currency_ab, org_amount_currency_b, exchange_rate_currency_a_2_tzs, exchange_rate_currency_b_2_tzs, tzs_amount_currency_a, tzs_amount_currency_b, transaction_date, value_date, counterpart_cr_rating, transaction_type, counterpart_country, cr_rating_counter_seller, grades_unrated_seller, past_due_days, impairment, bot_provision, batch_id) FROM stdin;
\.
COPY universe_dw.bought_forward_exchange (ptid, reporting_date, counterpart_name, relationship_type, currency_a, currency_b, org_amount_currency_a, exchange_rate_currency_ab, org_amount_currency_b, exchange_rate_currency_a_2_tzs, exchange_rate_currency_b_2_tzs, tzs_amount_currency_a, tzs_amount_currency_b, transaction_date, value_date, counterpart_cr_rating, transaction_type, counterpart_country, cr_rating_counter_seller, grades_unrated_seller, past_due_days, impairment, bot_provision, batch_id) FROM '$$PATH$$/6534.dat';

--
-- Data for Name: branch_information; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.branch_information (ptid, postal_code, region, district, ward, street, house_number, reporting_date, branch_name, tax_identification_number, business_license, branch_code, qr_fsr_code, gps_coordinates, banking_services, mobile_money_services, registration_date, branch_status, closure_date, contact_person, telephone_number, alt_telephone_number, branch_category, batch_id) FROM stdin;
\.
COPY universe_dw.branch_information (ptid, postal_code, region, district, ward, street, house_number, reporting_date, branch_name, tax_identification_number, business_license, branch_code, qr_fsr_code, gps_coordinates, banking_services, mobile_money_services, registration_date, branch_status, closure_date, contact_person, telephone_number, alt_telephone_number, branch_category, batch_id) FROM '$$PATH$$/6592.dat';

--
-- Data for Name: card_transaction; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.card_transaction (ptid, reporting_date, card_type, credit_cardtype, card_issuer, card_issuer_category, transacting_bank_name, transaction_id, card_holder, card_number, card_status, transaction_date, last_transaction_date, transaction_nature, atm_code, pos_number, currency, org_transaction_amount, tzs_transaction_amount, batch_id) FROM stdin;
\.
COPY universe_dw.card_transaction (ptid, reporting_date, card_type, credit_cardtype, card_issuer, card_issuer_category, transacting_bank_name, transaction_id, card_holder, card_number, card_status, transaction_date, last_transaction_date, transaction_nature, atm_code, pos_number, currency, org_transaction_amount, tzs_transaction_amount, batch_id) FROM '$$PATH$$/6608.dat';

--
-- Data for Name: cash_information; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.cash_information (ptid, reporting_date, branch_code, cash_category, sub_category, currency, cash_condition, cash_denomination, quantity_of_coins_notes, org_amount, usd_amount, tzs_amount, transaction_date, maturity_date, allowance_probable_loss, batch_id) FROM stdin;
\.
COPY universe_dw.cash_information (ptid, reporting_date, branch_code, cash_category, sub_category, currency, cash_condition, cash_denomination, quantity_of_coins_notes, org_amount, usd_amount, tzs_amount, transaction_date, maturity_date, allowance_probable_loss, batch_id) FROM '$$PATH$$/6492.dat';

--
-- Data for Name: cheque_unsold; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.cheque_unsold (ptid, reporting_date, payee_name, instrument_date, instrument_issuer_bank, drawer_name, relationship_type, cr_rating_counter_customer, grades_unrated_customer, currency, org_amount, tzs_amount, sector_sna_classification, past_due_days, impairment, bot_provision, batch_id) FROM stdin;
\.
COPY universe_dw.cheque_unsold (ptid, reporting_date, payee_name, instrument_date, instrument_issuer_bank, drawer_name, relationship_type, cr_rating_counter_customer, grades_unrated_customer, currency, org_amount, tzs_amount, sector_sna_classification, past_due_days, impairment, bot_provision, batch_id) FROM '$$PATH$$/6546.dat';

--
-- Data for Name: cheques; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.cheques (ptid, reporting_date, cheque_number, issuer_name, issuer_banker, payee_name, payee_account_number, cheque_date, transaction_date, settlement_date, allowance_probable_loss, currency, org_amount_opening, tzs_amount_opening, org_amount_payment, tzs_amount_payment, org_amount_balance, tzs_amount_balance, batch_id) FROM stdin;
\.
COPY universe_dw.cheques (ptid, reporting_date, cheque_number, issuer_name, issuer_banker, payee_name, payee_account_number, cheque_date, transaction_date, settlement_date, allowance_probable_loss, currency, org_amount_opening, tzs_amount_opening, org_amount_payment, tzs_amount_payment, org_amount_balance, tzs_amount_balance, batch_id) FROM '$$PATH$$/6512.dat';

--
-- Data for Name: claim_treasury; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.claim_treasury (ptid, reporting_date, transaction_date, gov_institution_name, currency, org_amount_claimed, tzs_amount_claimed, usd_amount_claimed, value_date, maturity_date, past_due_days, provision, asset_classification_category, sector_sna_classification, batch_id) FROM stdin;
\.
COPY universe_dw.claim_treasury (ptid, reporting_date, transaction_date, gov_institution_name, currency, org_amount_claimed, tzs_amount_claimed, usd_amount_claimed, value_date, maturity_date, past_due_days, provision, asset_classification_category, sector_sna_classification, batch_id) FROM '$$PATH$$/6506.dat';

--
-- Data for Name: commercial_other_bills_purchased; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.commercial_other_bills_purchased (ptid, reporting_date, security_number, bill_holder, cr_rating_borrower, grades_unrated_banks, bill_type, bill_type_subcategory, transaction_date, value_date, maturity_date, org_amount, tzs_amount, usd_amount, bill_bearer, issuer_credit_rating, issuer_country, collateral_pledged, past_due_days, provision, asset_classification_category, sector_sna_classification, batch_id) FROM stdin;
\.
COPY universe_dw.commercial_other_bills_purchased (ptid, reporting_date, security_number, bill_holder, cr_rating_borrower, grades_unrated_banks, bill_type, bill_type_subcategory, transaction_date, value_date, maturity_date, org_amount, tzs_amount, usd_amount, bill_bearer, issuer_credit_rating, issuer_country, collateral_pledged, past_due_days, provision, asset_classification_category, sector_sna_classification, batch_id) FROM '$$PATH$$/6514.dat';

--
-- Data for Name: company_info; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.company_info (ptid, reporting_date, customer_identification_number, smr_code_non_government, account_number, currency, account_operation_status, establishment_date, legal_form, negative_client_status, number_of_employees_male, number_of_employees_female, registration_country, registration_number, tax_identification_number, trade_name, parent_name, parent_incorporation_number, group_id, sector_classification_sna, batch_id) FROM stdin;
\.
COPY universe_dw.company_info (ptid, reporting_date, customer_identification_number, smr_code_non_government, account_number, currency, account_operation_status, establishment_date, legal_form, negative_client_status, number_of_employees_male, number_of_employees_female, registration_country, registration_number, tax_identification_number, trade_name, parent_name, parent_incorporation_number, group_id, sector_classification_sna, batch_id) FROM '$$PATH$$/6568.dat';

--
-- Data for Name: company_info_business_address; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.company_info_business_address (ptid, postal_code, region, district, ward, street, house_number) FROM stdin;
\.
COPY universe_dw.company_info_business_address (ptid, postal_code, region, district, ward, street, house_number) FROM '$$PATH$$/6638.dat';

--
-- Data for Name: company_info_contact; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.company_info_contact (ptid, mobile_number, alternative_mobile_number, fixed_line_number, fax_number, email_address, social_media) FROM stdin;
\.
COPY universe_dw.company_info_contact (ptid, mobile_number, alternative_mobile_number, fixed_line_number, fax_number, email_address, social_media) FROM '$$PATH$$/6644.dat';

--
-- Data for Name: company_info_pri_address; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.company_info_pri_address (ptid, primary_postal_code, primary_region, primary_district, primary_ward, primary_street, primary_house_number, country, postal_office_box, zip_code) FROM stdin;
\.
COPY universe_dw.company_info_pri_address (ptid, primary_postal_code, primary_region, primary_district, primary_ward, primary_street, primary_house_number, country, postal_office_box, zip_code) FROM '$$PATH$$/6640.dat';

--
-- Data for Name: company_info_related_person; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.company_info_related_person (ptid, cell_phone, full_name, gender, relation_type, national_id, nationality, appointment_date, termination_date, rate_value_of_shares_owned, amount_value_of_shares_owned) FROM stdin;
\.
COPY universe_dw.company_info_related_person (ptid, cell_phone, full_name, gender, relation_type, national_id, nationality, appointment_date, termination_date, rate_value_of_shares_owned, amount_value_of_shares_owned) FROM '$$PATH$$/6636.dat';

--
-- Data for Name: company_info_relation_entity; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.company_info_relation_entity (ptid, entity_name, entity_type, certificate_incorporation, group_parent_code, share_owned_percentage, share_owned_amount, postal_code, region, district, ward, street, house_number) FROM stdin;
\.
COPY universe_dw.company_info_relation_entity (ptid, entity_name, entity_type, certificate_incorporation, group_parent_code, share_owned_percentage, share_owned_amount, postal_code, region, district, ward, street, house_number) FROM '$$PATH$$/6646.dat';

--
-- Data for Name: company_info_sec_address; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.company_info_sec_address (ptid, secondary_postal_code, secondary_region, secondary_district, secondary_ward, secondary_street, secondary_house_number, country, structured_address, text_address) FROM stdin;
\.
COPY universe_dw.company_info_sec_address (ptid, secondary_postal_code, secondary_region, secondary_district, secondary_ward, secondary_street, secondary_house_number, country, structured_address, text_address) FROM '$$PATH$$/6642.dat';

--
-- Data for Name: complaint_fraud_statistics; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.complaint_fraud_statistics (ptid, reporting_date, complainant_name, complainant_mobile, complaint_type, occurance_date, complaint_reporting_date, closure_date, agent_name, till_number, currency, tzs_amount, employee_id, referred_complaints, complaint_status, batch_id) FROM stdin;
\.
COPY universe_dw.complaint_fraud_statistics (ptid, reporting_date, complainant_name, complainant_mobile, complaint_type, occurance_date, complaint_reporting_date, closure_date, agent_name, till_number, currency, tzs_amount, employee_id, referred_complaints, complaint_status, batch_id) FROM '$$PATH$$/6598.dat';

--
-- Data for Name: complaints_fraud_statistics; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.complaints_fraud_statistics (ptid, reporting_date, policy_number, complaint_nature, occurance_date, complaint_reporting_date, closure_date, currency, tzs_s_amount, complaint_status, complaints_referred, batch_id) FROM stdin;
\.
COPY universe_dw.complaints_fraud_statistics (ptid, reporting_date, policy_number, complaint_nature, occurance_date, complaint_reporting_date, closure_date, currency, tzs_s_amount, complaint_status, complaints_referred, batch_id) FROM '$$PATH$$/6620.dat';

--
-- Data for Name: core_capital_deductions; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.core_capital_deductions (ptid, reporting_date, transaction_date, deductions_type, currency, org_amount, tzs_amount, batch_id) FROM stdin;
\.
COPY universe_dw.core_capital_deductions (ptid, reporting_date, transaction_date, deductions_type, currency, org_amount, tzs_amount, batch_id) FROM '$$PATH$$/6458.dat';

--
-- Data for Name: currency_swap; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.currency_swap (ptid, reporting_date, contract_date, maturity_date, counterpart_name, relationship_type, cr_rating_counter_part, grades_unrated_counter_part, currency_a, currency_b, org_amount_currency_a, tzs_amount_currency_a, spot_exchange_rate_currency_ab, org_amount_currency_b, tzs_amount_currency_b, exchange_rate_currency_a_2_tzs, exchange_rate_currency_b_2_tzs, foward_exchange_rate, foward_exchange_rate_currency_a_2_tzs, foward_exchange_rate_currency_b_2_tzs, transaction_date, tzs_foward_currency_a, tzs_foward_currency_b, value_date, cr_rating_counterpart, transaction_type, sector_sna_classification, batch_id) FROM stdin;
\.
COPY universe_dw.currency_swap (ptid, reporting_date, contract_date, maturity_date, counterpart_name, relationship_type, cr_rating_counter_part, grades_unrated_counter_part, currency_a, currency_b, org_amount_currency_a, tzs_amount_currency_a, spot_exchange_rate_currency_ab, org_amount_currency_b, tzs_amount_currency_b, exchange_rate_currency_a_2_tzs, exchange_rate_currency_b_2_tzs, foward_exchange_rate, foward_exchange_rate_currency_a_2_tzs, foward_exchange_rate_currency_b_2_tzs, transaction_date, tzs_foward_currency_a, tzs_foward_currency_b, value_date, cr_rating_counterpart, transaction_type, sector_sna_classification, batch_id) FROM '$$PATH$$/6556.dat';

--
-- Data for Name: customer_liabilities; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.customer_liabilities (ptid, reporting_date, draft_holder, transaction_date, value_date, maturity_date, currency, org_amount, tzs_amount, usd_amount, collateral_pledged, past_due_days, provision, asset_classification_category, sector_sna_classification, batch_id) FROM stdin;
\.
COPY universe_dw.customer_liabilities (ptid, reporting_date, draft_holder, transaction_date, value_date, maturity_date, currency, org_amount, tzs_amount, usd_amount, collateral_pledged, past_due_days, provision, asset_classification_category, sector_sna_classification, batch_id) FROM '$$PATH$$/6510.dat';

--
-- Data for Name: deposit_information; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.deposit_information (ptid, account_number, account_name, customer_category, branch_code, district_name, region, account_product_name, account_type_saving, deposit_category_public, deposit_account_status_true, reporting_date, client_identification_number, customer_country, client_type, relationship_type, transaction_unique_ref, time_stamp, service_channel_mobile_banking, currency, org_amount_opening, usd_amount_opening, tzs_amount_opening, org_amount_deposit, usd_amount_deposit, tzs_amount_deposit, org_amount_withdraw, usd_amount_withdraw, tzs_amount_withdraw, org_amount_closing, usd_amount_closing, tzs_amount_closing, sector_sna_classification, lien_number, org_amount_lien, usd_amount_lien, tzs_amount_lien, contract_date, maturity_date, annual_interest_rate, interest_rate_type, org_interest_amount, usd_interest_amount, tzs_interest_amount, batch_id) FROM stdin;
\.
COPY universe_dw.deposit_information (ptid, account_number, account_name, customer_category, branch_code, district_name, region, account_product_name, account_type_saving, deposit_category_public, deposit_account_status_true, reporting_date, client_identification_number, customer_country, client_type, relationship_type, transaction_unique_ref, time_stamp, service_channel_mobile_banking, currency, org_amount_opening, usd_amount_opening, tzs_amount_opening, org_amount_deposit, usd_amount_deposit, tzs_amount_deposit, org_amount_withdraw, usd_amount_withdraw, tzs_amount_withdraw, org_amount_closing, usd_amount_closing, tzs_amount_closing, sector_sna_classification, lien_number, org_amount_lien, usd_amount_lien, tzs_amount_lien, contract_date, maturity_date, annual_interest_rate, interest_rate_type, org_interest_amount, usd_interest_amount, tzs_interest_amount, batch_id) FROM '$$PATH$$/6476.dat';

--
-- Data for Name: digital_credit; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.digital_credit (ptid, reporting_date, customer_name, gender_male, disability_status, customer_identification_number, institution_name, branch_name, services_facilitator, product_name, tzs_loan_disbursed_amount, loan_disbursement_date, tzs_loan_balance, maturity_date, loan_id, last_deposit_date, last_deposit_amount, payments_installment, repayments_frequency, loan_amotization_type, cycle_number, loan_amount_paid, deliquence_date, restructuring_date, interest_rate, past_due_days, past_due_amount, currency, org_accrued_interest, tzs_accrued_interest, usd_accrued_interest, classification, provision, interest_suspended, batch_id) FROM stdin;
\.
COPY universe_dw.digital_credit (ptid, reporting_date, customer_name, gender_male, disability_status, customer_identification_number, institution_name, branch_name, services_facilitator, product_name, tzs_loan_disbursed_amount, loan_disbursement_date, tzs_loan_balance, maturity_date, loan_id, last_deposit_date, last_deposit_amount, payments_installment, repayments_frequency, loan_amotization_type, cycle_number, loan_amount_paid, deliquence_date, restructuring_date, interest_rate, past_due_days, past_due_amount, currency, org_accrued_interest, tzs_accrued_interest, usd_accrued_interest, classification, provision, interest_suspended, batch_id) FROM '$$PATH$$/6518.dat';

--
-- Data for Name: digital_saving; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.digital_saving (ptid, reporting_date, customer_identification_number, customer_name, gender_male, disability_status, bank_name, branch_code, services_facilitator, product_name, transaction_type, transaction_date, currency, org_deposit_amount, usd_deposit_amount, tzs_deposit_amount, org_transaction_amount, usd_transaction_amount, tzs_transaction_amount, org_deposit_balance, usd_deposit_balance, tzs_deposit_balance, batch_id) FROM stdin;
\.
COPY universe_dw.digital_saving (ptid, reporting_date, customer_identification_number, customer_name, gender_male, disability_status, bank_name, branch_code, services_facilitator, product_name, transaction_type, transaction_date, currency, org_deposit_amount, usd_deposit_amount, tzs_deposit_amount, org_transaction_amount, usd_transaction_amount, tzs_transaction_amount, org_deposit_balance, usd_deposit_balance, tzs_deposit_balance, batch_id) FROM '$$PATH$$/6460.dat';

--
-- Data for Name: dividends_payable; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.dividends_payable (ptid, reporting_date, dividend_type, currency, org_amount, tzs_amount, batch_id) FROM stdin;
\.
COPY universe_dw.dividends_payable (ptid, reporting_date, dividend_type, currency, org_amount, tzs_amount, batch_id) FROM '$$PATH$$/6452.dat';

--
-- Data for Name: equity_derivatives; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.equity_derivatives (ptid, reporting_date, contract_date, maturity_date, counterpart_name, cr_rating_counterpart, grades_unrated_counter_part, relationship_type, equity_derivatives_category, sector_sna_classification, counterpart_country, currency, org_contract_amount, tzs_contract_amount, fixed_interest_rate, tzs_start_stock_price_amount, org_stock_price_amount, tzs_stock_price_amount, trading_intent, batch_id) FROM stdin;
\.
COPY universe_dw.equity_derivatives (ptid, reporting_date, contract_date, maturity_date, counterpart_name, cr_rating_counterpart, grades_unrated_counter_part, relationship_type, equity_derivatives_category, sector_sna_classification, counterpart_country, currency, org_contract_amount, tzs_contract_amount, fixed_interest_rate, tzs_start_stock_price_amount, org_stock_price_amount, tzs_stock_price_amount, trading_intent, batch_id) FROM '$$PATH$$/6560.dat';

--
-- Data for Name: equity_investment; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.equity_investment (ptid, reporting_date, nameof_investee, country_of_investee, obligor_external_credit_rating, grades_unrated_banks, sector_sna_classification, relationship, sna_classification, number_shares_purchased, equity_investment_category, currency, org_purchase_price, tzs_purchase_price, usd_purchase_price, org_purchased_book_value_shares, tzs_purchased_book_value_shares, usd_purchased_book_value_shares, org_purchased_market_value_shares, tzs_purchased_market_value_shares, usd_purchased_market_value_shares, number_paid_up_equity_shares, org_value_paid_up_equity_shares, tzs_value_paid_up_equity_shares, usd_value_paid_up_equity_shares, trading_intent, provision, asset_classification_category, batch_id) FROM stdin;
\.
COPY universe_dw.equity_investment (ptid, reporting_date, nameof_investee, country_of_investee, obligor_external_credit_rating, grades_unrated_banks, sector_sna_classification, relationship, sna_classification, number_shares_purchased, equity_investment_category, currency, org_purchase_price, tzs_purchase_price, usd_purchase_price, org_purchased_book_value_shares, tzs_purchased_book_value_shares, usd_purchased_book_value_shares, org_purchased_market_value_shares, tzs_purchased_market_value_shares, usd_purchased_market_value_shares, number_paid_up_equity_shares, org_value_paid_up_equity_shares, tzs_value_paid_up_equity_shares, usd_value_paid_up_equity_shares, trading_intent, provision, asset_classification_category, batch_id) FROM '$$PATH$$/6486.dat';

--
-- Data for Name: export_letters_credit; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.export_letters_credit (ptid, reporting_date, opening_date, maturity_date, holder_name, relationship_type, beneficiary_name, beneficiary_country, cr_rating_counter_foreign_bank, gradesfor_unrated_foreign_bank, currency, org_amount, tzs_amount, asset_classification_type, sector_sna_classification, past_due_days, provision, batch_id) FROM stdin;
\.
COPY universe_dw.export_letters_credit (ptid, reporting_date, opening_date, maturity_date, holder_name, relationship_type, beneficiary_name, beneficiary_country, cr_rating_counter_foreign_bank, gradesfor_unrated_foreign_bank, currency, org_amount, tzs_amount, asset_classification_type, sector_sna_classification, past_due_days, provision, batch_id) FROM '$$PATH$$/6526.dat';

--
-- Data for Name: foreign_term_debt; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.foreign_term_debt (ptid, reporting_date, client_identification_number, borrower_name, creditor_name, org_country, credit_type_letter_of_credit, debt_registration_number, borrower_account_number, sector_borrower_sna_classification, loan_contract_date, loan_receipt_date, loan_maturity_date, annual_interest_rate, currency, org_loan_receipt_amount, tzs_loan_receipt_amount, instalment_remittance_date, org_principal_instalment_payment_amount, org_interest_instalment_payment_amount, tzs_principal_instalment_payment_amount, tzs_interest_instalment_payment_amount, org_arrears_principal_amount, org_arrears_interest_amount, tzs_arrears_principal_amount, tzs_arrears_interest_amount, org_principal_amount_paid, tzs_principal_amount_paid, org_interest_amount_paid, tzs_interest_amount_paid, batch_id) FROM stdin;
\.
COPY universe_dw.foreign_term_debt (ptid, reporting_date, client_identification_number, borrower_name, creditor_name, org_country, credit_type_letter_of_credit, debt_registration_number, borrower_account_number, sector_borrower_sna_classification, loan_contract_date, loan_receipt_date, loan_maturity_date, annual_interest_rate, currency, org_loan_receipt_amount, tzs_loan_receipt_amount, instalment_remittance_date, org_principal_instalment_payment_amount, org_interest_instalment_payment_amount, tzs_principal_instalment_payment_amount, tzs_interest_instalment_payment_amount, org_arrears_principal_amount, org_arrears_interest_amount, tzs_arrears_principal_amount, tzs_arrears_interest_amount, org_principal_amount_paid, tzs_principal_amount_paid, org_interest_amount_paid, tzs_interest_amount_paid, batch_id) FROM '$$PATH$$/6576.dat';

--
-- Data for Name: ibcm_transaction; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.ibcm_transaction (ptid, reporting_date, transaction_date, lender_name, borrower_name, transaction_type, tzs_amount, tenure, interest_rate, batch_id) FROM stdin;
\.
COPY universe_dw.ibcm_transaction (ptid, reporting_date, transaction_date, lender_name, borrower_name, transaction_type, tzs_amount, tenure, interest_rate, batch_id) FROM '$$PATH$$/6582.dat';

--
-- Data for Name: ifem_quotes; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.ifem_quotes (ptid, reporting_date, bank_code, counterparty_name, transaction_date, currency, tzs_bid_price, tzs_ask_price, batch_id) FROM stdin;
\.
COPY universe_dw.ifem_quotes (ptid, reporting_date, bank_code, counterparty_name, transaction_date, currency, tzs_bid_price, tzs_ask_price, batch_id) FROM '$$PATH$$/6580.dat';

--
-- Data for Name: ifem_transaction; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.ifem_transaction (ptid, reporting_date, transaction_date, value_date, market_type, seller_name, buyer_name, sector_sna_classification, buyer_economic_activity, buyer_country, org_currency, exchange_rate, org_amount_offered, org_amount_sold, tzs_amount_offered, tzs_amount_sold, batch_id) FROM stdin;
\.
COPY universe_dw.ifem_transaction (ptid, reporting_date, transaction_date, value_date, market_type, seller_name, buyer_name, sector_sna_classification, buyer_economic_activity, buyer_country, org_currency, exchange_rate, org_amount_offered, org_amount_sold, tzs_amount_offered, tzs_amount_sold, batch_id) FROM '$$PATH$$/6578.dat';

--
-- Data for Name: income_statement; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.income_statement (ptid, reporting_date, interest_income, interest_expense, bad_debts_written_off_not_provided, provision_bad_doubtful_debts, impairments_investments, non_interest_income, non_interest_expenses, income_tax_provision, extraordinary_credits_charge, non_core_credits_charges, amount_interest_income, amount_interest_expenses, amount_non_interest_income, amount_non_interest_expenses, amountnon_core_credits_charges, batch_id) FROM stdin;
\.
COPY universe_dw.income_statement (ptid, reporting_date, interest_income, interest_expense, bad_debts_written_off_not_provided, provision_bad_doubtful_debts, impairments_investments, non_interest_income, non_interest_expenses, income_tax_provision, extraordinary_credits_charge, non_core_credits_charges, amount_interest_income, amount_interest_expenses, amount_non_interest_income, amount_non_interest_expenses, amountnon_core_credits_charges, batch_id) FROM '$$PATH$$/6564.dat';

--
-- Data for Name: individual_birth_info; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.individual_birth_info (ptid, birth_postal_code, birth_region, birth_district, birth_ward, birth_street, birth_house_number, birth_date, birth_country, batch_id) FROM stdin;
\.
COPY universe_dw.individual_birth_info (ptid, birth_postal_code, birth_region, birth_district, birth_ward, birth_street, birth_house_number, birth_date, birth_country, batch_id) FROM '$$PATH$$/6622.dat';

--
-- Data for Name: individual_contact_info; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.individual_contact_info (ptid, mobile_number, alternative_mobile_number, fixed_line_number, fax_number, email_address, social_media, batch_id) FROM stdin;
\.
COPY universe_dw.individual_contact_info (ptid, mobile_number, alternative_mobile_number, fixed_line_number, fax_number, email_address, social_media, batch_id) FROM '$$PATH$$/6630.dat';

--
-- Data for Name: individual_employer_info; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.individual_employer_info (ptid, employer_postal_code, employer_region, employer_district, employer_ward, employer_street, employer_house_number, employer_name, business_nature, batch_id) FROM stdin;
\.
COPY universe_dw.individual_employer_info (ptid, employer_postal_code, employer_region, employer_district, employer_ward, employer_street, employer_house_number, employer_name, business_nature, batch_id) FROM '$$PATH$$/6628.dat';

--
-- Data for Name: individual_enterprenuer_info; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.individual_enterprenuer_info (ptid, business_name, establishment_date, business_registration_number, business_registration_date, business_license_number, tax_identification_number, batch_id) FROM stdin;
\.
COPY universe_dw.individual_enterprenuer_info (ptid, business_name, establishment_date, business_registration_number, business_registration_date, business_license_number, tax_identification_number, batch_id) FROM '$$PATH$$/6626.dat';

--
-- Data for Name: individual_ident_info; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.individual_ident_info (ptid, identification_type, registration_number, issuance_date, issuance_expiration_date, issuance_location, issuing_authority, batch_id) FROM stdin;
\.
COPY universe_dw.individual_ident_info (ptid, identification_type, registration_number, issuance_date, issuance_expiration_date, issuance_location, issuing_authority, batch_id) FROM '$$PATH$$/6624.dat';

--
-- Data for Name: individual_info; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.individual_info (ptid, reporting_date, customer_identification_number, account_number, currency, account_operation_status, classification, smr_code, negative_client_status, first_name, middle_names, other_names, full_names, present_surname, birth_surname, gender_male, marital_status, number_spouse, spouses_full_name, spouse_identification_type, maiden_name, nationality, citizenship, residency, profession, social_status, employer_status, employer_name, monthly_income, monthly_expenses, number_of_dependants, education_level, average_monthly_expenditure, status, sna_sector_classification, fate_status, batch_id) FROM stdin;
\.
COPY universe_dw.individual_info (ptid, reporting_date, customer_identification_number, account_number, currency, account_operation_status, classification, smr_code, negative_client_status, first_name, middle_names, other_names, full_names, present_surname, birth_surname, gender_male, marital_status, number_spouse, spouses_full_name, spouse_identification_type, maiden_name, nationality, citizenship, residency, profession, social_status, employer_status, employer_name, monthly_income, monthly_expenses, number_of_dependants, education_level, average_monthly_expenditure, status, sna_sector_classification, fate_status, batch_id) FROM '$$PATH$$/6566.dat';

--
-- Data for Name: individual_pri_address; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.individual_pri_address (ptid, primary_postal_code, primary_region, primary_district, primary_ward, primary_street, primary_house_number, primary_country, batch_id) FROM stdin;
\.
COPY universe_dw.individual_pri_address (ptid, primary_postal_code, primary_region, primary_district, primary_ward, primary_street, primary_house_number, primary_country, batch_id) FROM '$$PATH$$/6632.dat';

--
-- Data for Name: individual_sec_address; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.individual_sec_address (ptid, secondary_postal_code, secondary_region, secondary_district, secondary_ward, secondary_street, secondary_house_number, secondary_country, batch_id) FROM stdin;
\.
COPY universe_dw.individual_sec_address (ptid, secondary_postal_code, secondary_region, secondary_district, secondary_ward, secondary_street, secondary_house_number, secondary_country, batch_id) FROM '$$PATH$$/6634.dat';

--
-- Data for Name: institution_premises; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.institution_premises (ptid, reporting_date, asset_category, usage_of_premises_furnitur_and_equipment, acquisition_date, asset_type, currency, org_amount, usd_amount, tzs_amount, disposal_date, disposed_asset_value, org_depreciation, usd_depreciation, tzs_depreciation, org_accum_depr_impairment, usd_accum_depr_impairment, tzs_accum_depr_impairment, org_net_book_value, usd_net_book_value, tzs_net_book_value, batch_id) FROM stdin;
\.
COPY universe_dw.institution_premises (ptid, reporting_date, asset_category, usage_of_premises_furnitur_and_equipment, acquisition_date, asset_type, currency, org_amount, usd_amount, tzs_amount, disposal_date, disposed_asset_value, org_depreciation, usd_depreciation, tzs_depreciation, org_accum_depr_impairment, usd_accum_depr_impairment, tzs_accum_depr_impairment, org_net_book_value, usd_net_book_value, tzs_net_book_value, batch_id) FROM '$$PATH$$/6508.dat';

--
-- Data for Name: insurance_claim; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.insurance_claim (ptid, reporting_date, policy_number, insurer_status, claim_ref_number, claim_nature, currency, org_claim_amount, tzs_sum_claim_amount, org_paid_claim_amount, tzs_paid_claim_amount, incident_occurence_date, incident_reporting_date, claim_date, claim_status_open, repudiation_reason, claim_closure_date, batch_id) FROM stdin;
\.
COPY universe_dw.insurance_claim (ptid, reporting_date, policy_number, insurer_status, claim_ref_number, claim_nature, currency, org_claim_amount, tzs_sum_claim_amount, org_paid_claim_amount, tzs_paid_claim_amount, incident_occurence_date, incident_reporting_date, claim_date, claim_status_open, repudiation_reason, claim_closure_date, batch_id) FROM '$$PATH$$/6616.dat';

--
-- Data for Name: insurance_commission; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.insurance_commission (ptid, reporting_date, policy_number, currency, org_commission_received_amount, tzs_commission_received_amount, commission_received_date, batch_id) FROM stdin;
\.
COPY universe_dw.insurance_commission (ptid, reporting_date, policy_number, currency, org_commission_received_amount, tzs_commission_received_amount, commission_received_date, batch_id) FROM '$$PATH$$/6618.dat';

--
-- Data for Name: insurance_underwritting; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.insurance_underwritting (ptid, reporting_date, customer_identification_number, policy_number, client_name, insurer_name, insurer_status, client_country, insurance_business_type, class_business, sub_class_business_01, sub_class_business_02, insurance_product_name, gender, disability, client_type, related_party, relationship_category, branch_name, branch_code, region, district_name, responsible_officer, responsible_supervisor, currency, org_sum_insured_amount, tzs_sum_insured_amount, frequency_premium, commision_rate, policy_start_date, policy_maturity_date, sector_sna_classfication, economic_activity, batch_id) FROM stdin;
\.
COPY universe_dw.insurance_underwritting (ptid, reporting_date, customer_identification_number, policy_number, client_name, insurer_name, insurer_status, client_country, insurance_business_type, class_business, sub_class_business_01, sub_class_business_02, insurance_product_name, gender, disability, client_type, related_party, relationship_category, branch_name, branch_code, region, district_name, responsible_officer, responsible_supervisor, currency, org_sum_insured_amount, tzs_sum_insured_amount, frequency_premium, commision_rate, policy_start_date, policy_maturity_date, sector_sna_classfication, economic_activity, batch_id) FROM '$$PATH$$/6614.dat';

--
-- Data for Name: inter_branch_float_item; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.inter_branch_float_item (ptid, reporting_date, branch_name, branch_code, currency, org_amount_float, tzs_amount_float, usd_amount_float, past_due_days, allowance_probable_loss, classification, batch_id) FROM stdin;
\.
COPY universe_dw.inter_branch_float_item (ptid, reporting_date, branch_name, branch_code, currency, org_amount_float, tzs_amount_float, usd_amount_float, past_due_days, allowance_probable_loss, classification, batch_id) FROM '$$PATH$$/6462.dat';

--
-- Data for Name: interbank_loan_payable; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.interbank_loan_payable (ptid, reporting_date, lender_name, account_number, lender_country, borrowering_type, transaction_date, disbursement_date, maturity_date, currency, org_amount_opening, tzs_amount_opening, usd_amount_opening, org_amount_repayment, tzs_amount_repayment, usd_amount_repayment, org_amount_closing, tzs_amount_closing, usd_amount_closing, tenure_days, annual_interest_rate, interest_rate_type, batch_id) FROM stdin;
\.
COPY universe_dw.interbank_loan_payable (ptid, reporting_date, lender_name, account_number, lender_country, borrowering_type, transaction_date, disbursement_date, maturity_date, currency, org_amount_opening, tzs_amount_opening, usd_amount_opening, org_amount_repayment, tzs_amount_repayment, usd_amount_repayment, org_amount_closing, tzs_amount_closing, usd_amount_closing, tenure_days, annual_interest_rate, interest_rate_type, batch_id) FROM '$$PATH$$/6480.dat';

--
-- Data for Name: interbank_loans_receivable; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.interbank_loans_receivable (ptid, reporting_date, borrowers_name, borrowers_country, relationship_type, external_rating_correspondent_borrower, grades_unrated_borrower, loan_type, issue_date, loan_maturity_date, currency, org_loan_amount, tzs_loan_amount, usd_loan_amount, interest_rate, past_due_days, org_accrued_interest_amount, tzs_accrued_interest_amount, allowance_probable_loss, asset_classification, batch_id) FROM stdin;
\.
COPY universe_dw.interbank_loans_receivable (ptid, reporting_date, borrowers_name, borrowers_country, relationship_type, external_rating_correspondent_borrower, grades_unrated_borrower, loan_type, issue_date, loan_maturity_date, currency, org_loan_amount, tzs_loan_amount, usd_loan_amount, interest_rate, past_due_days, org_accrued_interest_amount, tzs_accrued_interest_amount, allowance_probable_loss, asset_classification, batch_id) FROM '$$PATH$$/6500.dat';

--
-- Data for Name: interest_rate_futures; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.interest_rate_futures (ptid, reporting_date, contract_date, expiry_date, underlying_asset_type, counterpart_name, counterpart_country, relationship_type, cr_rating_counterpart, grades_unrated_counter_part, currency, org_contract_start_amount, tzs_contract_start_amount, org_contract_close_amount, tzs_contract_close_amount, org_margin_acc_start_amount, tzs_margin_acc_start_amount, org_margin_acc_close_amount, tzs_margin_acc_close_amount, fixed_interest_rate, float_interest_rate, libor_rate, tax_rate, arrangement_fee, sector_sna_classification, trading_intent, batch_id) FROM stdin;
\.
COPY universe_dw.interest_rate_futures (ptid, reporting_date, contract_date, expiry_date, underlying_asset_type, counterpart_name, counterpart_country, relationship_type, cr_rating_counterpart, grades_unrated_counter_part, currency, org_contract_start_amount, tzs_contract_start_amount, org_contract_close_amount, tzs_contract_close_amount, org_margin_acc_start_amount, tzs_margin_acc_start_amount, org_margin_acc_close_amount, tzs_margin_acc_close_amount, fixed_interest_rate, float_interest_rate, libor_rate, tax_rate, arrangement_fee, sector_sna_classification, trading_intent, batch_id) FROM '$$PATH$$/6562.dat';

--
-- Data for Name: interest_rate_swap; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.interest_rate_swap (ptid, reporting_date, contract_date, maturity_date, counterpart_name, counterpart_country, relationship_type, cr_rating_counterpart, gradesfor_unrated_counter_part, currency, org_contract_amount, tzs_contract_amount, fixed_interest_rate, float_interest_rate, libor_rate, tax_rate, arrangement_fee, sector_sna_classification, trading_intent, batch_id) FROM stdin;
\.
COPY universe_dw.interest_rate_swap (ptid, reporting_date, contract_date, maturity_date, counterpart_name, counterpart_country, relationship_type, cr_rating_counterpart, gradesfor_unrated_counter_part, currency, org_contract_amount, tzs_contract_amount, fixed_interest_rate, float_interest_rate, libor_rate, tax_rate, arrangement_fee, sector_sna_classification, trading_intent, batch_id) FROM '$$PATH$$/6558.dat';

--
-- Data for Name: interest_trust_account; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.interest_trust_account (ptid, reporting_date, trust_account_number, trust_account_name, bank_name, currency, interest_trust_account_balance, interest_approved_for_distribution, actual_interest_distributed_amount, transaction_type, undistributedinterest_amount, transaction_date, transaction_id, batch_id) FROM stdin;
\.
COPY universe_dw.interest_trust_account (ptid, reporting_date, trust_account_number, trust_account_name, bank_name, currency, interest_trust_account_balance, interest_approved_for_distribution, actual_interest_distributed_amount, transaction_type, undistributedinterest_amount, transaction_date, transaction_id, batch_id) FROM '$$PATH$$/6570.dat';

--
-- Data for Name: internet_banking; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.internet_banking (ptid, reporting_date, customer_name, gender, account_status, transaction_date, last_transaction_date, unique_identification_number, customer_category, transaction_type, service_category, sub_service_category, transaction_ref, currency, org_amount, tzs_amount, value_added_tax_amount, excise_duty_amount, electronic_levy_amount, batch_id) FROM stdin;
\.
COPY universe_dw.internet_banking (ptid, reporting_date, customer_name, gender, account_status, transaction_date, last_transaction_date, unique_identification_number, customer_category, transaction_type, service_category, sub_service_category, transaction_ref, currency, org_amount, tzs_amount, value_added_tax_amount, excise_duty_amount, electronic_levy_amount, batch_id) FROM '$$PATH$$/6572.dat';

--
-- Data for Name: inv_debt_securities; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.inv_debt_securities (ptid, reporting_date, security_number, security_type, security_issuer_name, external_issuer_ratting, grades_unrated_banks, security_issuer_country, sna_issuer_sector, currency, org_cost_value_amount, tzs_cost_value_amount, usd_cost_value_amount, org_face_value_amount, tzsg_face_value_amount, usdg_face_value_amount, org_fair_value_amount, tzsg_fair_value_amount, usdg_fair_value_amount, interest_rate, purchase_date, value_date, maturity_date, trading_intent, security_encumbarance_status, batch_id) FROM stdin;
\.
COPY universe_dw.inv_debt_securities (ptid, reporting_date, security_number, security_type, security_issuer_name, external_issuer_ratting, grades_unrated_banks, security_issuer_country, sna_issuer_sector, currency, org_cost_value_amount, tzs_cost_value_amount, usd_cost_value_amount, org_face_value_amount, tzsg_face_value_amount, usdg_face_value_amount, org_fair_value_amount, tzsg_fair_value_amount, usdg_fair_value_amount, interest_rate, purchase_date, value_date, maturity_date, trading_intent, security_encumbarance_status, batch_id) FROM '$$PATH$$/6488.dat';

--
-- Data for Name: inward_bills; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.inward_bills (ptid, reporting_date, opening_date, maturity_date, holder_name, relationship_type, beneficiary_name, beneficiary_country, cr_rating_counter_drawer_bank, gradesfor_unrated_drawer_bank, currency, org_amount, tzs_amount, asset_classification_type, sna_classification, past_due_days, provision, batch_id) FROM stdin;
\.
COPY universe_dw.inward_bills (ptid, reporting_date, opening_date, maturity_date, holder_name, relationship_type, beneficiary_name, beneficiary_country, cr_rating_counter_drawer_bank, gradesfor_unrated_drawer_bank, currency, org_amount, tzs_amount, asset_classification_type, sna_classification, past_due_days, provision, batch_id) FROM '$$PATH$$/6530.dat';

--
-- Data for Name: late_deposit_payments; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.late_deposit_payments (ptid, reporting_date, deposit_date, depositor_name, relationship_type, grades_unrated_customer, currency, org_deposited_amount, tzs_deposited_amount, sector_sna_classification, past_due_days, impairment, bot_provision, batch_id) FROM stdin;
\.
COPY universe_dw.late_deposit_payments (ptid, reporting_date, deposit_date, depositor_name, relationship_type, grades_unrated_customer, currency, org_deposited_amount, tzs_deposited_amount, sector_sna_classification, past_due_days, impairment, bot_provision, batch_id) FROM '$$PATH$$/6544.dat';

--
-- Data for Name: loan_information; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.loan_information (ptid, reporting_date, customer_identification_number, account_number, client_name, country_of_borrower, cr_rating_borrower, grades_unrated_banks, category_borrower, gender_male, disability, client_type, group_name, group_code, related_party, relationship_category, loan_number, loan_type, loan_economic_activity, loan_phase, transfer_status, purpose_mortgage, purpose_other_loans, source_fund_mortgage, amortization_type, branch_name, branch_code, district_name, region, loan_officer, loan_supervisor, group_village_number, cycle_number, loan_installment, frequency_of_repayment, currency, contact_date, org_sanction_amount, usd_sanction_amount, tzs_sanction_amount, org_disbursed_amount, usd_disbursed_amount, tzs_disbursed_amount, disbursement_date, maturity_date, real_end_date, restructuring_date, org_outstanding_principal_amount, usd_outstanding_principal_amount, tzs_outstanding_principal_amount, org_installment_amount, usd_installment_amount, tzs_installment_amount, loan_installment_paid, grace_period_payment_principal, annual_interest_rate, first_installment_payment_date, last_payment_date, collateral_pledged, collateral_value, loan_flag_type_restructured, past_due_days, past_due_amount, org_accrued_interest_amount, usd_accrued_interest_amount, tzs_accrued_interest_amount, org_penalty_charged_amount, usd_penalty_charged_amount, tzs_penalty_charged_amount, org_penalty_paid_amount, usd_penalty_paid_amount, tzs_penalty_paid_amount, org_loan_fees_charged_amount, usd_loan_fees_charged_amount, tzs_loan_fees_charged_amount, org_tot_monthly_payment_amount, usd_tot_monthly_payment_amount, tzs_tot_monthly_payment_amount, sector_sna_classification, asset_classification_category, neg_status_contract, customer_role, provision, trading_intent, suspended_interest, batch_id) FROM stdin;
\.
COPY universe_dw.loan_information (ptid, reporting_date, customer_identification_number, account_number, client_name, country_of_borrower, cr_rating_borrower, grades_unrated_banks, category_borrower, gender_male, disability, client_type, group_name, group_code, related_party, relationship_category, loan_number, loan_type, loan_economic_activity, loan_phase, transfer_status, purpose_mortgage, purpose_other_loans, source_fund_mortgage, amortization_type, branch_name, branch_code, district_name, region, loan_officer, loan_supervisor, group_village_number, cycle_number, loan_installment, frequency_of_repayment, currency, contact_date, org_sanction_amount, usd_sanction_amount, tzs_sanction_amount, org_disbursed_amount, usd_disbursed_amount, tzs_disbursed_amount, disbursement_date, maturity_date, real_end_date, restructuring_date, org_outstanding_principal_amount, usd_outstanding_principal_amount, tzs_outstanding_principal_amount, org_installment_amount, usd_installment_amount, tzs_installment_amount, loan_installment_paid, grace_period_payment_principal, annual_interest_rate, first_installment_payment_date, last_payment_date, collateral_pledged, collateral_value, loan_flag_type_restructured, past_due_days, past_due_amount, org_accrued_interest_amount, usd_accrued_interest_amount, tzs_accrued_interest_amount, org_penalty_charged_amount, usd_penalty_charged_amount, tzs_penalty_charged_amount, org_penalty_paid_amount, usd_penalty_paid_amount, tzs_penalty_paid_amount, org_loan_fees_charged_amount, usd_loan_fees_charged_amount, tzs_loan_fees_charged_amount, org_tot_monthly_payment_amount, usd_tot_monthly_payment_amount, tzs_tot_monthly_payment_amount, sector_sna_classification, asset_classification_category, neg_status_contract, customer_role, provision, trading_intent, suspended_interest, batch_id) FROM '$$PATH$$/6502.dat';

--
-- Data for Name: microfinance_segment_loans; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.microfinance_segment_loans (ptid, reporting_date, customer_identification_number, account_number, client_name, client_category, gender, age, disability_status, loan_number, loan_industry_classification, loan_sub_industry, microfinance_loans_type, amortization_type, branch_name, branch_code, loan_officer, loan_supervisor, group_village_number, cycle_number, currency, org_sanction_amount, tzs_sanction_amount, usd_sanction_amount, tzs_disbursed_amount, org_disbursed_amount, usd_disbursed_amount, disbursement_date, maturity_date, restructuring_date, write_off_date, amount_written_off, agreed_loan_installments, repayment_frequency, org_outstanding_principal_amount, tzs_outstanding_principal_amount, usd_outstanding_principal_amount, loan_installment_paid, grace_period_payment_principal, annual_interest_rate, first_installment_payment_date, loan_collateral, collateral_value, loan_flag_type, past_due_days, past_due_amount, org_accrued_interest_amount, tzs_accrued_interest_amount, usd_accrued_interest_amount, asset_classification_category, provision, batch_id) FROM stdin;
\.
COPY universe_dw.microfinance_segment_loans (ptid, reporting_date, customer_identification_number, account_number, client_name, client_category, gender, age, disability_status, loan_number, loan_industry_classification, loan_sub_industry, microfinance_loans_type, amortization_type, branch_name, branch_code, loan_officer, loan_supervisor, group_village_number, cycle_number, currency, org_sanction_amount, tzs_sanction_amount, usd_sanction_amount, tzs_disbursed_amount, org_disbursed_amount, usd_disbursed_amount, disbursement_date, maturity_date, restructuring_date, write_off_date, amount_written_off, agreed_loan_installments, repayment_frequency, org_outstanding_principal_amount, tzs_outstanding_principal_amount, usd_outstanding_principal_amount, loan_installment_paid, grace_period_payment_principal, annual_interest_rate, first_installment_payment_date, loan_collateral, collateral_value, loan_flag_type, past_due_days, past_due_amount, org_accrued_interest_amount, tzs_accrued_interest_amount, usd_accrued_interest_amount, asset_classification_category, provision, batch_id) FROM '$$PATH$$/6520.dat';

--
-- Data for Name: mno_funds_transfer; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.mno_funds_transfer (ptid, reporting_date, transaction_id, transaction_date, transaction_code, transfer_channel, sub_category_transfer_channel, sender_account_number, recipient_name, recipient_identification, recipient_bank_name, recipient_account_number, country, recipient_mobile_number, transaction_type, currency, org_amount, tzs_amount, sender_instruction, batch_id) FROM stdin;
\.
COPY universe_dw.mno_funds_transfer (ptid, reporting_date, transaction_id, transaction_date, transaction_code, transfer_channel, sub_category_transfer_channel, sender_account_number, recipient_name, recipient_identification, recipient_bank_name, recipient_account_number, country, recipient_mobile_number, transaction_type, currency, org_amount, tzs_amount, sender_instruction, batch_id) FROM '$$PATH$$/6590.dat';

--
-- Data for Name: mobile_banking; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.mobile_banking (ptid, reporting_date, customer_name, gender, account_status, transaction_date, last_transaction_date, unique_identification_number, customer_category, transaction_type, service_category, sub_service_category, transaction_ref, currency, org_amount, tzs_amount, value_added_tax_amount, excise_duty_amount, electronic_levy_amount, batch_id) FROM stdin;
\.
COPY universe_dw.mobile_banking (ptid, reporting_date, customer_name, gender, account_status, transaction_date, last_transaction_date, unique_identification_number, customer_category, transaction_type, service_category, sub_service_category, transaction_ref, currency, org_amount, tzs_amount, value_added_tax_amount, excise_duty_amount, electronic_levy_amount, batch_id) FROM '$$PATH$$/6574.dat';

--
-- Data for Name: other_asset; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.other_asset (ptid, reporting_date, asset_type, asset_type_sub_category, transaction_date, maturity_date, debtor_name, debtor_country, currency, org_amount, usd_amount, tzs_amount, sector_sna_classification, past_due_days, asset_classification_category, provision, batch_id) FROM stdin;
\.
COPY universe_dw.other_asset (ptid, reporting_date, asset_type, asset_type_sub_category, transaction_date, maturity_date, debtor_name, debtor_country, currency, org_amount, usd_amount, tzs_amount, sector_sna_classification, past_due_days, asset_classification_category, provision, batch_id) FROM '$$PATH$$/6490.dat';

--
-- Data for Name: other_capital_account; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.other_capital_account (ptid, reporting_date, transaction_date, transaction_type, reserve_category, reserve_sub_category, currency, org_amount, tzs_amount, batch_id) FROM stdin;
\.
COPY universe_dw.other_capital_account (ptid, reporting_date, transaction_date, transaction_type, reserve_category, reserve_sub_category, currency, org_amount, tzs_amount, batch_id) FROM '$$PATH$$/6456.dat';

--
-- Data for Name: other_liability; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.other_liability (ptid, reporting_date, liability_category, counterparty_name, counterparty_country, transaction_date, value_date, maturity_date, currency, org_amount_opening, usd_amount_opening, tzs_amount_opening, org_amount_payment, usd_amount_payment, tzs_amount_payment, org_amount_balance, usd_amount_balance, tzs_amount_balance, sector_sna_classification, batch_id) FROM stdin;
\.
COPY universe_dw.other_liability (ptid, reporting_date, liability_category, counterparty_name, counterparty_country, transaction_date, value_date, maturity_date, currency, org_amount_opening, usd_amount_opening, tzs_amount_opening, org_amount_payment, usd_amount_payment, tzs_amount_payment, org_amount_balance, usd_amount_balance, tzs_amount_balance, sector_sna_classification, batch_id) FROM '$$PATH$$/6482.dat';

--
-- Data for Name: outstanding_acceptances; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.outstanding_acceptances (ptid, reporting_date, acceptance_type, beneficiary_name, transaction_date, currency, org_amount, usd_amount, tzs_amount, sector_lender_sna_classification, batch_id) FROM stdin;
\.
COPY universe_dw.outstanding_acceptances (ptid, reporting_date, acceptance_type, beneficiary_name, transaction_date, currency, org_amount, usd_amount, tzs_amount, sector_lender_sna_classification, batch_id) FROM '$$PATH$$/6474.dat';

--
-- Data for Name: outstanding_guarantees; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.outstanding_guarantees (ptid, reporting_date, opening_date, maturity_date, beneficiary_name, relationship_type, guarantee_types, collateral_types_gold, beneficiary_country, cr_rating_counter_foreign_bank, gradesfor_unrated_foreign_bank, currency, org_amount, tzs_amount, past_due_days, asset_classification_type, sector_sna_classification, provision, batch_id) FROM stdin;
\.
COPY universe_dw.outstanding_guarantees (ptid, reporting_date, opening_date, maturity_date, beneficiary_name, relationship_type, guarantee_types, collateral_types_gold, beneficiary_country, cr_rating_counter_foreign_bank, gradesfor_unrated_foreign_bank, currency, org_amount, tzs_amount, past_due_days, asset_classification_type, sector_sna_classification, provision, batch_id) FROM '$$PATH$$/6524.dat';

--
-- Data for Name: outstanding_letters_credit; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.outstanding_letters_credit (ptid, reporting_date, letters_credit_type, collateral_type, opening_date, maturity_date, holder_name, relationship_type, beneficiary_name, beneficiary_country, cr_rating_counter_importer, gradesfor_unrated_importer, currency, org_amount, tzs_amount, org_outstanding_deposits_amount, tzs_outstanding_deposits_amount, past_due_days, asset_classification_type, sector_sna_classification, provision, batch_id) FROM stdin;
\.
COPY universe_dw.outstanding_letters_credit (ptid, reporting_date, letters_credit_type, collateral_type, opening_date, maturity_date, holder_name, relationship_type, beneficiary_name, beneficiary_country, cr_rating_counter_importer, gradesfor_unrated_importer, currency, org_amount, tzs_amount, org_outstanding_deposits_amount, tzs_outstanding_deposits_amount, past_due_days, asset_classification_type, sector_sna_classification, provision, batch_id) FROM '$$PATH$$/6528.dat';

--
-- Data for Name: outward_bills; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.outward_bills (ptid, reporting_date, opening_date, maturity_date, holder_name, relationship_type, beneficiary_name, beneficiary_country, cr_rating_counter_borrower, gradesfor_unrated_borrower, currency, org_amount, usd_amount, tzs_amount, past_due_days, asset_classification_type, sna_classification, impairment, bot_provision, batch_id) FROM stdin;
\.
COPY universe_dw.outward_bills (ptid, reporting_date, opening_date, maturity_date, holder_name, relationship_type, beneficiary_name, beneficiary_country, cr_rating_counter_borrower, gradesfor_unrated_borrower, currency, org_amount, usd_amount, tzs_amount, past_due_days, asset_classification_type, sna_classification, impairment, bot_provision, batch_id) FROM '$$PATH$$/6532.dat';

--
-- Data for Name: overdraft; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.overdraft (ptid, reporting_date, account_number, customer_identification_number, client_name, client_type, borrower_country, cr_rating_borrower, grades_unrated_banks, group_code, related_entity_name, related_party, relationship_category, loan_product_type, overdraft_economic_activity, loan_phase, transfer_status, purpose_other_loans, contact_date, branch_name, branch_code, loan_officer, loan_supervisor, currency, org_sanctioned_amount, tzs_sanctioned_amount, org_utilised_amount, tzs_utilised_amount, org_cr_usage_last_30_days_amount, tzs_cr_usage_last_30_days_amount, disbursement_date, expiry_date, real_end_date, org_outstanding_amount, tzs_outstanding_amount, org_outstanding_principal_amount, latest_customer_credit_date, latest_credit_amount, interest_rate, collateral_pledged, collateral_value, restructured_loans, past_due_days, past_due_amount, org_accrued_interest_amount, tzs_accrued_interest_amount, org_penalty_charged_amount, tzs_penalty_charged_amount, org_penalty_paid_amount, tzs_penalty_paid_amount, org_loan_fees_charged_amount, tzs_loan_fees_charged_amount, org_tot_monthly_payment_amount, tzs_tot_monthly_payment_amount, interest_paid_total, asset_classification_category, sector_sna_classification, neg_status_contract, customer_role, provision, batch_id) FROM stdin;
\.
COPY universe_dw.overdraft (ptid, reporting_date, account_number, customer_identification_number, client_name, client_type, borrower_country, cr_rating_borrower, grades_unrated_banks, group_code, related_entity_name, related_party, relationship_category, loan_product_type, overdraft_economic_activity, loan_phase, transfer_status, purpose_other_loans, contact_date, branch_name, branch_code, loan_officer, loan_supervisor, currency, org_sanctioned_amount, tzs_sanctioned_amount, org_utilised_amount, tzs_utilised_amount, org_cr_usage_last_30_days_amount, tzs_cr_usage_last_30_days_amount, disbursement_date, expiry_date, real_end_date, org_outstanding_amount, tzs_outstanding_amount, org_outstanding_principal_amount, latest_customer_credit_date, latest_credit_amount, interest_rate, collateral_pledged, collateral_value, restructured_loans, past_due_days, past_due_amount, org_accrued_interest_amount, tzs_accrued_interest_amount, org_penalty_charged_amount, tzs_penalty_charged_amount, org_penalty_paid_amount, tzs_penalty_paid_amount, org_loan_fees_charged_amount, tzs_loan_fees_charged_amount, org_tot_monthly_payment_amount, tzs_tot_monthly_payment_amount, interest_paid_total, asset_classification_category, sector_sna_classification, neg_status_contract, customer_role, provision, batch_id) FROM '$$PATH$$/6504.dat';

--
-- Data for Name: pos_information; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.pos_information (ptid, postal_code, region, district, ward, street, house_number, reporting_date, branch_name, pos_branch_code, pos_number, qr_fsr_code, pos_holder_category, pos_holder_name, pos_holder_nin, pos_holder_tin, gps_coordinates, linked_account, issue_date, return_date, batch_id) FROM stdin;
\.
COPY universe_dw.pos_information (ptid, postal_code, region, district, ward, street, house_number, reporting_date, branch_name, pos_branch_code, pos_number, qr_fsr_code, pos_holder_category, pos_holder_name, pos_holder_nin, pos_holder_tin, gps_coordinates, linked_account, issue_date, return_date, batch_id) FROM '$$PATH$$/6600.dat';

--
-- Data for Name: pos_transaction; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.pos_transaction (ptid, reporting_date, pos_number, transaction_date, transaction_id, transaction_type, currency, org_currency_transaction_amount, tzs_transaction_amount, value_added_tax_amount, excise_duty_amount, electronic_levy_amount, batch_id) FROM stdin;
\.
COPY universe_dw.pos_transaction (ptid, reporting_date, pos_number, transaction_date, transaction_id, transaction_type, currency, org_currency_transaction_amount, tzs_transaction_amount, value_added_tax_amount, excise_duty_amount, electronic_levy_amount, batch_id) FROM '$$PATH$$/6602.dat';

--
-- Data for Name: pre_operating_expenses; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.pre_operating_expenses (ptid, reporting_date, currency, org_amount, usd_amount, tzs_amount, batch_id) FROM stdin;
\.
COPY universe_dw.pre_operating_expenses (ptid, reporting_date, currency, org_amount, usd_amount, tzs_amount, batch_id) FROM '$$PATH$$/6554.dat';

--
-- Data for Name: premises_furniture_equipment; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.premises_furniture_equipment (ptid, reporting_date, asset_category, usage_premises_furniture_equipment, acquisition_date, asset_type, currency, org_amount, tzs_amount, usd_amount, disposal_date, asset_disposed_value, org_cur_depr, tzs_cur_depr, usd_cur_depr, org_cur_accum_depr_impairment, tzs_cur_accum_depr_impairment, usd_cur_accum_depr_impairment, org_cur_net_book_value, tzs_cur_net_book_value, usd_cur_net_book_value, batch_id) FROM stdin;
\.
COPY universe_dw.premises_furniture_equipment (ptid, reporting_date, asset_category, usage_premises_furniture_equipment, acquisition_date, asset_type, currency, org_amount, tzs_amount, usd_amount, disposal_date, asset_disposed_value, org_cur_depr, tzs_cur_depr, usd_cur_depr, org_cur_accum_depr_impairment, tzs_cur_accum_depr_impairment, usd_cur_accum_depr_impairment, org_cur_net_book_value, tzs_cur_net_book_value, usd_cur_net_book_value, batch_id) FROM '$$PATH$$/6522.dat';

--
-- Data for Name: remittances; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.remittances (ptid, reporting_date, transaction_id, transaction_code, transaction_date, transaction_type, transaction_purposes, remittance_type, sender_name, sender_identification, mobile_number, transfer_channel, sub_category_transferchannel, recipient_name, recipient_identity_number, recipient_mobile_number, region_beneficiary, terminating_channel, terminating_channel_name, currency, org_amount, tzs_amount, tzs_inward_remittance, agent_principal, batch_id) FROM stdin;
\.
COPY universe_dw.remittances (ptid, reporting_date, transaction_id, transaction_code, transaction_date, transaction_type, transaction_purposes, remittance_type, sender_name, sender_identification, mobile_number, transfer_channel, sub_category_transferchannel, recipient_name, recipient_identity_number, recipient_mobile_number, region_beneficiary, terminating_channel, terminating_channel_name, currency, org_amount, tzs_amount, tzs_inward_remittance, agent_principal, batch_id) FROM '$$PATH$$/6610.dat';

--
-- Data for Name: remittances_receiver; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.remittances_receiver (ptid, remitance_ptid, region, district, ward, street, recipient_country, recipient_house_number) FROM stdin;
\.
COPY universe_dw.remittances_receiver (ptid, remitance_ptid, region, district, ward, street, recipient_country, recipient_house_number) FROM '$$PATH$$/6650.dat';

--
-- Data for Name: remittances_sender; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.remittances_sender (ptid, remitance_ptid, region, district, ward, street, sender_country, sender_house_number) FROM stdin;
\.
COPY universe_dw.remittances_sender (ptid, remitance_ptid, region, district, ward, street, sender_country, sender_house_number) FROM '$$PATH$$/6648.dat';

--
-- Data for Name: safekeeping_heald_item; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.safekeeping_heald_item (ptid, reporting_date, deposit_date, beneficiary_name, relationship_type, collateral_type, beneficiary_country, credit_rating_counter_customer, gradesfor_unrated_customer, currency, org_amount, tzs_amount, past_due_days, impairment, bot_provision, batch_id) FROM stdin;
\.
COPY universe_dw.safekeeping_heald_item (ptid, reporting_date, deposit_date, beneficiary_name, relationship_type, collateral_type, beneficiary_country, credit_rating_counter_customer, gradesfor_unrated_customer, currency, org_amount, tzs_amount, past_due_days, impairment, bot_provision, batch_id) FROM '$$PATH$$/6540.dat';

--
-- Data for Name: securities_purchased; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.securities_purchased (ptid, reporting_date, seller_name, relationship_type, transaction_date, value_date, maturity_date, seller_country, cr_rating_counter_customer, gradesfor_unrated_customer, currency, org_purchased_amount, usd_purchased_amount, tzs_purchased_amount, org_resale_amount, usd_resale_amount, tzs_resale_amount, sna_classification, past_due_days, impairment, bot_provision, batch_id) FROM stdin;
\.
COPY universe_dw.securities_purchased (ptid, reporting_date, seller_name, relationship_type, transaction_date, value_date, maturity_date, seller_country, cr_rating_counter_customer, gradesfor_unrated_customer, currency, org_purchased_amount, usd_purchased_amount, tzs_purchased_amount, org_resale_amount, usd_resale_amount, tzs_resale_amount, sna_classification, past_due_days, impairment, bot_provision, batch_id) FROM '$$PATH$$/6550.dat';

--
-- Data for Name: securities_sold; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.securities_sold (ptid, reporting_date, relationship_type, value_date, maturity_date, buyer_name, buyer_country, cr_rating_counter_customer, gradesfor_unrated_customer, currency, org_sold_amount, usd_sold_amount, tzs_sold_amount, org_repurchase_amount, usd_repurchase_amount, tzs_repurchase_amount, sna_classification, past_due_days, impairment, bot_provision, batch_id) FROM stdin;
\.
COPY universe_dw.securities_sold (ptid, reporting_date, relationship_type, value_date, maturity_date, buyer_name, buyer_country, cr_rating_counter_customer, gradesfor_unrated_customer, currency, org_sold_amount, usd_sold_amount, tzs_sold_amount, org_repurchase_amount, usd_repurchase_amount, tzs_repurchase_amount, sna_classification, past_due_days, impairment, bot_provision, batch_id) FROM '$$PATH$$/6548.dat';

--
-- Data for Name: share_capital; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.share_capital (ptid, reporting_date, capital_category, capital_sub_category, transaction_date, shareholder_names, client_type, shareholder_country, number_of_shares, share_price_book_value, currency, org_amount, tzs_amount, sector_snaclassification, batch_id) FROM stdin;
\.
COPY universe_dw.share_capital (ptid, reporting_date, capital_category, capital_sub_category, transaction_date, shareholder_names, client_type, shareholder_country, number_of_shares, share_price_book_value, currency, org_amount, tzs_amount, sector_snaclassification, batch_id) FROM '$$PATH$$/6454.dat';

--
-- Data for Name: sold_forward_exchange; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.sold_forward_exchange (ptid, reporting_date, counterpart_name, relationship_type, currency_a, currency_b, org_amount_currency_a, exchange_rate_currency_ab, org_amount_currency_b, exchange_rate_currency_a_2_tzs, exchange_rate_currency_b_2_tzs, tzs_amount_currency_a, tzs_amount_currency_b, transaction_date, value_date, transaction_type, counterpart_country, cr_rating_counter_customer, grades_unrated_customer, past_due_days, impairment, bot_provision, batch_id) FROM stdin;
\.
COPY universe_dw.sold_forward_exchange (ptid, reporting_date, counterpart_name, relationship_type, currency_a, currency_b, org_amount_currency_a, exchange_rate_currency_ab, org_amount_currency_b, exchange_rate_currency_a_2_tzs, exchange_rate_currency_b_2_tzs, tzs_amount_currency_a, tzs_amount_currency_b, transaction_date, value_date, transaction_type, counterpart_country, cr_rating_counter_customer, grades_unrated_customer, past_due_days, impairment, bot_provision, batch_id) FROM '$$PATH$$/6536.dat';

--
-- Data for Name: subordinated_debt; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.subordinated_debt (ptid, reporting_date, lender_name, country, sector_sna_classification, lender_relationship, borrowing_purposes, currency, org_amount, tzs_amount, annual_interest_rate, interest_rate_type, loan_contract_date, loan_value_date, maturity_date, principal_payment_date, org_amount_repayment, tzs_amount_repayment, org_amount_closing, tzs_amount_closing, batch_id) FROM stdin;
\.
COPY universe_dw.subordinated_debt (ptid, reporting_date, lender_name, country, sector_sna_classification, lender_relationship, borrowing_purposes, currency, org_amount, tzs_amount, annual_interest_rate, interest_rate_type, loan_contract_date, loan_value_date, maturity_date, principal_payment_date, org_amount_repayment, tzs_amount_repayment, org_amount_closing, tzs_amount_closing, batch_id) FROM '$$PATH$$/6470.dat';

--
-- Data for Name: tbond_transactions; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.tbond_transactions (ptid, reporting_date, trade_date, seller_name, buyer_name, tbond_auction_number, isin, issue_date, maturity_date, tzs_amount, price, yield, coupon_rate, tenure, batch_id) FROM stdin;
\.
COPY universe_dw.tbond_transactions (ptid, reporting_date, trade_date, seller_name, buyer_name, tbond_auction_number, isin, issue_date, maturity_date, tzs_amount, price, yield, coupon_rate, tenure, batch_id) FROM '$$PATH$$/6584.dat';

--
-- Data for Name: transfers_payable; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.transfers_payable (ptid, reporting_date, customer_identification_number, beneficiary_name, beneficiary_country, purpose_transfer, beneficiary_acc_number, ben_receiving_institution, ben_sector_sna_classification, transaction_date, value_date, maturity_date, sender_name, sender_acc_number, sender_country, currency, org_amount, tzs_amount, org_amount_repayment, tzs_amount_repayment, org_amount_closing, tzs_amount_closing, batch_id) FROM stdin;
\.
COPY universe_dw.transfers_payable (ptid, reporting_date, customer_identification_number, beneficiary_name, beneficiary_country, purpose_transfer, beneficiary_acc_number, ben_receiving_institution, ben_sector_sna_classification, transaction_date, value_date, maturity_date, sender_name, sender_acc_number, sender_country, currency, org_amount, tzs_amount, org_amount_repayment, tzs_amount_repayment, org_amount_closing, tzs_amount_closing, batch_id) FROM '$$PATH$$/6466.dat';

--
-- Data for Name: trust_fiduciary_account; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.trust_fiduciary_account (ptid, reporting_date, deposit_date, beneficiary_name, relationship_type, collateral_type, beneficiary_country, credit_rating_counter_customer, gradesfor_unrated_customer, currency, org_amount, tzs_amount, past_due_days, impairment, bot_provision, batch_id) FROM stdin;
\.
COPY universe_dw.trust_fiduciary_account (ptid, reporting_date, deposit_date, beneficiary_name, relationship_type, collateral_type, beneficiary_country, credit_rating_counter_customer, gradesfor_unrated_customer, currency, org_amount, tzs_amount, past_due_days, impairment, bot_provision, batch_id) FROM '$$PATH$$/6538.dat';

--
-- Data for Name: underwriting_accounts; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.underwriting_accounts (ptid, reporting_date, underwriting_type, collateral_type, customer_name, transaction_date, total_value_share, total_value_share_underwritten, date_underwritten, past_due_days, provision, asset_classification_category, sector_sna_classification, batch_id) FROM stdin;
\.
COPY universe_dw.underwriting_accounts (ptid, reporting_date, underwriting_type, collateral_type, customer_name, transaction_date, total_value_share, total_value_share_underwritten, date_underwritten, past_due_days, provision, asset_classification_category, sector_sna_classification, batch_id) FROM '$$PATH$$/6516.dat';

--
-- Data for Name: undrawn_balance; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.undrawn_balance (ptid, reporting_date, client_file_number, borrower_name, relationship_type, contract_date, category_undrawn_balance, cr_rating_counter_customer, grades_unrated_customer, currency, org_sanctioned_amount, tzs_sactioned_amount, org_disbursed_amount, tzs_disbursed_amount, org_unutilised_amount, tzs_unutilised_amount, collateral_type, past_due_days, impairment, bot_provision, batch_id) FROM stdin;
\.
COPY universe_dw.undrawn_balance (ptid, reporting_date, client_file_number, borrower_name, relationship_type, contract_date, category_undrawn_balance, cr_rating_counter_customer, grades_unrated_customer, currency, org_sanctioned_amount, tzs_sactioned_amount, org_disbursed_amount, tzs_disbursed_amount, org_unutilised_amount, tzs_unutilised_amount, collateral_type, past_due_days, impairment, bot_provision, batch_id) FROM '$$PATH$$/6552.dat';

--
-- Data for Name: unearned_income; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.unearned_income (ptid, reporting_date, unearned_income_type, beneficiary_name, transaction_date, currency, org_amount, usd_amount, tzs_amount, sector_lender_sna_classification, batch_id) FROM stdin;
\.
COPY universe_dw.unearned_income (ptid, reporting_date, unearned_income_type, beneficiary_name, transaction_date, currency, org_amount, usd_amount, tzs_amount, sector_lender_sna_classification, batch_id) FROM '$$PATH$$/6472.dat';

--
-- Data for Name: user_pwd; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.user_pwd (user_id, encrypted_pwd, status, ptid, password_cycle, created_by, create_date) FROM stdin;
\.
COPY universe_dw.user_pwd (user_id, encrypted_pwd, status, ptid, password_cycle, created_by, create_date) FROM '$$PATH$$/6655.dat';

--
-- Data for Name: user_ref; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.user_ref (user_id, login_id, first_name, middle_name, last_name, gender, email_address, branch_id, security_role_id, start_dt, end_dt, failed_login_attempt, status, uuid, password_changed_flag, password_expiry_date, last_logon_date, created_by, create_dt, modified_by, modify_dt) FROM stdin;
\.
COPY universe_dw.user_ref (user_id, login_id, first_name, middle_name, last_name, gender, email_address, branch_id, security_role_id, start_dt, end_dt, failed_login_attempt, status, uuid, password_changed_flag, password_expiry_date, last_logon_date, created_by, create_dt, modified_by, modify_dt) FROM '$$PATH$$/6657.dat';

--
-- Data for Name: written_offloans; Type: TABLE DATA; Schema: universe_dw; Owner: postgres
--

COPY universe_dw.written_offloans (ptid, reporting_date, customer_identification_number, account_number, borrower_name, borrower_country, client_type, loan_number, loan_type, currency, org_disbursed_amount, tzs_disbursed_amount, disbursement_date, grace_period_payment_principal, maturity_date, gross_paid_amount, written_off_date, org_outstanding_principal_amount, tzs_outstanding_principal_amount, annual_interest_rate, latest_installment_pay_date, collateral_pledged, collateral_value, past_due_days, loan_officer, loan_supervisor, batch_id) FROM stdin;
\.
COPY universe_dw.written_offloans (ptid, reporting_date, customer_identification_number, account_number, borrower_name, borrower_country, client_type, loan_number, loan_type, currency, org_disbursed_amount, tzs_disbursed_amount, disbursement_date, grace_period_payment_principal, maturity_date, gross_paid_amount, written_off_date, org_outstanding_principal_amount, tzs_outstanding_principal_amount, annual_interest_rate, latest_installment_pay_date, collateral_pledged, collateral_value, past_due_days, loan_officer, loan_supervisor, batch_id) FROM '$$PATH$$/6612.dat';

--
-- Name: account_category_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.account_category_ptid_seq', 1, false);


--
-- Name: accounts_unsold_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.accounts_unsold_ptid_seq', 1, false);


--
-- Name: accrued_taxes_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.accrued_taxes_ptid_seq', 1, false);


--
-- Name: agent_information_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.agent_information_ptid_seq', 1, false);


--
-- Name: agent_transaction_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.agent_transaction_ptid_seq', 1, false);


--
-- Name: asset_owned_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.asset_owned_ptid_seq', 1, false);


--
-- Name: atm_information_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.atm_information_ptid_seq', 1, false);


--
-- Name: atm_transaction_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.atm_transaction_ptid_seq', 1, false);


--
-- Name: balance_bot_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.balance_bot_ptid_seq', 1, false);


--
-- Name: balance_mno_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.balance_mno_ptid_seq', 1, false);


--
-- Name: balance_other_banks_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.balance_other_banks_ptid_seq', 1, false);


--
-- Name: bank_funds_transfer_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.bank_funds_transfer_ptid_seq', 1, false);


--
-- Name: bankers_cheques_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.bankers_cheques_ptid_seq', 1, false);


--
-- Name: borrowings_information_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.borrowings_information_ptid_seq', 1, false);


--
-- Name: bot_replication_summary_batch_id_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.bot_replication_summary_batch_id_seq', 1, false);


--
-- Name: bot_replication_summary_file_id_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.bot_replication_summary_file_id_seq', 173, true);


--
-- Name: bought_forward_exchange_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.bought_forward_exchange_ptid_seq', 1, false);


--
-- Name: branch_information_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.branch_information_ptid_seq', 1, false);


--
-- Name: card_transaction_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.card_transaction_ptid_seq', 1, false);


--
-- Name: cash_information_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.cash_information_ptid_seq', 1, false);


--
-- Name: cheque_unsold_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.cheque_unsold_ptid_seq', 1, false);


--
-- Name: cheques_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.cheques_ptid_seq', 1, false);


--
-- Name: claim_treasury_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.claim_treasury_ptid_seq', 1, false);


--
-- Name: commercial_other_bills_purchased_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.commercial_other_bills_purchased_ptid_seq', 1, false);


--
-- Name: company_info_business_address_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.company_info_business_address_ptid_seq', 1, false);


--
-- Name: company_info_contact_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.company_info_contact_ptid_seq', 1, false);


--
-- Name: company_info_pri_address_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.company_info_pri_address_ptid_seq', 1, false);


--
-- Name: company_info_rel_person_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.company_info_rel_person_ptid_seq', 1, false);


--
-- Name: company_info_relation_entity_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.company_info_relation_entity_ptid_seq', 1, false);


--
-- Name: company_info_sec_address_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.company_info_sec_address_ptid_seq', 1, false);


--
-- Name: company_information_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.company_information_ptid_seq', 1, false);


--
-- Name: complaint_fraud_statistics_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.complaint_fraud_statistics_ptid_seq', 1, false);


--
-- Name: complaints_fraud_statistics_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.complaints_fraud_statistics_ptid_seq', 1, false);


--
-- Name: core_capital_deductions_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.core_capital_deductions_ptid_seq', 1, false);


--
-- Name: currency_swap_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.currency_swap_ptid_seq', 1, false);


--
-- Name: customer_liabilities_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.customer_liabilities_ptid_seq', 1, false);


--
-- Name: deposit_information_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.deposit_information_ptid_seq', 1, false);


--
-- Name: digital_credit_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.digital_credit_ptid_seq', 1, false);


--
-- Name: digital_saving_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.digital_saving_ptid_seq', 1, false);


--
-- Name: dividends_payable_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.dividends_payable_ptid_seq', 1, false);


--
-- Name: equity_derivatives_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.equity_derivatives_ptid_seq', 1, false);


--
-- Name: equity_investment_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.equity_investment_ptid_seq', 1, false);


--
-- Name: export_letters_credit_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.export_letters_credit_ptid_seq', 1, false);


--
-- Name: foreign_term_debt_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.foreign_term_debt_ptid_seq', 1, false);


--
-- Name: ibcm_transaction_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.ibcm_transaction_ptid_seq', 1, false);


--
-- Name: ifem_quotes_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.ifem_quotes_ptid_seq', 1, false);


--
-- Name: ifem_transaction_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.ifem_transaction_ptid_seq', 1, false);


--
-- Name: income_statement_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.income_statement_ptid_seq', 1, false);


--
-- Name: individual_address_info_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.individual_address_info_ptid_seq', 1, false);


--
-- Name: individual_birth_info_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.individual_birth_info_ptid_seq', 1, false);


--
-- Name: individual_contact_info_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.individual_contact_info_ptid_seq', 1, false);


--
-- Name: individual_employer_info_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.individual_employer_info_ptid_seq', 1, false);


--
-- Name: individual_enterprenuer_info_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.individual_enterprenuer_info_ptid_seq', 1, false);


--
-- Name: individual_ident_info_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.individual_ident_info_ptid_seq', 1, false);


--
-- Name: individual_information_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.individual_information_ptid_seq', 1, false);


--
-- Name: individual_sec_address_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.individual_sec_address_ptid_seq', 1, false);


--
-- Name: institution_premises_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.institution_premises_ptid_seq', 1, false);


--
-- Name: insurance_claim_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.insurance_claim_ptid_seq', 1, false);


--
-- Name: insurance_commission_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.insurance_commission_ptid_seq', 1, false);


--
-- Name: insurance_underwritting_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.insurance_underwritting_ptid_seq', 1, false);


--
-- Name: inter_branch_float_item_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.inter_branch_float_item_ptid_seq', 1, false);


--
-- Name: interbank_loan_payable_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.interbank_loan_payable_ptid_seq', 1, false);


--
-- Name: interbank_loans_receivable_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.interbank_loans_receivable_ptid_seq', 1, false);


--
-- Name: interest_rate_futures_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.interest_rate_futures_ptid_seq', 1, false);


--
-- Name: interest_rate_swap_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.interest_rate_swap_ptid_seq', 1, false);


--
-- Name: interest_trust_account_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.interest_trust_account_ptid_seq', 1, false);


--
-- Name: internet_banking_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.internet_banking_ptid_seq', 1, false);


--
-- Name: inv_debt_securities_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.inv_debt_securities_ptid_seq', 1, false);


--
-- Name: inward_bills_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.inward_bills_ptid_seq', 1, false);


--
-- Name: late_deposit_payments_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.late_deposit_payments_ptid_seq', 1, false);


--
-- Name: loan_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.loan_ptid_seq', 1, false);


--
-- Name: microfinance_segment_loans_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.microfinance_segment_loans_ptid_seq', 1, false);


--
-- Name: mno_funds_transfer_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.mno_funds_transfer_ptid_seq', 1, false);


--
-- Name: mobile_banking_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.mobile_banking_ptid_seq', 1, false);


--
-- Name: other_asset_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.other_asset_ptid_seq', 1, false);


--
-- Name: other_capital_account_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.other_capital_account_ptid_seq', 1, false);


--
-- Name: other_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.other_ptid_seq', 1, false);


--
-- Name: outstanding_acceptances_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.outstanding_acceptances_ptid_seq', 1, false);


--
-- Name: outstanding_guarantees_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.outstanding_guarantees_ptid_seq', 1, false);


--
-- Name: outstanding_letters_credit_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.outstanding_letters_credit_ptid_seq', 1, false);


--
-- Name: outward_bills_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.outward_bills_ptid_seq', 1, false);


--
-- Name: overdraft_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.overdraft_ptid_seq', 1, false);


--
-- Name: pos_information_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.pos_information_ptid_seq', 1, false);


--
-- Name: pos_transaction_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.pos_transaction_ptid_seq', 1, false);


--
-- Name: pre_operating_expenses_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.pre_operating_expenses_ptid_seq', 1, false);


--
-- Name: premises_furniture_equipment_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.premises_furniture_equipment_ptid_seq', 1, false);


--
-- Name: remittances_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.remittances_ptid_seq', 1, false);


--
-- Name: remittances_receiver_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.remittances_receiver_ptid_seq', 1, false);


--
-- Name: remittances_sender_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.remittances_sender_ptid_seq', 1, false);


--
-- Name: safekeeping_heald_item_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.safekeeping_heald_item_ptid_seq', 1, false);


--
-- Name: securities_purchased_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.securities_purchased_ptid_seq', 1, false);


--
-- Name: securities_sold_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.securities_sold_ptid_seq', 1, false);


--
-- Name: share_capital_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.share_capital_ptid_seq', 1, false);


--
-- Name: sold_forward_exchange_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.sold_forward_exchange_ptid_seq', 1, false);


--
-- Name: subordinated_debt_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.subordinated_debt_ptid_seq', 1, false);


--
-- Name: tbond_transactionaa_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.tbond_transactionaa_ptid_seq', 1, false);


--
-- Name: transfers_payable_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.transfers_payable_ptid_seq', 1, false);


--
-- Name: trust_fiduciary_account_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.trust_fiduciary_account_ptid_seq', 1, false);


--
-- Name: underwriting_accounts_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.underwriting_accounts_ptid_seq', 1, false);


--
-- Name: undrawn_balance_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.undrawn_balance_ptid_seq', 1, false);


--
-- Name: unearned_income_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.unearned_income_ptid_seq', 1, false);


--
-- Name: user_ref_user_id_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.user_ref_user_id_seq', 1, false);


--
-- Name: written_offloans_ptid_seq; Type: SEQUENCE SET; Schema: universe_dw; Owner: postgres
--

SELECT pg_catalog.setval('universe_dw.written_offloans_ptid_seq', 1, false);


--
-- Name: account_category account_category_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.account_category
    ADD CONSTRAINT account_category_pk PRIMARY KEY (ptid);


--
-- Name: accounts_unsold accounts_unsold_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.accounts_unsold
    ADD CONSTRAINT accounts_unsold_pk PRIMARY KEY (ptid);


--
-- Name: accrued_taxes accrued_taxes_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.accrued_taxes
    ADD CONSTRAINT accrued_taxes_pk PRIMARY KEY (ptid);


--
-- Name: agent_information agent_information_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.agent_information
    ADD CONSTRAINT agent_information_pk PRIMARY KEY (ptid);


--
-- Name: agent_transaction agent_transaction_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.agent_transaction
    ADD CONSTRAINT agent_transaction_pk PRIMARY KEY (ptid);


--
-- Name: asset_owned asset_owned_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.asset_owned
    ADD CONSTRAINT asset_owned_pk PRIMARY KEY (ptid);


--
-- Name: atm_information atm_information_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.atm_information
    ADD CONSTRAINT atm_information_pk PRIMARY KEY (ptid);


--
-- Name: atm_transaction atm_transaction_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.atm_transaction
    ADD CONSTRAINT atm_transaction_pk PRIMARY KEY (ptid);


--
-- Name: balance_bot balance_bot_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.balance_bot
    ADD CONSTRAINT balance_bot_pk PRIMARY KEY (ptid);


--
-- Name: balance_mno balance_mno_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.balance_mno
    ADD CONSTRAINT balance_mno_pk PRIMARY KEY (ptid);


--
-- Name: balance_other_banks balance_other_banks_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.balance_other_banks
    ADD CONSTRAINT balance_other_banks_pk PRIMARY KEY (ptid);


--
-- Name: bank_funds_transfer bank_funds_transfer_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bank_funds_transfer
    ADD CONSTRAINT bank_funds_transfer_pk PRIMARY KEY (ptid);


--
-- Name: bankers_cheques bankers_cheques_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bankers_cheques
    ADD CONSTRAINT bankers_cheques_pk PRIMARY KEY (ptid);


--
-- Name: borrowings_information borrowings_information_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.borrowings_information
    ADD CONSTRAINT borrowings_information_pk PRIMARY KEY (ptid);


--
-- Name: bot_replication_files bot_replication_files_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bot_replication_files
    ADD CONSTRAINT bot_replication_files_pk PRIMARY KEY (file_id);


--
-- Name: bot_replication_files bot_replication_files_un; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bot_replication_files
    ADD CONSTRAINT bot_replication_files_un UNIQUE (uuid);


--
-- Name: bot_replication_summary bot_replication_summary_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bot_replication_summary
    ADD CONSTRAINT bot_replication_summary_pk PRIMARY KEY (batch_id);


--
-- Name: bought_forward_exchange bought_forward_exchange_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bought_forward_exchange
    ADD CONSTRAINT bought_forward_exchange_pk PRIMARY KEY (ptid);


--
-- Name: branch_information branch_information_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.branch_information
    ADD CONSTRAINT branch_information_pk PRIMARY KEY (ptid);


--
-- Name: card_transaction card_transaction_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.card_transaction
    ADD CONSTRAINT card_transaction_pk PRIMARY KEY (ptid);


--
-- Name: cash_information cash_information_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.cash_information
    ADD CONSTRAINT cash_information_pk PRIMARY KEY (ptid);


--
-- Name: cheque_unsold cheque_unsold_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.cheque_unsold
    ADD CONSTRAINT cheque_unsold_pk PRIMARY KEY (ptid);


--
-- Name: cheques cheques_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.cheques
    ADD CONSTRAINT cheques_pk PRIMARY KEY (ptid);


--
-- Name: claim_treasury claim_treasury_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.claim_treasury
    ADD CONSTRAINT claim_treasury_pk PRIMARY KEY (ptid);


--
-- Name: commercial_other_bills_purchased commercial_other_bills_purchased_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.commercial_other_bills_purchased
    ADD CONSTRAINT commercial_other_bills_purchased_pk PRIMARY KEY (ptid);


--
-- Name: company_info company_information_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.company_info
    ADD CONSTRAINT company_information_pk PRIMARY KEY (ptid);


--
-- Name: complaint_fraud_statistics complaint_fraud_statistics_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.complaint_fraud_statistics
    ADD CONSTRAINT complaint_fraud_statistics_pk PRIMARY KEY (ptid);


--
-- Name: complaints_fraud_statistics complaints_fraud_statistics_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.complaints_fraud_statistics
    ADD CONSTRAINT complaints_fraud_statistics_pk PRIMARY KEY (ptid);


--
-- Name: core_capital_deductions core_capital_deductions_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.core_capital_deductions
    ADD CONSTRAINT core_capital_deductions_pk PRIMARY KEY (ptid);


--
-- Name: currency_swap currency_swap_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.currency_swap
    ADD CONSTRAINT currency_swap_pk PRIMARY KEY (ptid);


--
-- Name: customer_liabilities customer_liabilities_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.customer_liabilities
    ADD CONSTRAINT customer_liabilities_pk PRIMARY KEY (ptid);


--
-- Name: deposit_information deposit_information_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.deposit_information
    ADD CONSTRAINT deposit_information_pk PRIMARY KEY (ptid);


--
-- Name: digital_credit digital_credit_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.digital_credit
    ADD CONSTRAINT digital_credit_pk PRIMARY KEY (ptid);


--
-- Name: digital_saving digital_saving_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.digital_saving
    ADD CONSTRAINT digital_saving_pk PRIMARY KEY (ptid);


--
-- Name: dividends_payable dividends_payable_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.dividends_payable
    ADD CONSTRAINT dividends_payable_pk PRIMARY KEY (ptid);


--
-- Name: equity_derivatives equity_derivatives_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.equity_derivatives
    ADD CONSTRAINT equity_derivatives_pk PRIMARY KEY (ptid);


--
-- Name: equity_investment equity_investment_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.equity_investment
    ADD CONSTRAINT equity_investment_pk PRIMARY KEY (ptid);


--
-- Name: export_letters_credit export_letters_credit_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.export_letters_credit
    ADD CONSTRAINT export_letters_credit_pk PRIMARY KEY (ptid);


--
-- Name: foreign_term_debt foreign_term_debt_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.foreign_term_debt
    ADD CONSTRAINT foreign_term_debt_pk PRIMARY KEY (ptid);


--
-- Name: ibcm_transaction ibcm_transaction_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.ibcm_transaction
    ADD CONSTRAINT ibcm_transaction_pk PRIMARY KEY (ptid);


--
-- Name: ifem_quotes ifem_quotes_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.ifem_quotes
    ADD CONSTRAINT ifem_quotes_pk PRIMARY KEY (ptid);


--
-- Name: ifem_transaction ifem_transaction_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.ifem_transaction
    ADD CONSTRAINT ifem_transaction_pk PRIMARY KEY (ptid);


--
-- Name: income_statement income_statement_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.income_statement
    ADD CONSTRAINT income_statement_pk PRIMARY KEY (ptid);


--
-- Name: individual_info individual_information_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_info
    ADD CONSTRAINT individual_information_pk PRIMARY KEY (ptid);


--
-- Name: institution_premises institution_premises_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.institution_premises
    ADD CONSTRAINT institution_premises_pk PRIMARY KEY (ptid);


--
-- Name: insurance_claim insurance_claim_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.insurance_claim
    ADD CONSTRAINT insurance_claim_pk PRIMARY KEY (ptid);


--
-- Name: insurance_commission insurance_commission_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.insurance_commission
    ADD CONSTRAINT insurance_commission_pk PRIMARY KEY (ptid);


--
-- Name: insurance_underwritting insurance_underwritting_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.insurance_underwritting
    ADD CONSTRAINT insurance_underwritting_pk PRIMARY KEY (ptid);


--
-- Name: inter_branch_float_item inter_branch_float_item_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.inter_branch_float_item
    ADD CONSTRAINT inter_branch_float_item_pk PRIMARY KEY (ptid);


--
-- Name: interbank_loan_payable interbank_loan_payable_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interbank_loan_payable
    ADD CONSTRAINT interbank_loan_payable_pk PRIMARY KEY (ptid);


--
-- Name: interbank_loans_receivable interbank_loans_receivable_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interbank_loans_receivable
    ADD CONSTRAINT interbank_loans_receivable_pk PRIMARY KEY (ptid);


--
-- Name: interest_rate_futures interest_rate_futures_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interest_rate_futures
    ADD CONSTRAINT interest_rate_futures_pk PRIMARY KEY (ptid);


--
-- Name: interest_rate_swap interest_rate_swap_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interest_rate_swap
    ADD CONSTRAINT interest_rate_swap_pk PRIMARY KEY (ptid);


--
-- Name: interest_trust_account interest_trust_account_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interest_trust_account
    ADD CONSTRAINT interest_trust_account_pk PRIMARY KEY (ptid);


--
-- Name: internet_banking internet_banking_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.internet_banking
    ADD CONSTRAINT internet_banking_pk PRIMARY KEY (ptid);


--
-- Name: inv_debt_securities inv_debt_securities_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.inv_debt_securities
    ADD CONSTRAINT inv_debt_securities_pk PRIMARY KEY (ptid);


--
-- Name: inward_bills inward_bills_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.inward_bills
    ADD CONSTRAINT inward_bills_pk PRIMARY KEY (ptid);


--
-- Name: late_deposit_payments late_deposit_payments_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.late_deposit_payments
    ADD CONSTRAINT late_deposit_payments_pk PRIMARY KEY (ptid);


--
-- Name: loan_information loan_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.loan_information
    ADD CONSTRAINT loan_pk PRIMARY KEY (ptid);


--
-- Name: microfinance_segment_loans microfinance_segment_loans_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.microfinance_segment_loans
    ADD CONSTRAINT microfinance_segment_loans_pk PRIMARY KEY (ptid);


--
-- Name: mno_funds_transfer mno_funds_transfer_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.mno_funds_transfer
    ADD CONSTRAINT mno_funds_transfer_pk PRIMARY KEY (ptid);


--
-- Name: mobile_banking mobile_banking_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.mobile_banking
    ADD CONSTRAINT mobile_banking_pk PRIMARY KEY (ptid);


--
-- Name: other_asset other_asset_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.other_asset
    ADD CONSTRAINT other_asset_pk PRIMARY KEY (ptid);


--
-- Name: other_capital_account other_capital_account_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.other_capital_account
    ADD CONSTRAINT other_capital_account_pk PRIMARY KEY (ptid);


--
-- Name: other_liability other_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.other_liability
    ADD CONSTRAINT other_pk PRIMARY KEY (ptid);


--
-- Name: outstanding_acceptances outstanding_acceptances_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.outstanding_acceptances
    ADD CONSTRAINT outstanding_acceptances_pk PRIMARY KEY (ptid);


--
-- Name: outstanding_guarantees outstanding_guarantees_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.outstanding_guarantees
    ADD CONSTRAINT outstanding_guarantees_pk PRIMARY KEY (ptid);


--
-- Name: outstanding_letters_credit outstanding_letters_credit_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.outstanding_letters_credit
    ADD CONSTRAINT outstanding_letters_credit_pk PRIMARY KEY (ptid);


--
-- Name: outward_bills outward_bills_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.outward_bills
    ADD CONSTRAINT outward_bills_pk PRIMARY KEY (ptid);


--
-- Name: overdraft overdraft_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.overdraft
    ADD CONSTRAINT overdraft_pk PRIMARY KEY (ptid);


--
-- Name: pos_information pos_information_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.pos_information
    ADD CONSTRAINT pos_information_pk PRIMARY KEY (ptid);


--
-- Name: pos_transaction pos_transaction_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.pos_transaction
    ADD CONSTRAINT pos_transaction_pk PRIMARY KEY (ptid);


--
-- Name: pre_operating_expenses pre_operating_expenses_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.pre_operating_expenses
    ADD CONSTRAINT pre_operating_expenses_pk PRIMARY KEY (ptid);


--
-- Name: premises_furniture_equipment premises_furniture_equipment_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.premises_furniture_equipment
    ADD CONSTRAINT premises_furniture_equipment_pk PRIMARY KEY (ptid);


--
-- Name: remittances remittances_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.remittances
    ADD CONSTRAINT remittances_pk PRIMARY KEY (ptid);


--
-- Name: remittances_sender remittances_sender_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.remittances_sender
    ADD CONSTRAINT remittances_sender_pk PRIMARY KEY (ptid);


--
-- Name: safekeeping_heald_item safekeeping_heald_item_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.safekeeping_heald_item
    ADD CONSTRAINT safekeeping_heald_item_pk PRIMARY KEY (ptid);


--
-- Name: securities_purchased securities_purchased_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.securities_purchased
    ADD CONSTRAINT securities_purchased_pk PRIMARY KEY (ptid);


--
-- Name: securities_sold securities_sold_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.securities_sold
    ADD CONSTRAINT securities_sold_pk PRIMARY KEY (ptid);


--
-- Name: share_capital share_capital_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.share_capital
    ADD CONSTRAINT share_capital_pk PRIMARY KEY (ptid);


--
-- Name: sold_forward_exchange sold_forward_exchange_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.sold_forward_exchange
    ADD CONSTRAINT sold_forward_exchange_pk PRIMARY KEY (ptid);


--
-- Name: subordinated_debt subordinated_debt_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.subordinated_debt
    ADD CONSTRAINT subordinated_debt_pk PRIMARY KEY (ptid);


--
-- Name: tbond_transactions tbond_transactionaa_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.tbond_transactions
    ADD CONSTRAINT tbond_transactionaa_pk PRIMARY KEY (ptid);


--
-- Name: transfers_payable transfers_payable_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.transfers_payable
    ADD CONSTRAINT transfers_payable_pk PRIMARY KEY (ptid);


--
-- Name: trust_fiduciary_account trust_fiduciary_account_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.trust_fiduciary_account
    ADD CONSTRAINT trust_fiduciary_account_pk PRIMARY KEY (ptid);


--
-- Name: underwriting_accounts underwriting_accounts_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.underwriting_accounts
    ADD CONSTRAINT underwriting_accounts_pk PRIMARY KEY (ptid);


--
-- Name: undrawn_balance undrawn_balance_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.undrawn_balance
    ADD CONSTRAINT undrawn_balance_pk PRIMARY KEY (ptid);


--
-- Name: unearned_income unearned_income_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.unearned_income
    ADD CONSTRAINT unearned_income_pk PRIMARY KEY (ptid);


--
-- Name: user_pwd user_pwd_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.user_pwd
    ADD CONSTRAINT user_pwd_pk PRIMARY KEY (ptid);


--
-- Name: user_ref user_ref_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.user_ref
    ADD CONSTRAINT user_ref_pk PRIMARY KEY (user_id);


--
-- Name: written_offloans written_offloans_pk; Type: CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.written_offloans
    ADD CONSTRAINT written_offloans_pk PRIMARY KEY (ptid);


--
-- Name: bot_replication_summary_uuid_idx; Type: INDEX; Schema: universe_dw; Owner: postgres
--

CREATE UNIQUE INDEX bot_replication_summary_uuid_idx ON universe_dw.bot_replication_summary USING btree (uuid);


--
-- Name: user_pwd_user_id_idx; Type: INDEX; Schema: universe_dw; Owner: postgres
--

CREATE INDEX user_pwd_user_id_idx ON universe_dw.user_pwd USING btree (user_id);


--
-- Name: account_category account_category_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.account_category
    ADD CONSTRAINT account_category_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: accounts_unsold accounts_unsold_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.accounts_unsold
    ADD CONSTRAINT accounts_unsold_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: accrued_taxes accrued_taxes_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.accrued_taxes
    ADD CONSTRAINT accrued_taxes_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: agent_information agent_information_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.agent_information
    ADD CONSTRAINT agent_information_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: agent_transaction agent_transaction_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.agent_transaction
    ADD CONSTRAINT agent_transaction_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: asset_owned asset_owned_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.asset_owned
    ADD CONSTRAINT asset_owned_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: atm_information atm_information_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.atm_information
    ADD CONSTRAINT atm_information_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: atm_transaction atm_transaction_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.atm_transaction
    ADD CONSTRAINT atm_transaction_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: balance_bot balance_bot_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.balance_bot
    ADD CONSTRAINT balance_bot_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: balance_mno balance_mno_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.balance_mno
    ADD CONSTRAINT balance_mno_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: balance_other_banks balance_other_banks_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.balance_other_banks
    ADD CONSTRAINT balance_other_banks_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: bank_funds_transfer bank_funds_transfer_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bank_funds_transfer
    ADD CONSTRAINT bank_funds_transfer_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: bankers_cheques bankers_cheques_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bankers_cheques
    ADD CONSTRAINT bankers_cheques_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: borrowings_information borrowings_information_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.borrowings_information
    ADD CONSTRAINT borrowings_information_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: bot_replication_summary bot_replication_summary_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bot_replication_summary
    ADD CONSTRAINT bot_replication_summary_fk FOREIGN KEY (file_id) REFERENCES universe_dw.bot_replication_files(file_id);


--
-- Name: bought_forward_exchange bought_forward_exchange_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.bought_forward_exchange
    ADD CONSTRAINT bought_forward_exchange_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: branch_information branch_information_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.branch_information
    ADD CONSTRAINT branch_information_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: card_transaction card_transaction_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.card_transaction
    ADD CONSTRAINT card_transaction_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: cash_information cash_information_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.cash_information
    ADD CONSTRAINT cash_information_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: cheque_unsold cheque_unsold_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.cheque_unsold
    ADD CONSTRAINT cheque_unsold_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: cheques cheques_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.cheques
    ADD CONSTRAINT cheques_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: claim_treasury claim_treasury_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.claim_treasury
    ADD CONSTRAINT claim_treasury_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: commercial_other_bills_purchased commercial_other_bills_purchased_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.commercial_other_bills_purchased
    ADD CONSTRAINT commercial_other_bills_purchased_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: company_info company_info_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.company_info
    ADD CONSTRAINT company_info_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: complaint_fraud_statistics complaint_fraud_statistics_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.complaint_fraud_statistics
    ADD CONSTRAINT complaint_fraud_statistics_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: complaints_fraud_statistics complaints_fraud_statistics_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.complaints_fraud_statistics
    ADD CONSTRAINT complaints_fraud_statistics_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: core_capital_deductions core_capital_deductions_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.core_capital_deductions
    ADD CONSTRAINT core_capital_deductions_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: currency_swap currency_swap_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.currency_swap
    ADD CONSTRAINT currency_swap_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: customer_liabilities customer_liabilities_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.customer_liabilities
    ADD CONSTRAINT customer_liabilities_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: deposit_information deposit_information_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.deposit_information
    ADD CONSTRAINT deposit_information_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: digital_credit digital_credit_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.digital_credit
    ADD CONSTRAINT digital_credit_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: digital_saving digital_saving_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.digital_saving
    ADD CONSTRAINT digital_saving_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: dividends_payable dividends_payable_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.dividends_payable
    ADD CONSTRAINT dividends_payable_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: equity_derivatives equity_derivatives_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.equity_derivatives
    ADD CONSTRAINT equity_derivatives_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: equity_investment equity_investment_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.equity_investment
    ADD CONSTRAINT equity_investment_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: export_letters_credit export_letters_credit_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.export_letters_credit
    ADD CONSTRAINT export_letters_credit_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: foreign_term_debt foreign_term_debt_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.foreign_term_debt
    ADD CONSTRAINT foreign_term_debt_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: ibcm_transaction ibcm_transaction_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.ibcm_transaction
    ADD CONSTRAINT ibcm_transaction_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: ifem_quotes ifem_quotes_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.ifem_quotes
    ADD CONSTRAINT ifem_quotes_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: ifem_transaction ifem_transaction_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.ifem_transaction
    ADD CONSTRAINT ifem_transaction_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: income_statement income_statement_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.income_statement
    ADD CONSTRAINT income_statement_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: individual_birth_info individual_birth_info_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_birth_info
    ADD CONSTRAINT individual_birth_info_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: individual_contact_info individual_contact_info_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_contact_info
    ADD CONSTRAINT individual_contact_info_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: individual_employer_info individual_employer_info_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_employer_info
    ADD CONSTRAINT individual_employer_info_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: individual_enterprenuer_info individual_enterprenuer_info_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_enterprenuer_info
    ADD CONSTRAINT individual_enterprenuer_info_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: individual_ident_info individual_ident_info_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_ident_info
    ADD CONSTRAINT individual_ident_info_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: individual_info individual_info_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_info
    ADD CONSTRAINT individual_info_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: individual_pri_address individual_pri_address_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_pri_address
    ADD CONSTRAINT individual_pri_address_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: individual_sec_address individual_sec_address_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.individual_sec_address
    ADD CONSTRAINT individual_sec_address_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: institution_premises institution_premises_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.institution_premises
    ADD CONSTRAINT institution_premises_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: insurance_claim insurance_claim_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.insurance_claim
    ADD CONSTRAINT insurance_claim_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: insurance_commission insurance_commission_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.insurance_commission
    ADD CONSTRAINT insurance_commission_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: insurance_underwritting insurance_underwritting_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.insurance_underwritting
    ADD CONSTRAINT insurance_underwritting_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: inter_branch_float_item inter_branch_float_item_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.inter_branch_float_item
    ADD CONSTRAINT inter_branch_float_item_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: interbank_loan_payable interbank_loan_payable_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interbank_loan_payable
    ADD CONSTRAINT interbank_loan_payable_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: interbank_loans_receivable interbank_loans_receivable_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interbank_loans_receivable
    ADD CONSTRAINT interbank_loans_receivable_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: interest_rate_futures interest_rate_futures_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interest_rate_futures
    ADD CONSTRAINT interest_rate_futures_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: interest_rate_swap interest_rate_swap_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interest_rate_swap
    ADD CONSTRAINT interest_rate_swap_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: interest_trust_account interest_trust_account_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.interest_trust_account
    ADD CONSTRAINT interest_trust_account_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: internet_banking internet_banking_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.internet_banking
    ADD CONSTRAINT internet_banking_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: inv_debt_securities inv_debt_securities_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.inv_debt_securities
    ADD CONSTRAINT inv_debt_securities_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: inward_bills inward_bills_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.inward_bills
    ADD CONSTRAINT inward_bills_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: late_deposit_payments late_deposit_payments_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.late_deposit_payments
    ADD CONSTRAINT late_deposit_payments_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: loan_information loan_information_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.loan_information
    ADD CONSTRAINT loan_information_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: microfinance_segment_loans microfinance_segment_loans_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.microfinance_segment_loans
    ADD CONSTRAINT microfinance_segment_loans_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: mno_funds_transfer mno_funds_transfer_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.mno_funds_transfer
    ADD CONSTRAINT mno_funds_transfer_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: mobile_banking mobile_banking_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.mobile_banking
    ADD CONSTRAINT mobile_banking_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: other_asset other_asset_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.other_asset
    ADD CONSTRAINT other_asset_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: other_capital_account other_capital_account_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.other_capital_account
    ADD CONSTRAINT other_capital_account_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: other_liability other_liability_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.other_liability
    ADD CONSTRAINT other_liability_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: outstanding_acceptances outstanding_acceptances_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.outstanding_acceptances
    ADD CONSTRAINT outstanding_acceptances_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: outstanding_guarantees outstanding_guarantees_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.outstanding_guarantees
    ADD CONSTRAINT outstanding_guarantees_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: outstanding_letters_credit outstanding_letters_credit_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.outstanding_letters_credit
    ADD CONSTRAINT outstanding_letters_credit_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: outward_bills outward_bills_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.outward_bills
    ADD CONSTRAINT outward_bills_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: overdraft overdraft_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.overdraft
    ADD CONSTRAINT overdraft_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: pos_information pos_information_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.pos_information
    ADD CONSTRAINT pos_information_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: pos_transaction pos_transaction_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.pos_transaction
    ADD CONSTRAINT pos_transaction_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: pre_operating_expenses pre_operating_expenses_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.pre_operating_expenses
    ADD CONSTRAINT pre_operating_expenses_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: premises_furniture_equipment premises_furniture_equipment_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.premises_furniture_equipment
    ADD CONSTRAINT premises_furniture_equipment_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: remittances remittances_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.remittances
    ADD CONSTRAINT remittances_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: safekeeping_heald_item safekeeping_heald_item_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.safekeeping_heald_item
    ADD CONSTRAINT safekeeping_heald_item_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: securities_purchased securities_purchased_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.securities_purchased
    ADD CONSTRAINT securities_purchased_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: securities_sold securities_sold_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.securities_sold
    ADD CONSTRAINT securities_sold_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: share_capital share_capital_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.share_capital
    ADD CONSTRAINT share_capital_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: sold_forward_exchange sold_forward_exchange_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.sold_forward_exchange
    ADD CONSTRAINT sold_forward_exchange_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: subordinated_debt subordinated_debt_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.subordinated_debt
    ADD CONSTRAINT subordinated_debt_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: tbond_transactions tbond_transactions_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.tbond_transactions
    ADD CONSTRAINT tbond_transactions_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: transfers_payable transfers_payable_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.transfers_payable
    ADD CONSTRAINT transfers_payable_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: trust_fiduciary_account trust_fiduciary_account_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.trust_fiduciary_account
    ADD CONSTRAINT trust_fiduciary_account_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: underwriting_accounts underwriting_accounts_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.underwriting_accounts
    ADD CONSTRAINT underwriting_accounts_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: undrawn_balance undrawn_balance_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.undrawn_balance
    ADD CONSTRAINT undrawn_balance_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: unearned_income unearned_income_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.unearned_income
    ADD CONSTRAINT unearned_income_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- Name: user_pwd user_pwd_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.user_pwd
    ADD CONSTRAINT user_pwd_fk FOREIGN KEY (user_id) REFERENCES universe_dw.user_ref(user_id);


--
-- Name: written_offloans written_offloans_fk; Type: FK CONSTRAINT; Schema: universe_dw; Owner: postgres
--

ALTER TABLE ONLY universe_dw.written_offloans
    ADD CONSTRAINT written_offloans_fk FOREIGN KEY (batch_id) REFERENCES universe_dw.bot_replication_summary(batch_id);


--
-- PostgreSQL database dump complete
--

